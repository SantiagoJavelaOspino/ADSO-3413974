// Safe HTML escaping & URL validation helpers (XSS protection)
const HTML_ESCAPE_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function escapeHtml(value) {
  if (value === null || value === undefined) return '';
  return String(value).replace(/[&<>"']/g, (ch) => HTML_ESCAPE_MAP[ch]);
}
function isSafeDataOrHttpUrl(url) {
  if (typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (/^data:(application\/pdf|application\/vnd\.openxmlformats-officedocument\.spreadsheetml\.sheet|application\/vnd\.ms-excel|image\/png|image\/jpeg);base64,[A-Za-z0-9+/=\s]+$/i.test(trimmed)) {
    return true;
  }
  return /^https?:\/\//i.test(trimmed) || trimmed.startsWith('/');
}

// State Management
let storedPerson = null;
try {
  const rawPerson = localStorage.getItem('person');
  if (rawPerson && rawPerson !== 'undefined' && rawPerson !== 'null') {
    storedPerson = JSON.parse(rawPerson);
  }
} catch (e) {
  storedPerson = null;
  localStorage.removeItem('person');
}

let state = {
  apiUrl: window.location.origin,
  token: localStorage.getItem('token') || '',
  person: storedPerson,
  activeSession: null,
  activeTab: 'control', // 'control' or 'report'
  qrcode: null,
  refreshInterval: null,
  countdownInterval: null,
  qrRotationInterval: null,
  searchQuery: '',
  presentsList: [],
  absentsList: []
};

// DOM Elements
const apiUrlInput = document.getElementById('apiUrlInput');
const apiStatusDot = document.getElementById('apiStatusDot');

const loginScreen = document.getElementById('loginScreen');
const dashboardScreen = document.getElementById('dashboardScreen');
const loginForm = document.getElementById('loginForm');
const loginDoc = document.getElementById('loginDoc');
const loginPassword = document.getElementById('loginPassword');
const loginFeedback = document.getElementById('loginFeedback');

const userInfo = document.getElementById('userInfo');
const userName = document.getElementById('userName');
const btnLogout = document.getElementById('btnLogout');

const activeFichaName = document.getElementById('activeFichaName');
const btnTabControl = document.getElementById('btnTabControl');
const btnTabReport = document.getElementById('btnTabReport');
const tabContentControl = document.getElementById('tabContentControl');
const tabContentReport = document.getElementById('tabContentReport');

const sessionSetupForm = document.getElementById('sessionSetupForm');
const selectFicha = document.getElementById('selectFicha');
const inputQrTtl = document.getElementById('inputQrTtl');
const btnCreateRoom = document.getElementById('btnCreateRoom');

const activeSessionController = document.getElementById('activeSessionController');
const roomCountdown = document.getElementById('roomCountdown');
const roomStatusBadge = document.getElementById('roomStatusBadge');
const btnReopenRoom = document.getElementById('btnReopenRoom');
const btnCloseSession = document.getElementById('btnCloseSession');
const btnNewRoom = document.getElementById('btnNewRoom');

const qrCodeCard = document.getElementById('qrCodeCard');
const qrRotationCount = document.getElementById('qrRotationCount');
const rejectionsCard = document.getElementById('rejectionsCard');
const rejectionsList = document.getElementById('rejectionsList');

const attendanceGridBody = document.getElementById('attendanceGridBody');
const btnRefreshGrid = document.getElementById('btnRefreshGrid');
const reportGridBody = document.getElementById('reportGridBody');
const btnPrintReport = document.getElementById('btnPrintReport');
const btnDownloadPdfReport = document.getElementById('btnDownloadPdfReport');
const btnSubmitEvidence = document.getElementById('btnSubmitEvidence');

// Student Dashboard & Excuses Elements
const studentDashboardScreen = document.getElementById('studentDashboardScreen');
const studentFichaName = document.getElementById('studentFichaName');
const studentTotalHours = document.getElementById('studentTotalHours');
const studentHistoryGridBody = document.getElementById('studentHistoryGridBody');
const btnRefreshStudent = document.getElementById('btnRefreshStudent');

const excuseModal = document.getElementById('excuseModal');
const excuseForm = document.getElementById('excuseForm');
const excuseSessionId = document.getElementById('excuseSessionId');
const excuseSessionSelect = document.getElementById('excuseSessionSelect');
const excuseText = document.getElementById('excuseText');
const excuseFile = document.getElementById('excuseFile');
const btnCancelExcuse = document.getElementById('btnCancelExcuse');

const btnTabExcuses = document.getElementById('btnTabExcuses');
const tabContentExcuses = document.getElementById('tabContentExcuses');
const instructorExcusesGridBody = document.getElementById('instructorExcusesGridBody');
const btnRefreshInstructorExcuses = document.getElementById('btnRefreshInstructorExcuses');

const btnTabLateRequests = document.getElementById('btnTabLateRequests');
const tabContentLateRequests = document.getElementById('tabContentLateRequests');
const lateRequestsLoading = document.getElementById('lateRequestsLoading');

// Ficha form selectors
const fichaJornada = document.getElementById('fichaJornada');
const fichaModalidad = document.getElementById('fichaModalidad');

// Coordinator Elements
const coordDashboardScreen = document.getElementById('coordDashboardScreen');
const btnCoordTabInstructors = document.getElementById('btnCoordTabInstructors');
const btnCoordTabFichas = document.getElementById('btnCoordTabFichas');
const btnCoordTabEvidences = document.getElementById('btnCoordTabEvidences');
const tabContentInstructors = document.getElementById('tabContentInstructors');
const tabContentFichas = document.getElementById('tabContentFichas');
const tabContentEvidences = document.getElementById('tabContentEvidences');
const coordInstructorsGridBody = document.getElementById('coordInstructorsGridBody');
const coordFichasGridBody = document.getElementById('coordFichasGridBody');
const coordEvidencesGridBody = document.getElementById('coordEvidencesGridBody');

const btnNewInstructor = document.getElementById('btnNewInstructor');
const btnNewFicha = document.getElementById('btnNewFicha');
const instructorModal = document.getElementById('instructorModal');
const fichaModal = document.getElementById('fichaModal');
const instructorForm = document.getElementById('instructorForm');
const fichaForm = document.getElementById('fichaForm');
const btnCancelInstructor = document.getElementById('btnCancelInstructor');
const btnCancelFicha = document.getElementById('btnCancelFicha');

const instructorModalTitle = document.getElementById('instructorModalTitle');
const instructorEditId = document.getElementById('instructorEditId');
const instNombre = document.getElementById('instNombre');
const instDocumento = document.getElementById('instDocumento');
const instPassword = document.getElementById('instPassword');
const instActiveWrapper = document.getElementById('instActiveWrapper');
const instActive = document.getElementById('instActive');

const fichaModalTitle = document.getElementById('fichaModalTitle');
const fichaEditId = document.getElementById('fichaEditId');
const fichaCode = document.getElementById('fichaCode');
const fichaName = document.getElementById('fichaName');
const fichaActiveWrapper = document.getElementById('fichaActiveWrapper');
const fichaActive = document.getElementById('fichaActive');

// Search & Bulk Elements
const searchStudentInput = document.getElementById('searchStudentInput');
const btnBulkMarkPresent = document.getElementById('btnBulkMarkPresent');

// Portal & Navigation Elements
const portalScreen = document.getElementById('portalScreen');
const scannerScreen = document.getElementById('scannerScreen');
const btnOpenStudentLogin = document.getElementById('btnOpenStudentLogin');
const btnOpenStaffLogin = document.getElementById('btnOpenStaffLogin');
const btnOpenStudentRegister = document.getElementById('btnOpenStudentRegister');
const btnBackToPortalFromStaff = document.getElementById('btnBackToPortalFromStaff');
const btnBackToPortalFromStudent = document.getElementById('btnBackToPortalFromStudent');
const btnSwitchToRegister = document.getElementById('btnSwitchToRegister');
const btnForgotStaff = document.getElementById('btnForgotStaff');
const btnForgotStudent = document.getElementById('btnForgotStudent');

// Student Auth Elements
const studentLoginScreen = document.getElementById('studentLoginScreen');
const studentLoginForm = document.getElementById('studentLoginForm');
const studentLoginDoc = document.getElementById('studentLoginDoc');
const studentLoginPassword = document.getElementById('studentLoginPassword');
const studentLoginFeedback = document.getElementById('studentLoginFeedback');
const btnToggleStudentPassword = document.getElementById('btnToggleStudentPassword');

// Student Register Modal Elements
const studentRegisterModal = document.getElementById('studentRegisterModal');
const btnCloseRegisterModal = document.getElementById('btnCloseRegisterModal');
const btnCancelRegister = document.getElementById('btnCancelRegister');
const studentRegisterForm = document.getElementById('studentRegisterForm');
const regFichaSelect = document.getElementById('regFichaSelect');
const regNombre = document.getElementById('regNombre');
const regDoc = document.getElementById('regDoc');
const regEmail = document.getElementById('regEmail');
const regPass = document.getElementById('regPass');
const regPassConfirm = document.getElementById('regPassConfirm');
const regTerms = document.getElementById('regTerms');
const registerFeedback = document.getElementById('registerFeedback');

// Forgot Password Elements
const forgotPasswordModal = document.getElementById('forgotPasswordModal');
const btnCloseForgotModal = document.getElementById('btnCloseForgotModal');
const forgotFeedback = document.getElementById('forgotFeedback');
const forgotRequestForm = document.getElementById('forgotRequestForm');
const forgotIdentifier = document.getElementById('forgotIdentifier');
const forgotResetSection = document.getElementById('forgotResetSection');
const resetPasswordForm = document.getElementById('resetPasswordForm');
const resetTokenInput = document.getElementById('resetTokenInput');
const resetNewPassInput = document.getElementById('resetNewPassInput');

// Student Dashboard Elements (4 Tabs)
const studentWelcomeName = document.getElementById('studentWelcomeName');
const btnStudentTabActive = document.getElementById('btnStudentTabActive');
const btnStudentTabHistory = document.getElementById('btnStudentTabHistory');
const btnStudentTabExcuses = document.getElementById('btnStudentTabExcuses');
const btnStudentTabSettings = document.getElementById('btnStudentTabSettings');
const studentTabContentActive = document.getElementById('studentTabContentActive');
const studentTabContentHistory = document.getElementById('studentTabContentHistory');
const studentTabContentExcuses = document.getElementById('studentTabContentExcuses');
const studentTabContentSettings = document.getElementById('studentTabContentSettings');
const studentActiveSessionContent = document.getElementById('studentActiveSessionContent');
const btnRefreshActiveSession = document.getElementById('btnRefreshActiveSession');
const studentExcusesGridBody = document.getElementById('studentExcusesGridBody');
const btnOpenNewExcuseModal = document.getElementById('btnOpenNewExcuseModal');
const studentChangePassForm = document.getElementById('studentChangePassForm');
const currentPassStudent = document.getElementById('currentPassStudent');
const newPassStudent = document.getElementById('newPassStudent');
const newPassConfirmStudent = document.getElementById('newPassConfirmStudent');
const btnVerifyCurrentPass = document.getElementById('btnVerifyCurrentPass');
const btnCancelChangePass = document.getElementById('btnCancelChangePass');
const btnToggleCurrentPassVisibility = document.getElementById('btnToggleCurrentPassVisibility');
const passVerifiedBadge = document.getElementById('passVerifiedBadge');
const feedbackChangePass = document.getElementById('feedbackChangePass');
const btnDeleteStudentAccount = document.getElementById('btnDeleteStudentAccount');

// Coordinator Tabs Elements (Dual + Audit)
const btnCoordTabDual = document.getElementById('btnCoordTabDual');
const btnCoordTabAudit = document.getElementById('btnCoordTabAudit');
const tabContentDual = document.getElementById('tabContentDual');
const tabContentAudit = document.getElementById('tabContentAudit');
const coordDualGridBody = document.getElementById('coordDualGridBody');
const coordAuditGridBody = document.getElementById('coordAuditGridBody');
const btnRefreshDual = document.getElementById('btnRefreshDual');
const btnRefreshAudit = document.getElementById('btnRefreshAudit');

// Request Ficha Deletion Modal (4 Eyes)
const requestFichaDeletionModal = document.getElementById('requestFichaDeletionModal');
const btnCloseDeletionModal = document.getElementById('btnCloseDeletionModal');
const btnCancelFichaDeletion = document.getElementById('btnCancelFichaDeletion');
const formRequestFichaDeletion = document.getElementById('formRequestFichaDeletion');
const deleteFichaId = document.getElementById('deleteFichaId');
const deleteFichaLabel = document.getElementById('deleteFichaLabel');
const deleteFichaReason = document.getElementById('deleteFichaReason');

// Initialize API configuration
// Initialize API configuration
let rawApiUrl = localStorage.getItem('apiUrl') || window.location.origin;
if (rawApiUrl.endsWith('/')) {
  rawApiUrl = rawApiUrl.slice(0, -1);
}
apiUrlInput.value = rawApiUrl;
state.apiUrl = rawApiUrl;

apiUrlInput.addEventListener('change', () => {
  let val = apiUrlInput.value.trim();
  if (val.endsWith('/')) {
    val = val.slice(0, -1);
  }
  apiUrlInput.value = val;
  state.apiUrl = val;
  localStorage.setItem('apiUrl', val);
  checkApiHealth();
});

async function checkApiHealth() {
  try {
    const res = await fetch(`${state.apiUrl}/health`);
    if (res.ok) {
      apiStatusDot.className = 'w-2 h-2 bg-green-500 rounded-full animate-pulse';
      return true;
    }
  } catch (err) {
    apiStatusDot.className = 'w-2 h-2 bg-red-500 rounded-full';
  }
  return false;
}

// HTML5 QR Scanner Instance
let html5QrCode = null;

function startQrScanner() {
  portalScreen?.classList.add('hidden');
  loginScreen?.classList.add('hidden');
  studentLoginScreen?.classList.add('hidden');
  dashboardScreen?.classList.add('hidden');
  studentDashboardScreen?.classList.add('hidden');
  coordDashboardScreen?.classList.add('hidden');
  userInfo?.classList.add('hidden');
  scannerScreen?.classList.remove('hidden');

  const feedback = document.getElementById('scannerFeedback');
  if (feedback) feedback.classList.add('hidden');

  if (typeof Html5Qrcode !== 'undefined') {
    if (!html5QrCode) {
      html5QrCode = new Html5Qrcode("reader");
    }
    const config = { fps: 10, qrbox: { width: 250, height: 250 } };

    html5QrCode.start(
      { facingMode: "environment" },
      config,
      (decodedText) => {
        stopQrScanner();
        let token = decodedText.trim();
        try {
          const url = new URL(decodedText);
          const tokenParam = url.searchParams.get('token');
          if (tokenParam) {
            token = tokenParam;
          } else {
            const pathParts = url.pathname.split('/');
            const lastPart = pathParts[pathParts.length - 1];
            if (lastPart && (url.pathname.includes('/attendance/') || url.pathname.includes('/attendance'))) {
              token = lastPart;
            }
          }
        } catch (e) {}

        if (state.token && state.person) {
          showDashboard();
          submitStudentCheckin(token);
        } else {
          sessionStorage.setItem('pending_qr_token', token.trim().toUpperCase());
          showStudentLogin();
          const fb = document.getElementById('studentLoginFeedback');
          if (fb) {
            fb.textContent = `Código de clase '${token}' detectado. Inicia sesión como aprendiz para confirmar tu asistencia.`;
            fb.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-green-500/10 text-green-400 border border-green-500/20 block';
          }
        }
      },
      () => {}
    ).catch(err => {
      if (feedback) {
        feedback.textContent = "No se pudo iniciar la cámara: " + (err?.message || err);
        feedback.className = "p-3 rounded-xl text-center text-xs font-semibold bg-red-500/10 text-red-400 border border-red-500/20";
        feedback.classList.remove('hidden');
      }
    });
  } else if (feedback) {
    feedback.textContent = "Lector de QR en carga...";
    feedback.classList.remove('hidden');
  }
}

function stopQrScanner() {
  if (html5QrCode) {
    try {
      if (html5QrCode.isScanning) {
        html5QrCode.stop().then(() => {
          html5QrCode = null;
        }).catch(() => { html5QrCode = null; });
      } else {
        html5QrCode = null;
      }
    } catch (e) {
      html5QrCode = null;
    }
  }
}

window.startQrScanner = startQrScanner;
window.stopQrScanner = stopQrScanner;

// App Initialization
document.addEventListener('DOMContentLoaded', () => {
  checkApiHealth();
  
  // Bind Portal Navigation Buttons
  const btnGoToScanner = document.getElementById('btnGoToScanner');
  if (btnGoToScanner) btnGoToScanner.addEventListener('click', startQrScanner);

  const btnCancelScanner = document.getElementById('btnCancelScanner');
  if (btnCancelScanner) btnCancelScanner.addEventListener('click', showPortal);

  if (btnOpenStudentLogin) btnOpenStudentLogin.addEventListener('click', showStudentLogin);
  if (btnOpenStaffLogin) btnOpenStaffLogin.addEventListener('click', showLogin);
  if (btnOpenStudentRegister) btnOpenStudentRegister.addEventListener('click', openStudentRegisterModal);
  if (btnBackToPortalFromStaff) btnBackToPortalFromStaff.addEventListener('click', showPortal);
  if (btnBackToPortalFromStudent) btnBackToPortalFromStudent.addEventListener('click', showPortal);
  if (btnSwitchToRegister) btnSwitchToRegister.addEventListener('click', openStudentRegisterModal);

  // Forgot Password Openers & Closers
  if (btnForgotStaff) {
    btnForgotStaff.addEventListener('click', () => {
      forgotPasswordModal?.classList.remove('hidden');
      forgotFeedback?.classList.add('hidden');
      forgotResetSection?.classList.add('hidden');
      forgotRequestForm?.reset();
    });
  }
  if (btnForgotStudent) {
    btnForgotStudent.addEventListener('click', () => {
      forgotPasswordModal?.classList.remove('hidden');
      forgotFeedback?.classList.add('hidden');
      forgotResetSection?.classList.add('hidden');
      forgotRequestForm?.reset();
    });
  }
  if (btnCloseForgotModal) btnCloseForgotModal.addEventListener('click', () => forgotPasswordModal?.classList.add('hidden'));

  // Student Register Modal Closers
  if (btnCloseRegisterModal) btnCloseRegisterModal.addEventListener('click', () => studentRegisterModal?.classList.add('hidden'));
  if (btnCancelRegister) btnCancelRegister.addEventListener('click', () => studentRegisterModal?.classList.add('hidden'));

  // Deletion Modal Closers
  if (btnCloseDeletionModal) btnCloseDeletionModal.addEventListener('click', () => requestFichaDeletionModal?.classList.add('hidden'));
  if (btnCancelFichaDeletion) btnCancelFichaDeletion.addEventListener('click', () => requestFichaDeletionModal?.classList.add('hidden'));

  // Manual code from scanner screen
  const btnScannerManualGo = document.getElementById('btnScannerManualGo');
  if (btnScannerManualGo) {
    btnScannerManualGo.addEventListener('click', async () => {
      const code = document.getElementById('scannerManualCode').value.trim().toUpperCase();
      if (code.length < 6) {
        const fb = document.getElementById('scannerFeedback');
        fb.textContent = 'Ingresa el código completo de 6 caracteres.';
        fb.className = 'p-3 rounded-xl text-center text-xs font-semibold bg-red-500/10 text-red-400 border border-red-500/20';
        fb.classList.remove('hidden');
        return;
      }
      stopQrScanner();
      if (state.token && state.person) {
        showDashboard();
        await submitStudentCheckin(code);
      } else {
        sessionStorage.setItem('pending_qr_token', code);
        showStudentLogin();
        const fb = document.getElementById('studentLoginFeedback');
        if (fb) {
          fb.textContent = `Código de clase '${code}' detectado. Inicia sesión como aprendiz para registrar tu asistencia.`;
          fb.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-green-500/10 text-green-400 border border-green-500/20 block';
        }
      }
    });
  }

  const scannerManualCode = document.getElementById('scannerManualCode');
  if (scannerManualCode) {
    scannerManualCode.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') btnScannerManualGo?.click();
    });
  }

  // Manual code from portal home landing screen
  const btnPortalManualGo = document.getElementById('btnPortalManualGo');
  const portalManualCode = document.getElementById('portalManualCode');
  if (btnPortalManualGo) {
    btnPortalManualGo.addEventListener('click', async () => {
      const code = portalManualCode ? portalManualCode.value.trim().toUpperCase() : '';
      if (code.length < 6) {
        alert('El código debe tener al menos 6 caracteres.');
        return;
      }
      if (state.token && state.person) {
        showDashboard();
        await submitStudentCheckin(code);
      } else {
        sessionStorage.setItem('pending_qr_token', code);
        showStudentLogin();
        const fb = document.getElementById('studentLoginFeedback');
        if (fb) {
          fb.textContent = `Código de clase '${code}' detectado. Inicia sesión para registrar tu asistencia.`;
          fb.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-green-500/10 text-green-400 border border-green-500/20 block';
        }
      }
    });
  }
  if (portalManualCode) {
    portalManualCode.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') btnPortalManualGo?.click();
    });
  }

  // Coordinator Tab bindings
  if (btnCoordTabInstructors) {
    btnCoordTabInstructors.addEventListener('click', () => {
      switchCoordTab('instructors');
      fetchCoordInstructors();
    });
  }
  if (btnCoordTabFichas) {
    btnCoordTabFichas.addEventListener('click', () => {
      switchCoordTab('fichas');
      fetchCoordFichas();
    });
  }
  if (btnCoordTabEvidences) {
    btnCoordTabEvidences.addEventListener('click', () => {
      switchCoordTab('evidences');
      fetchCoordEvidences();
    });
  }
  if (btnCoordTabDual) {
    btnCoordTabDual.addEventListener('click', () => {
      switchCoordTab('dual');
      fetchCoordDualApprovals();
    });
  }
  if (btnCoordTabAudit) {
    btnCoordTabAudit.addEventListener('click', () => {
      switchCoordTab('audit');
      fetchCoordAuditLogs();
    });
  }
  if (btnRefreshDual) btnRefreshDual.addEventListener('click', fetchCoordDualApprovals);
  if (btnRefreshAudit) btnRefreshAudit.addEventListener('click', fetchCoordAuditLogs);

  // Student Tab bindings
  if (btnStudentTabActive) {
    btnStudentTabActive.addEventListener('click', () => {
      switchStudentTab('active');
      loadStudentActiveSession();
    });
  }
  if (btnStudentTabHistory) {
    btnStudentTabHistory.addEventListener('click', () => {
      switchStudentTab('history');
      fetchStudentHistory();
    });
  }
  if (btnStudentTabExcuses) {
    btnStudentTabExcuses.addEventListener('click', () => {
      switchStudentTab('excuses');
      fetchStudentHistory();
    });
  }
  if (btnStudentTabSettings) {
    btnStudentTabSettings.addEventListener('click', () => {
      switchStudentTab('settings');
    });
  }
  if (btnRefreshActiveSession) btnRefreshActiveSession.addEventListener('click', loadStudentActiveSession);
  if (btnOpenNewExcuseModal) {
    btnOpenNewExcuseModal.addEventListener('click', async () => {
      if (!state.studentHistory || state.studentHistory.length === 0) {
        await fetchStudentHistory();
      }
      populateExcuseSessions();
      if (excuseSessionId) excuseSessionId.value = excuseSessionSelect?.value || '';
      if (excuseText) excuseText.value = '';
      if (excuseFile) excuseFile.value = '';
      excuseModal?.classList.remove('hidden');
    });
  }
  if (btnDeleteStudentAccount) btnDeleteStudentAccount.addEventListener('click', handleDeleteStudentAccount);

  // Coordinator Modal openers
  if (btnNewInstructor) {
    btnNewInstructor.addEventListener('click', () => {
      instructorModalTitle.textContent = "Registrar Nuevo Instructor";
      instructorEditId.value = "";
      instNombre.value = "";
      instDocumento.value = "";
      instDocumento.disabled = false;
      instPassword.value = "";
      instPassword.required = true;
      instActiveWrapper.classList.add('hidden');
      instructorModal.classList.remove('hidden');
    });
  }

  if (btnNewFicha) {
    btnNewFicha.addEventListener('click', () => {
      fichaModalTitle.textContent = "Registrar Nueva Ficha";
      fichaEditId.value = "";
      fichaCode.value = "";
      fichaCode.disabled = false;
      fichaName.value = "";
      if (fichaJornada) fichaJornada.value = "DIURNA";
      if (fichaModalidad) fichaModalidad.value = "PRESENCIAL";
      fichaActiveWrapper.classList.add('hidden');
      fichaModal.classList.remove('hidden');
    });
  }

  if (btnCancelInstructor) btnCancelInstructor.addEventListener('click', () => instructorModal?.classList.add('hidden'));
  if (btnCancelFicha) btnCancelFicha.addEventListener('click', () => fichaModal?.classList.add('hidden'));

  // Coordinator form submits
  if (instructorForm) instructorForm.addEventListener('submit', handleInstructorSubmit);
  if (fichaForm) fichaForm.addEventListener('submit', handleFichaSubmit);

  // Request Ficha Deletion Form Submit (4 Eyes)
  if (formRequestFichaDeletion) {
    formRequestFichaDeletion.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = deleteFichaId.value;
      const reason = deleteFichaReason.value.trim();
      if (!id || !reason) return;

      try {
        const res = await fetch(`${state.apiUrl}/api/coord/fichas/${id}/request-deletion`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${state.token}`
          },
          body: JSON.stringify({ reason })
        });
        const result = await res.json();
        if (res.ok) {
          alert(result.data?.message || 'Solicitud de baja radicada exitosamente.');
          requestFichaDeletionModal?.classList.add('hidden');
          fetchCoordFichas();
          fetchCoordDualApprovals();
        } else {
          alert(`Error: ${result.error?.message || 'No se pudo radicar la solicitud.'}`);
        }
      } catch (err) {
        alert('Error de conexión al solicitar la baja.');
      }
    });
  }

  // Toggle Staff Login Password Visibility
  const btnToggleLoginPassword = document.getElementById('btnToggleLoginPassword');
  if (btnToggleLoginPassword) {
    btnToggleLoginPassword.addEventListener('click', () => {
      const isPass = loginPassword.getAttribute('type') === 'password';
      loginPassword.setAttribute('type', isPass ? 'text' : 'password');
      const eyeOpen = document.getElementById('eyeIconOpen');
      const eyeClosed = document.getElementById('eyeIconClosed');
      if (eyeOpen && eyeClosed) {
        eyeOpen.classList.toggle('hidden', isPass);
        eyeClosed.classList.toggle('hidden', !isPass);
      }
    });
  }

  // Toggle Student Password Visibility
  if (btnToggleStudentPassword) {
    btnToggleStudentPassword.addEventListener('click', () => {
      const isPass = studentLoginPassword.getAttribute('type') === 'password';
      studentLoginPassword.setAttribute('type', isPass ? 'text' : 'password');
    });
  }

  // Toggle visibility of current password input
  if (btnToggleCurrentPassVisibility && currentPassStudent) {
    btnToggleCurrentPassVisibility.addEventListener('click', () => {
      const isPass = currentPassStudent.getAttribute('type') === 'password';
      currentPassStudent.setAttribute('type', isPass ? 'text' : 'password');
    });
  }

  function resetChangePasswordUi() {
    passVerifiedBadge?.classList.add('hidden');
    studentChangePassForm?.classList.add('hidden');
    btnVerifyCurrentPass?.classList.remove('hidden');
    if (currentPassStudent) {
      currentPassStudent.disabled = false;
      currentPassStudent.value = '';
    }
    if (newPassStudent) newPassStudent.value = '';
    if (newPassConfirmStudent) newPassConfirmStudent.value = '';
    feedbackChangePass?.classList.add('hidden');
  }

  // Step 1: Verify current password
  if (btnVerifyCurrentPass) {
    btnVerifyCurrentPass.addEventListener('click', async () => {
      feedbackChangePass?.classList.add('hidden');
      const currentPassword = (currentPassStudent?.value || '').trim();

      if (!currentPassword) {
        feedbackChangePass.textContent = 'Por favor ingresa tu contraseña actual.';
        feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        feedbackChangePass.classList.remove('hidden');
        currentPassStudent?.focus();
        return;
      }

      btnVerifyCurrentPass.disabled = true;
      btnVerifyCurrentPass.innerHTML = '<span>Verificando...</span>';

      try {
        const res = await fetch(`${state.apiUrl}/api/auth/verify-password`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${state.token}`
          },
          body: JSON.stringify({ currentPassword })
        });
        const result = await res.json();

        if (res.ok && result.data?.verified) {
          // Success: Unlock Step 2
          feedbackChangePass.textContent = 'Identidad confirmada. Ahora puedes ingresar tu nueva contraseña.';
          feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-green-500/10 text-green-400 border border-green-500/20';
          feedbackChangePass.classList.remove('hidden');

          passVerifiedBadge?.classList.remove('hidden');
          currentPassStudent.disabled = true;
          btnVerifyCurrentPass.classList.add('hidden');
          studentChangePassForm?.classList.remove('hidden');
          newPassStudent?.focus();
        } else {
          feedbackChangePass.textContent = result.error?.message || 'La contraseña actual es incorrecta.';
          feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
          feedbackChangePass.classList.remove('hidden');
        }
      } catch (err) {
        feedbackChangePass.textContent = 'Error de conexión al verificar contraseña.';
        feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        feedbackChangePass.classList.remove('hidden');
      } finally {
        btnVerifyCurrentPass.disabled = false;
        btnVerifyCurrentPass.innerHTML = '<span>Verificar Contraseña Actual</span>';
      }
    });
  }

  // Cancel Step 2 and reset to Step 1
  if (btnCancelChangePass) {
    btnCancelChangePass.addEventListener('click', () => {
      resetChangePasswordUi();
    });
  }

  // Step 2: Submit new password
  if (studentChangePassForm) {
    studentChangePassForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      feedbackChangePass?.classList.add('hidden');
      const currentPassword = currentPassStudent?.value || '';
      const newPassword = (newPassStudent?.value || '').trim();
      const confirmPassword = (newPassConfirmStudent?.value || '').trim();

      if (newPassword.length < 6) {
        feedbackChangePass.textContent = 'La nueva contraseña debe tener mínimo 6 caracteres.';
        feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        feedbackChangePass.classList.remove('hidden');
        return;
      }

      if (newPassword !== confirmPassword) {
        feedbackChangePass.textContent = 'La nueva contraseña y su confirmación no coinciden.';
        feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        feedbackChangePass.classList.remove('hidden');
        return;
      }

      if (currentPassword === newPassword) {
        feedbackChangePass.textContent = 'La nueva contraseña no puede ser idéntica a la actual.';
        feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        feedbackChangePass.classList.remove('hidden');
        return;
      }

      const submitBtn = document.getElementById('btnSubmitNewPass');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span>Actualizando...</span>';
      }

      try {
        const res = await fetch(`${state.apiUrl}/api/auth/change-password`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${state.token}`
          },
          body: JSON.stringify({ currentPassword, newPassword })
        });
        const result = await res.json();
        if (res.ok) {
          alert('¡Contraseña actualizada exitosamente! Usa tu nueva contraseña en tu próximo inicio de sesión.');
          resetChangePasswordUi();
        } else {
          feedbackChangePass.textContent = result.error?.message || 'Error al cambiar contraseña.';
          feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
          feedbackChangePass.classList.remove('hidden');
        }
      } catch (err) {
        feedbackChangePass.textContent = 'Error de conexión.';
        feedbackChangePass.className = 'p-2.5 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        feedbackChangePass.classList.remove('hidden');
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '<span>Guardar Nueva Contraseña</span>';
        }
      }
    });
  }

  // Student Login Form Submit
  if (studentLoginForm) {
    studentLoginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      studentLoginFeedback?.classList.add('hidden');
      const doc = studentLoginDoc.value.trim();
      const pass = studentLoginPassword.value.trim();

      try {
        const res = await fetch(`${state.apiUrl}/public/student/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ documento: doc, password: pass })
        });
        const result = await res.json();
        if (res.ok) {
          state.token = result.data.token;
          state.person = result.data.person;
          localStorage.setItem('token', state.token);
          localStorage.setItem('person', JSON.stringify(state.person));
          showDashboard();
        } else {
          studentLoginFeedback.textContent = result.error?.message || 'Error al iniciar sesión.';
          studentLoginFeedback.classList.remove('hidden');
        }
      } catch (err) {
        studentLoginFeedback.textContent = 'Error de conexión con el servidor.';
        studentLoginFeedback.classList.remove('hidden');
      }
    });
  }

  // Student Self-Registration Form Submit
  if (studentRegisterForm) {
    studentRegisterForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      registerFeedback?.classList.add('hidden');

      if (regPass.value !== regPassConfirm.value) {
        registerFeedback.textContent = 'Las contraseñas no coinciden.';
        registerFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        registerFeedback.classList.remove('hidden');
        return;
      }

      if (!regTerms.checked) {
        registerFeedback.textContent = 'Debe aceptar la Política de Tratamiento de Datos (Habeas Data).';
        registerFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        registerFeedback.classList.remove('hidden');
        return;
      }

      const payload = {
        fichaId: regFichaSelect.value,
        nombre: regNombre.value.trim(),
        documento: regDoc.value.trim(),
        email: regEmail.value.trim(),
        password: regPass.value.trim(),
        termsAccepted: true
      };

      try {
        const res = await fetch(`${state.apiUrl}/public/student/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const result = await res.json();
        if (res.ok) {
          state.token = result.data.token;
          state.person = result.data.person;
          localStorage.setItem('token', state.token);
          localStorage.setItem('person', JSON.stringify(state.person));
          studentRegisterModal?.classList.add('hidden');
          showDashboard();
        } else {
          registerFeedback.textContent = result.error?.message || 'Error durante el registro.';
          registerFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
          registerFeedback.classList.remove('hidden');
        }
      } catch (err) {
        registerFeedback.textContent = 'Error de conexión con el servidor.';
        registerFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        registerFeedback.classList.remove('hidden');
      }
    });
  }

  // Forgot Password Step 1 Form Submit
  if (forgotRequestForm) {
    forgotRequestForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      forgotFeedback?.classList.add('hidden');
      const identifier = forgotIdentifier.value.trim();

      try {
        const res = await fetch(`${state.apiUrl}/public/auth/forgot-password`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ documento: identifier })
        });
        const result = await res.json();
        if (res.ok) {
          forgotFeedback.textContent = result.data?.message || 'Si tu cuenta está activa, enviamos las instrucciones de recuperación.';
          forgotFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-blue-500/10 text-blue-400 border border-blue-500/20';
          forgotFeedback.classList.remove('hidden');
          forgotResetSection?.classList.remove('hidden');
        } else {
          forgotFeedback.textContent = result.error?.message || 'Error al procesar solicitud.';
          forgotFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
          forgotFeedback.classList.remove('hidden');
        }
      } catch (err) {
        forgotFeedback.textContent = 'Error de conexión con el servidor.';
        forgotFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        forgotFeedback.classList.remove('hidden');
      }
    });
  }

  // Forgot Password Step 2 (Reset Password) Form Submit
  if (resetPasswordForm) {
    resetPasswordForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const token = resetTokenInput.value.trim();
      const newPassword = resetNewPassInput.value.trim();

      try {
        const res = await fetch(`${state.apiUrl}/public/auth/reset-password`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token, newPassword })
        });
        const result = await res.json();
        if (res.ok) {
          alert(result.data?.message || 'Contraseña restablecida exitosamente. Ahora puedes iniciar sesión.');
          forgotPasswordModal?.classList.add('hidden');
        } else {
          forgotFeedback.textContent = result.error?.message || 'Error al restablecer contraseña.';
          forgotFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
          forgotFeedback.classList.remove('hidden');
        }
      } catch (err) {
        forgotFeedback.textContent = 'Error de conexión con el servidor.';
        forgotFeedback.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        forgotFeedback.classList.remove('hidden');
      }
    });
  }

  // Extract token from URL if present (?token=XYZ)
  const urlParams = new URLSearchParams(window.location.search);
  const tokenFromUrl = urlParams.get('token');
  if (tokenFromUrl) {
    sessionStorage.setItem('pending_qr_token', tokenFromUrl.trim().toUpperCase());
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  // Check login state
  if (state.token && state.person) {
    showDashboard();
  } else {
    const pending = sessionStorage.getItem('pending_qr_token');
    if (pending) {
      showStudentLogin();
      const fb = document.getElementById('studentLoginFeedback');
      if (fb) {
        fb.textContent = `🟢 Código de clase '${pending}' detectado. Inicia sesión como aprendiz para registrar tu asistencia.`;
        fb.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-green-500/10 text-green-400 border border-green-500/20 block';
      }
    } else {
      showPortal();
    }
  }
});

// Unified Institutional Authentication handler (Aprendiz, Instructor, Coordinador)
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginFeedback.classList.add('hidden');
    const submitBtn = document.getElementById('btnUnifiedLoginSubmit');

    const doc = loginDoc.value.trim();
    const pass = loginPassword.value;

    if (!doc || !pass) {
      loginFeedback.textContent = 'Ingresa tu documento o correo y tu contraseña.';
      loginFeedback.classList.remove('hidden');
      loginFeedback.focus();
      return;
    }

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Ingresando...';
    }

    try {
      const res = await fetch(`${state.apiUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: doc, documento: doc, password: pass })
      });

      const result = await res.json().catch(() => ({}));
      if (res.ok && result.data?.token) {
        state.token = result.data.token;
        state.person = result.data.person;
        localStorage.setItem('token', state.token);
        localStorage.setItem('person', JSON.stringify(state.person));
        loginPassword.value = '';
        showDashboard();
      } else {
        loginPassword.value = '';
        loginFeedback.textContent = result.error?.message || 'Credenciales inválidas. Verifica tus datos e intenta de nuevo.';
        loginFeedback.classList.remove('hidden');
        loginFeedback.focus();
      }
    } catch (err) {
      loginPassword.value = '';
      loginFeedback.textContent = 'Error de conexión con el servidor.';
      loginFeedback.classList.remove('hidden');
      loginFeedback.focus();
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Ingresar';
      }
    }
  });
}

btnLogout.addEventListener('click', () => {
  state.token = '';
  state.person = null;
  state.activeSession = null;
  localStorage.removeItem('token');
  localStorage.removeItem('person');
  stopSessionPolling();
  showPortal();
});

function handleAuthError(res) {
  if (res.status === 401) {
    state.token = '';
    state.person = null;
    state.activeSession = null;
    localStorage.removeItem('token');
    localStorage.removeItem('person');
    stopSessionPolling();
    showPortal();
    alert('Tu sesión ha expirado o el servidor fue reiniciado. Por favor, inicia sesión de nuevo.');
    return true;
  }
  return false;
}

function showPortal() {
  portalScreen?.classList.remove('hidden');
  scannerScreen?.classList.add('hidden');
  loginScreen?.classList.add('hidden');
  studentLoginScreen?.classList.add('hidden');
  dashboardScreen?.classList.add('hidden');
  studentDashboardScreen?.classList.add('hidden');
  coordDashboardScreen?.classList.add('hidden');
  userInfo?.classList.add('hidden');
  stopQrScanner();
}

function showLogin() {
  portalScreen?.classList.add('hidden');
  scannerScreen?.classList.add('hidden');
  loginScreen?.classList.remove('hidden');
  studentLoginScreen?.classList.add('hidden');
  dashboardScreen?.classList.add('hidden');
  studentDashboardScreen?.classList.add('hidden');
  coordDashboardScreen?.classList.add('hidden');
  userInfo?.classList.add('hidden');
  stopQrScanner();
}

function showStudentLogin() {
  portalScreen?.classList.add('hidden');
  scannerScreen?.classList.add('hidden');
  loginScreen?.classList.add('hidden');
  studentLoginScreen?.classList.remove('hidden');
  dashboardScreen?.classList.add('hidden');
  studentDashboardScreen?.classList.add('hidden');
  coordDashboardScreen?.classList.add('hidden');
  userInfo?.classList.add('hidden');
  stopQrScanner();
}

function showDashboard() {
  try {
    if (!state.person || !state.token) {
      showPortal();
      return;
    }

    const roles = (state.person && Array.isArray(state.person.roles)) ? state.person.roles : [];
    const isCoord = roles.includes('COORDINADOR');
    const isInstructor = roles.includes('INSTRUCTOR');
    const isStudent = !isCoord && !isInstructor;

    portalScreen?.classList.add('hidden');
    scannerScreen?.classList.add('hidden');
    loginScreen?.classList.add('hidden');
    studentLoginScreen?.classList.add('hidden');
    userInfo?.classList.remove('hidden');
    if (userName) userName.textContent = state.person?.nombre || '';
    const userRoleEl = document.getElementById('userRole');
    if (userRoleEl) {
      userRoleEl.textContent = isCoord ? 'COORDINADOR' : (isInstructor ? 'INSTRUCTOR' : 'APRENDIZ');
    }
    const headerSubtitle = document.getElementById('headerSubtitle');
    if (headerSubtitle) {
      headerSubtitle.textContent = isCoord ? 'Coordinación Académica' : (isInstructor ? 'Instructor SENA' : 'Aprendiz SENA');
    }
    stopQrScanner();

    if (isCoord) {
      coordDashboardScreen?.classList.remove('hidden');
      dashboardScreen?.classList.add('hidden');
      studentDashboardScreen?.classList.add('hidden');
      
      switchCoordTab('instructors');
      fetchCoordInstructors();
    } else if (isInstructor) {
      coordDashboardScreen?.classList.add('hidden');
      dashboardScreen?.classList.remove('hidden');
      studentDashboardScreen?.classList.add('hidden');
      loadFichas();
      checkForActiveSession();
      fetchInstructorExcuses();
    } else {
      coordDashboardScreen?.classList.add('hidden');
      dashboardScreen?.classList.add('hidden');
      studentDashboardScreen?.classList.remove('hidden');
      if (studentWelcomeName) {
        studentWelcomeName.textContent = `Bienvenido(a), ${state.person?.nombre || 'Aprendiz'} (${state.person?.documento || ''})`;
      }
      switchStudentTab('active');
      loadStudentActiveSession();
      fetchStudentHistory();

      const pendingToken = sessionStorage.getItem('pending_qr_token');
      if (pendingToken) {
        sessionStorage.removeItem('pending_qr_token');
        setTimeout(() => {
          submitStudentCheckin(pendingToken);
        }, 300);
      }
    }
  } catch (err) {
    console.error('Error al renderizar dashboard:', err);
    showPortal();
  }
}

// Student Tab Switcher
function switchStudentTab(tab) {
  const tabs = {
    active: { btn: btnStudentTabActive, content: studentTabContentActive },
    history: { btn: btnStudentTabHistory, content: studentTabContentHistory },
    excuses: { btn: btnStudentTabExcuses, content: studentTabContentExcuses },
    settings: { btn: btnStudentTabSettings, content: studentTabContentSettings }
  };

  Object.entries(tabs).forEach(([name, t]) => {
    if (t.btn && t.content) {
      if (name === tab) {
        t.btn.className = "px-4 py-2.5 text-sm font-semibold border-b-2 border-[#39A900] text-white transition-all whitespace-nowrap";
        t.content.classList.remove('hidden');
      } else {
        t.btn.className = "px-4 py-2.5 text-sm font-semibold border-b-2 border-transparent text-slate-400 hover:text-white transition-all whitespace-nowrap";
        t.content.classList.add('hidden');
      }
    }
  });

  if (tab === 'settings' && typeof resetChangePasswordUi === 'function') {
    resetChangePasswordUi();
  }
}

// Coordinator Tab Switcher
function switchCoordTab(tab) {
  const tabs = {
    instructors: { btn: btnCoordTabInstructors, content: tabContentInstructors },
    fichas: { btn: btnCoordTabFichas, content: tabContentFichas },
    evidences: { btn: btnCoordTabEvidences, content: tabContentEvidences },
    dual: { btn: btnCoordTabDual, content: tabContentDual },
    audit: { btn: btnCoordTabAudit, content: tabContentAudit }
  };

  Object.entries(tabs).forEach(([name, t]) => {
    if (t.btn && t.content) {
      if (name === tab) {
        t.btn.className = "px-4 py-2.5 text-sm font-semibold border-b-2 border-[#39A900] text-white transition-all";
        t.content.classList.remove('hidden');
      } else {
        t.btn.className = "px-4 py-2.5 text-sm font-semibold border-b-2 border-transparent text-slate-400 hover:text-white transition-all";
        t.content.classList.add('hidden');
      }
    }
  });
}

// Load Public Fichas for Self-Registration
async function loadPublicFichas() {
  if (!regFichaSelect) return;
  regFichaSelect.innerHTML = '<option value="">Cargando fichas activas...</option>';
  try {
    const res = await fetch(`${state.apiUrl}/public/fichas`);
    const result = await res.json();
    if (res.ok && result.data) {
      if (result.data.length === 0) {
        regFichaSelect.innerHTML = '<option value="">No hay fichas activas disponibles</option>';
        return;
      }
      regFichaSelect.innerHTML = '<option value="">-- Selecciona tu ficha académica --</option>' + 
        result.data.map(f => `<option value="${f.id}">${f.code} - ${f.name} (${f.jornada || 'DIURNA'} | ${f.modalidad || 'PRESENCIAL'})</option>`).join('');
    } else {
      regFichaSelect.innerHTML = '<option value="">Error cargando fichas</option>';
    }
  } catch (err) {
    regFichaSelect.innerHTML = '<option value="">Error de conexión</option>';
  }
}

function openStudentRegisterModal() {
  if (!studentRegisterModal) return;
  registerFeedback?.classList.add('hidden');
  studentRegisterForm?.reset();
  studentRegisterModal.classList.remove('hidden');
  loadPublicFichas();
}

// Load Active Session for Student (Tab 1)
async function loadStudentActiveSession() {
  if (!studentActiveSessionContent) return;
  studentActiveSessionContent.innerHTML = `
    <div class="flex flex-col items-center justify-center py-12 text-center text-slate-400">
      <svg class="w-8 h-8 animate-spin text-[#39A900] mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 1121.21 8H18.2"/></svg>
      <p class="text-sm font-medium">Verificando si tu instructor ha abierto clase...</p>
    </div>
  `;

  try {
    const res = await fetch(`${state.apiUrl}/api/student/active-session`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (!res.ok) {
      studentActiveSessionContent.innerHTML = `
        <div class="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-center text-red-400 text-sm">
          Error al verificar la sesión: ${result.error?.message || 'Error desconocido'}
        </div>
      `;
      return;
    }

    const { hasActiveSession, alreadyCheckedIn, checkinRecord, session, isExpired } = result.data;

    if (!hasActiveSession || !session) {
      studentActiveSessionContent.innerHTML = `
        <div class="flex flex-col items-center justify-center py-10 text-center text-slate-400">
          <div class="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-3">
            <svg class="w-8 h-8 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
          </div>
          <h4 class="text-white font-bold text-base mb-1">No hay ninguna sesión activa detectada para tu ficha</h4>
          <p class="text-xs text-slate-500 max-w-sm mb-5">Tu instructor abrirá la sala de asistencia al inicio de la jornada formativa presencial.</p>

          <div class="w-full max-w-md bg-slate-900/90 border border-slate-800 rounded-2xl p-5 text-left space-y-3">
            <span class="text-xs font-bold text-slate-300 uppercase tracking-wide block">¿Tienes el código de 6 caracteres del instructor?</span>
            <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <input 
                type="text" 
                id="inputInlineStudentCode" 
                maxlength="12" 
                placeholder="CÓDIGO (EJ: A8X9K2)" 
                class="flex-1 bg-slate-800/90 border border-slate-700 text-white font-mono font-bold text-center tracking-widest text-sm uppercase px-3 py-2.5 rounded-xl focus:border-[#39A900] focus:ring-1 focus:ring-[#39A900] outline-none"
              />
              <button 
                id="btnInlineStudentCheckin" 
                onclick="submitInlineManualCode()" 
                class="px-5 py-2.5 bg-[#39A900] hover:bg-[#329200] active:scale-95 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-[#39A900]/20 flex items-center justify-center gap-1.5"
              >
                <span>Registrar</span>
              </button>
            </div>
            <div id="inlineCheckinFeedback" class="hidden text-xs font-semibold"></div>
          </div>
        </div>
      `;
      setupInlineCodeKeydown();
      return;
    }

    if (alreadyCheckedIn) {
      const rec = checkinRecord || {};
      const horaIngreso = rec.hora_ingreso_real || '-';
      const horasVal = rec.horas_validadas_asistencia || 6;
      const horasProg = rec.horas_programadas_sesion || 6;
      const statusClass = rec.status === 'PRESENTE' || rec.status === 'accepted' ? 'text-green-400 bg-green-500/10 border-green-500/20' : 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';

      studentActiveSessionContent.innerHTML = `
        <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-2xl bg-green-500/10 border border-green-500/20 flex items-center justify-center text-green-400">
              <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="text-xs font-mono font-bold text-[#39A900]">${session.unitCode}</span>
                <span class="text-xs text-slate-400 font-semibold">${session.unitName}</span>
              </div>
              <h4 class="text-lg font-bold text-white mt-0.5">¡Asistencia Registrada Correctamente!</h4>
              <p class="text-xs text-slate-400 mt-0.5">Hora de ingreso acreditada: <span class="text-white font-mono font-bold">${horaIngreso}</span></p>
            </div>
          </div>
          <div class="flex flex-col items-center md:items-end gap-1">
            <span class="inline-flex px-3 py-1 rounded-full text-xs font-bold border ${statusClass}">${rec.status || 'REGULAR'}</span>
            <span class="text-xs font-mono text-slate-300 mt-1">${horasVal}h / ${horasProg}h computadas</span>
          </div>
        </div>
      `;
      return;
    }

    if (isExpired) {
      studentActiveSessionContent.innerHTML = `
        <div class="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div class="flex items-center gap-4">
            <div class="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="text-xs font-mono font-bold text-amber-400">Ficha ${session.unitCode}</span>
                <span class="text-xs text-slate-400 font-semibold">${session.unitName}</span>
              </div>
              <h4 class="text-lg font-bold text-white mt-0.5">Ventana de Ingreso Finalizada (15 min)</h4>
              <p class="text-xs text-slate-400 mt-0.5">La sala inició a las ${new Date(session.createdAt).toLocaleTimeString('es-CO')}. Si llegaste tarde o necesitas registrarte, solicita a tu instructor que reabra la sala o registre tu asistencia manual.</p>
            </div>
          </div>
        </div>
      `;
      return;
    }

    // Session is open and student has NOT checked in yet
    const mode = session.validationMode || 'IP_AND_QR';
    let modeBadge = `<span class="inline-flex px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">${mode}</span>`;
    
    studentActiveSessionContent.innerHTML = `
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 space-y-5">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div>
            <div class="flex items-center gap-2 mb-1">
              <span class="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></span>
              <span class="text-xs font-mono font-bold text-[#39A900]">Ficha ${session.unitCode}</span>
              ${modeBadge}
            </div>
            <h4 class="text-lg font-bold text-white">${session.unitName}</h4>
            <p class="text-xs text-slate-400 mt-0.5">Sesión abierta a las ${new Date(session.createdAt).toLocaleTimeString('es-CO')}. Registra tu asistencia.</p>
          </div>
        </div>

        <div id="studentCheckinActionArea" class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <button 
            id="btnStudentScanQr" 
            onclick="startQrScanner()"
            class="px-6 py-3 bg-[#39A900] hover:bg-[#329200] active:scale-95 text-white font-bold rounded-xl text-xs transition-all shadow-lg shadow-[#39A900]/20 flex items-center justify-center gap-2"
          >
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h.01M16 20h2M4 12h2m0 0H4m-2 0h2m14-4V4m0 8h2m-2-4h-2m-8 8v4m0 0v-4m-2 4h2M4 20h2m-2 0V16m2 4h2m4-12h.01M16 16h.01M20 12h.01"/></svg>
            <span>Escanear QR del Aula</span>
          </button>
        </div>

        <div class="pt-4 border-t border-slate-800/80">
          <label class="block text-xs font-bold text-slate-300 uppercase tracking-wide mb-2">
            O ingresa el código manual de 6 caracteres del instructor:
          </label>
          <div class="flex flex-wrap items-center gap-3">
            <input 
              type="text" 
              id="inputInlineStudentCode" 
              maxlength="12" 
              placeholder="CÓDIGO (EJ: A8X9K2)" 
              class="bg-slate-800/90 border border-slate-700 text-white font-mono font-bold text-center tracking-widest text-base uppercase px-4 py-2.5 rounded-xl focus:border-[#39A900] focus:ring-1 focus:ring-[#39A900] outline-none w-56 transition-all placeholder:tracking-normal placeholder:font-normal placeholder:text-xs placeholder:text-slate-500"
            />
            <button 
              id="btnInlineStudentCheckin" 
              onclick="submitInlineManualCode()" 
              class="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 active:scale-95 text-white font-bold rounded-xl text-xs transition-all shadow-lg shadow-blue-600/20 flex items-center gap-2"
            >
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
              <span>Registrar Asistencia</span>
            </button>
          </div>
          <div id="inlineCheckinFeedback" class="hidden mt-2 text-xs font-semibold"></div>
        </div>
      </div>
    `;
    setupInlineCodeKeydown();

  } catch (err) {
    studentActiveSessionContent.innerHTML = `<div class="p-4 text-center text-red-400 text-xs">Error de conexión al verificar sesión.</div>`;
  }
}

function setupInlineCodeKeydown() {
  const inp = document.getElementById('inputInlineStudentCode');
  if (inp) {
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        submitInlineManualCode();
      }
    });
  }
}

window.submitInlineManualCode = async () => {
  const inp = document.getElementById('inputInlineStudentCode');
  const fb = document.getElementById('inlineCheckinFeedback');
  if (!inp) return;
  const code = inp.value.trim().toUpperCase();
  if (code.length < 6) {
    if (fb) {
      fb.textContent = '❌ El código debe tener al menos 6 caracteres.';
      fb.className = 'mt-2 text-xs font-semibold text-red-400 block';
    } else {
      alert('El código debe tener al menos 6 caracteres.');
    }
    return;
  }
  if (fb) {
    fb.textContent = '⏳ Validando código y registrando asistencia...';
    fb.className = 'mt-2 text-xs font-semibold text-blue-400 block animate-pulse';
  }
  await submitStudentCheckin(code);
};

async function submitStudentCheckin(token) {
  if (!token) return;
  const cleanToken = token.trim().toUpperCase();

  if (studentActiveSessionContent) {
    studentActiveSessionContent.innerHTML = `
      <div class="flex flex-col items-center justify-center py-12 text-center text-slate-400">
        <svg class="w-8 h-8 animate-spin text-[#39A900] mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 1121.21 8H18.2"/></svg>
        <p class="text-sm font-medium">Validando asistencia con el aula formativa...</p>
      </div>
    `;
  }

  try {
    const res = await fetch(`${state.apiUrl}/public/attendance/${cleanToken}/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({
        documento: state.person.documento,
        qrToken: cleanToken
      })
    });
    const result = await res.json();
    if (res.ok) {
      alert('¡Asistencia registrada exitosamente!');
      await loadStudentActiveSession();
      await fetchStudentHistory();
    } else {
      alert(`Error al registrar asistencia: ${result.error?.message || 'Código inválido o sesión vencida.'}`);
      await loadStudentActiveSession();
    }
  } catch (err) {
    alert('Error de conexión al registrar la asistencia.');
    await loadStudentActiveSession();
  }
}

window.promptManualCode = async (sessionId) => {
  const inputEl = document.getElementById('inputInlineStudentCode');
  if (inputEl) {
    inputEl.focus();
    inputEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }
  const code = prompt('Ingresa el código alfanumérico de 6 caracteres visible en la pantalla del docente:');
  if (!code) return;
  const cleanCode = code.trim().toUpperCase();
  if (cleanCode.length < 6) {
    alert('El código debe tener al menos 6 caracteres.');
    return;
  }

  if (state.token && state.person) {
    await submitStudentCheckin(cleanCode);
  } else {
    sessionStorage.setItem('pending_qr_token', cleanCode);
    showStudentLogin();
    const fb = document.getElementById('studentLoginFeedback');
    if (fb) {
      fb.textContent = `Código de clase '${cleanCode}' detectado. Inicia sesión como aprendiz para registrar tu asistencia.`;
      fb.className = 'mb-4 p-3 rounded-xl text-xs font-semibold text-center bg-green-500/10 text-green-400 border border-green-500/20 block';
    }
  }
};


// Load Fichas into dropdown
async function loadFichas() {
  try {
    const isInstructor = state.person && (state.person.roles.includes('INSTRUCTOR') || !state.person.roles.includes('COORDINATOR'));
    let units = [];

    if (isInstructor) {
      const resUnits = await fetch(`${state.apiUrl}/api/instructor/my-units`, {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      if (handleAuthError(resUnits)) return;
      const unitsData = await resUnits.json();
      if (!resUnits.ok) throw new Error(unitsData.error?.message || 'Error cargando fichas');
      units = unitsData.data || [];
    } else {
      // 1. Get SENA institution ID
      const resInst = await fetch(`${state.apiUrl}/api/institutions`, {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      if (handleAuthError(resInst)) return;

      const instData = await resInst.json();
      if (!resInst.ok) throw new Error(instData.error.message);

      const sena = instData.data.find(inst => inst.code === 'SENA');
      if (!sena) throw new Error('No se encontró institución SENA.');

      // 2. Load units (Fichas)
      const resUnits = await fetch(`${state.apiUrl}/api/institutions/${sena.id}/units`, {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      if (handleAuthError(resUnits)) return;

      const unitsData = await resUnits.json();
      if (!resUnits.ok) throw new Error(unitsData.error.message);
      units = unitsData.data || [];
    }

    if (!units || units.length === 0) {
      selectFicha.innerHTML = '<option value="">⚠️ Sin fichas asignadas (Contacte al Coordinador)</option>';
      if (btnCreateRoom) {
        btnCreateRoom.disabled = true;
        btnCreateRoom.classList.add('opacity-50', 'cursor-not-allowed');
      }
      return;
    }

    if (btnCreateRoom) {
      btnCreateRoom.disabled = false;
      btnCreateRoom.classList.remove('opacity-50', 'cursor-not-allowed');
    }

    selectFicha.innerHTML = '<option value="">-- Seleccione una Ficha --</option>';
    units.forEach(unit => {
      selectFicha.innerHTML += `<option value="${unit.id}">${unit.code} - ${unit.name}</option>`;
    });

  } catch (err) {
    console.error('Error loading Fichas:', err);
    selectFicha.innerHTML = '<option value="">Error al cargar Fichas</option>';
  }
}

// Check if there is an active session running
async function checkForActiveSession() {
  try {
    const res = await fetch(`${state.apiUrl}/api/sessions`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok && result.data && result.data.length > 0) {
      // Find the most recent active or draft session
      const latest = result.data[0];
      if (latest.status === 'active') {
        state.activeSession = latest;
        startSessionPolling();
      }
    }
  } catch (err) {
    console.error('Error checking sessions:', err);
  }
}

// Room Creation
btnCreateRoom.addEventListener('click', async () => {
  const unitId = selectFicha.value;
  const qrTtl = parseInt(inputQrTtl.value) || 15;
  const ipCheckEnabled = document.getElementById('inputIpCheckEnabled').checked;

  if (!unitId) {
    alert('Por favor seleccione una ficha.');
    return;
  }

  try {
    const res = await fetch(`${state.apiUrl}/room/create`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}` 
      },
      body: JSON.stringify({
        institutionId: state.person.institutionId,
        unitId,
        qrTtlMinutes: qrTtl,
        ipCheckEnabled
      })
    });

    const result = await res.json();
    if (res.ok) {
      state.activeSession = result.data;
      startSessionPolling();
    } else {
      alert(`Error: ${result.error.message}`);
    }
  } catch (err) {
    alert('Error al abrir la sala.');
  }
});

// Reopen Room
btnReopenRoom.addEventListener('click', async () => {
  if (!state.activeSession) return;

  try {
    const res = await fetch(`${state.apiUrl}/room/reopen`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({ sessionId: state.activeSession.id })
    });

    const result = await res.json();
    if (res.ok) {
      state.activeSession = result.data;
      alert('Sala reabierta por 15 minutos para registrar salidas.');
      startSessionPolling();
    } else {
      alert(`Error: ${result.error.message}`);
    }
  } catch (err) {
    alert('Error al reabrir la sala.');
  }
});

// Close Session Manual
btnCloseSession.addEventListener('click', async () => {
  if (!state.activeSession) return;
  if (!confirm('¿Está seguro de cerrar la sala? Los aprendices no podrán registrar más asistencia.')) return;

  try {
    const res = await fetch(`${state.apiUrl}/api/sessions/${state.activeSession.id}/close`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${state.token}` }
    });

    const result = await res.json();
    if (res.ok) {
      state.activeSession = result.data;
      alert('Sala cerrada exitosamente.');
      stopSessionPolling();
      updateControllerView();
      fetchRealTimeAttendance();
    } else {
      alert(`Error: ${result.error.message}`);
    }
  } catch (err) {
    alert('Error al cerrar la sala.');
  }
});

// Manual Check-in Modal for Students without Device
const btnOpenManualCheckinModal = document.getElementById('btnOpenManualCheckinModal');
const manualCheckinModal = document.getElementById('manualCheckinModal');
const btnCancelManualCheckin = document.getElementById('btnCancelManualCheckin');
const btnCancelManualCheckin2 = document.getElementById('btnCancelManualCheckin2');
const formManualCheckin = document.getElementById('formManualCheckin');
const feedbackManualCheckin = document.getElementById('feedbackManualCheckin');
const manualDoc = document.getElementById('manualDoc');
const manualNombre = document.getElementById('manualNombre');

if (btnOpenManualCheckinModal) {
  btnOpenManualCheckinModal.addEventListener('click', () => {
    if (!state.activeSession) {
      alert('Debe tener una sala de clase activa para registrar asistencias.');
      return;
    }
    feedbackManualCheckin.className = 'hidden mb-3 p-3 rounded-xl text-xs font-semibold text-center';
    manualDoc.value = '';
    manualNombre.value = '';
    manualCheckinModal.classList.remove('hidden');
  });
}

if (btnCancelManualCheckin) btnCancelManualCheckin.addEventListener('click', () => manualCheckinModal.classList.add('hidden'));
if (btnCancelManualCheckin2) btnCancelManualCheckin2.addEventListener('click', () => manualCheckinModal.classList.add('hidden'));

if (formManualCheckin) {
  formManualCheckin.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!state.activeSession) return;
    
    const doc = manualDoc.value.trim();
    const nom = manualNombre.value.trim();
    if (!doc) return;

    try {
      const res = await fetch(`${state.apiUrl}/attendance/manual-override`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${state.token}`
        },
        body: JSON.stringify({
          sessionId: state.activeSession.id,
          documento: doc,
          nombre: nom,
          horas_validadas_asistencia: 6,
          horas_inasistencia_acumulada: 0,
          tipo_registro: 'MANUAL_INSTRUCTOR'
        })
      });

      const result = await res.json();
      if (res.ok) {
        alert('¡Asistencia registrada manualmente con éxito!');
        manualCheckinModal.classList.add('hidden');
        fetchRealTimeAttendance();
      } else {
        feedbackManualCheckin.className = 'mb-3 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
        feedbackManualCheckin.textContent = result.error?.message || 'Error al registrar asistencia manual.';
      }
    } catch(err) {
      feedbackManualCheckin.className = 'mb-3 p-3 rounded-xl text-xs font-semibold text-center bg-red-500/10 text-red-400 border border-red-500/20';
      feedbackManualCheckin.textContent = 'Error de conexión con el servidor.';
    }
  });
}

// Polling and timers
function startSessionPolling() {
  updateControllerView();
  fetchRealTimeAttendance();

  // Polling grid and rejections every 10 seconds
  state.refreshInterval = setInterval(() => {
    fetchRealTimeAttendance();
  }, 10000);

  // QR rotation polling every 60 seconds
  rotateQrCode();
  state.qrRotationInterval = setInterval(() => {
    rotateQrCode();
  }, 60000);

  // Room expiration countdown every 1 second
  startRoomCountdown();
}

function stopSessionPolling() {
  if (state.refreshInterval) clearInterval(state.refreshInterval);
  if (state.qrRotationInterval) clearInterval(state.qrRotationInterval);
  if (state.countdownInterval) clearInterval(state.countdownInterval);
  
  state.refreshInterval = null;
  state.qrRotationInterval = null;
  state.countdownInterval = null;
  
  // Clean QR Container
  document.getElementById('qrcode').innerHTML = '';
}

function updateControllerView() {
  if (state.activeSession) {
    sessionSetupForm.classList.add('hidden');
    activeSessionController.classList.remove('hidden');
    rejectionsCard.classList.remove('hidden');

    const selectedOption = selectFicha.querySelector(`option[value="${state.activeSession.unit_id}"]`);
    const cleanUnitId = state.activeSession.unit_id ? state.activeSession.unit_id.replace('unit_ficha_', '') : '';
    activeFichaName.textContent = selectedOption ? `Ficha ${selectedOption.textContent}` : `Ficha ${state.activeSession.unit_code || cleanUnitId}`;

    // Manage status indicators
    if (state.activeSession.status === 'active') {
      qrCodeCard.classList.remove('hidden');
      btnNewRoom.classList.add('hidden');
      btnCloseSession.classList.remove('hidden');
      roomStatusBadge.textContent = state.activeSession.is_reopened ? 'REGISTRO SALIDA' : 'REGISTRO ENTRADA';
      roomStatusBadge.className = state.activeSession.is_reopened 
        ? 'inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-500/10 text-blue-400 border border-blue-500/20'
        : 'inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-green-500/10 text-green-400 border border-green-500/20';
    } else {
      qrCodeCard.classList.add('hidden');
      btnNewRoom.classList.remove('hidden');
      btnCloseSession.classList.add('hidden');
      btnReopenRoom.classList.add('hidden');
      roomStatusBadge.textContent = 'CERRADA';
      roomStatusBadge.className = 'inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-500/10 text-red-400 border border-red-500/20';
    }
  } else {
    sessionSetupForm.classList.remove('hidden');
    activeSessionController.classList.add('hidden');
    qrCodeCard.classList.add('hidden');
    rejectionsCard.classList.add('hidden');
    btnNewRoom.classList.add('hidden');
    activeFichaName.textContent = 'Seleccione una Ficha para Iniciar';
  }
}

async function rotateQrCode() {
  if (!state.activeSession || state.activeSession.status !== 'active') return;

  try {
    const res = await fetch(`${state.apiUrl}/api/sessions/${state.activeSession.id}/qr-token`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (res.ok) {
      const data = await res.json();
      const baseUrl = state.apiUrl && state.apiUrl.startsWith('http') ? state.apiUrl : window.location.origin;
      const qrUrl = `${baseUrl}/?token=${data.qrToken}`;
      
      // Update manual code
      const manualCode = data.qrToken.substring(0, 6).toUpperCase();
      document.getElementById('qrManualCode').textContent = manualCode;

      // Clear container and render QR
      const qrContainer = document.getElementById('qrcode');
      qrContainer.innerHTML = '';
      state.qrcode = new QRCode(qrContainer, {
        text: qrUrl,
        width: 192,
        height: 192,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
      });

      // Start 15s visual countdown
      let remaining = data.expiresSec;
      qrRotationCount.textContent = `${remaining}s`;
      
      if (window.rotationTimer) clearInterval(window.rotationTimer);
      window.rotationTimer = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
          clearInterval(window.rotationTimer);
        }
        qrRotationCount.textContent = `${remaining}s`;
      }, 1000);
    }
  } catch (err) {
    console.error('Error rotating QR token:', err);
  }
}

function startRoomCountdown() {
  if (state.countdownInterval) clearInterval(state.countdownInterval);

  state.countdownInterval = setInterval(() => {
    if (!state.activeSession) return;

    const expiresAt = new Date(state.activeSession.room_expires_at).getTime();
    const now = Date.now();
    const diff = expiresAt - now;

    if (diff <= 0 || state.activeSession.status === 'closed') {
      clearInterval(state.countdownInterval);
      roomCountdown.textContent = '00:00';
      qrCodeCard.classList.add('hidden');
      btnNewRoom.classList.remove('hidden');
      btnCloseSession.classList.add('hidden');
      
      // Update badge dynamically
      roomStatusBadge.textContent = 'TIEMPO EXPIRADO';
      roomStatusBadge.className = 'inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-orange-500/10 text-orange-400 border border-orange-500/20';

      // Show reopen room button if it hasn't been closed manually
      if (state.activeSession.status === 'active') {
        btnReopenRoom.classList.remove('hidden');
      }
      return;
    }

    btnReopenRoom.classList.add('hidden'); // Hide reopen if time remains
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    roomCountdown.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }, 1000);
}

// Fetch Real-time present, absent and rejections
async function fetchRealTimeAttendance() {
  if (!state.activeSession) return;

  try {
    // 1. Fetch Present
    const resP = await fetch(`${state.apiUrl}/api/sessions/${state.activeSession.id}/present`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    const presents = await resP.json();

    // 2. Fetch Absent
    const resA = await fetch(`${state.apiUrl}/api/sessions/${state.activeSession.id}/absent`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    const absents = await resA.json();

    // 3. Fetch Rejections
    const resR = await fetch(`${state.apiUrl}/api/sessions/${state.activeSession.id}/rejections`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    const rejections = await resR.json();

    // Save lists to state for offline/instant search
    state.presentsList = presents.data || [];
    state.absentsList = absents.data || [];

    renderGridFiltered();
    renderRejections(rejections.data || []);

    if (state.activeTab === 'report') {
      fetchReportData();
    }

  } catch (err) {
    console.error('Error fetching attendance details:', err);
  }
}

// Filter and render grid dynamically
function renderGridFiltered() {
  const query = state.searchQuery || '';
  
  const filteredPresents = state.presentsList.filter(p => 
    p.nombre.toLowerCase().includes(query) || p.documento.includes(query)
  );
  
  const filteredAbsents = state.absentsList.filter(a => 
    a.nombre.toLowerCase().includes(query) || a.documento.includes(query)
  );

  renderGrid(filteredPresents, filteredAbsents);
}

// Render real-time grid
function renderGrid(presents, absents) {
  attendanceGridBody.innerHTML = '';

  if (presents.length === 0) {
    attendanceGridBody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center py-8 text-slate-500">Ningún aprendiz ha registrado asistencia en esta sesión.</td>
      </tr>
    `;
    return;
  }

  // Render Presents
  presents.forEach(p => {
    let badgeClass = 'bg-green-500/10 text-green-400 border border-green-500/20';
    if (p.status === 'ASISTENCIA_PARCIAL') badgeClass = 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20';
    if (p.status === 'PRESENTE') badgeClass = 'bg-[#39A900]/20 text-[#39A900] border border-[#39A900]/30';

    attendanceGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3 px-4 font-medium text-slate-200">${p.nombre}</td>
        <td class="py-3 px-4 text-slate-400 font-mono">${p.documento}</td>
        <td class="py-3 px-4 text-slate-300 font-mono">${p.hora_ingreso_real || '-'}</td>
        <td class="py-3 px-4 text-slate-300 font-mono">${p.hora_salida_real || '-'}</td>
        <td class="py-3 px-4 text-center text-slate-300">${p.horas_validadas_asistencia} / ${p.horas_programadas_sesion}h</td>
        <td class="py-3 px-4 text-center text-xs font-mono text-slate-400">${p.tipo_registro}</td>
        <td class="py-3 px-4">
          <span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${badgeClass}">${p.status}</span>
        </td>
        <td class="py-3 px-4 text-center">
          <div class="flex items-center justify-center gap-1.5">
            <button onclick="triggerManualOverride('${p.documento}', 6, 0, 'MANUAL_OVERRIDE')" class="text-xs bg-slate-800 hover:bg-slate-700 text-[#39A900] border border-[#39A900]/20 px-2 py-1 rounded-md transition-all">
              Quitar Falla
            </button>
          </div>
        </td>
      </tr>
    `;
  });
}

function renderRejections(rejections) {
  rejectionsList.innerHTML = '';
  if (rejections.length === 0) {
    rejectionsList.innerHTML = '<div class="p-2.5 bg-slate-950/40 rounded-xl border border-slate-800/40">Sin rechazos recientes.</div>';
    return;
  }

  rejections.slice(0, 5).forEach(r => {
    const time = new Date(r.created_at).toLocaleTimeString();
    rejectionsList.innerHTML += `
      <div class="p-2.5 bg-red-950/15 rounded-xl border border-red-500/10 flex flex-col gap-0.5">
        <div class="flex justify-between font-semibold">
          <span class="text-red-400 font-mono">${r.documento}</span>
          <span class="text-[10px] text-slate-500 font-mono">${time}</span>
        </div>
        <div class="text-[11px] text-slate-300 font-medium">Motivo: <span class="font-bold text-red-300">${r.reject_reason}</span></div>
        <div class="text-[10px] text-slate-500">IP: ${r.client_ip}</div>
      </div>
    `;
  });
}

// Action triggers bound to window for onclick in HTML template
window.triggerManualOverride = async (documento, validadas, falladas, tipo) => {
  if (!state.activeSession) return;
  
  try {
    const res = await fetch(`${state.apiUrl}/attendance/manual-override`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({
        sessionId: state.activeSession.id,
        documento,
        horas_validadas_asistencia: validadas,
        horas_inasistencia_acumulada: falladas,
        tipo_registro: tipo
      })
    });

    if (res.ok) {
      fetchRealTimeAttendance();
    } else {
      const err = await res.json();
      alert(`Error: ${err.error.message}`);
    }
  } catch (err) {
    alert('Error al realizar override manual.');
  }
};

window.triggerManualLateCheckin = async (documento) => {
  if (!state.activeSession) return;

  try {
    const res = await fetch(`${state.apiUrl}/attendance/manual-checkin`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({
        sessionId: state.activeSession.id,
        documento
      })
    });

    if (res.ok) {
      fetchRealTimeAttendance();
    } else {
      const err = await res.json();
      alert(`Error: ${err.error.message}`);
    }
  } catch (err) {
    alert('Error al registrar ingreso retardado.');
  }
};

btnRefreshGrid.addEventListener('click', () => {
  fetchRealTimeAttendance();
});

// TAB VIEW CONTROLLERS
btnTabControl.addEventListener('click', () => {
  state.activeTab = 'control';
  btnTabControl.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg bg-[#39A900] text-white transition-all';
  btnTabReport.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  btnTabExcuses.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  btnTabLateRequests.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  tabContentControl.classList.remove('hidden');
  tabContentReport.classList.add('hidden');
  tabContentExcuses.classList.add('hidden');
  tabContentLateRequests.classList.add('hidden');
});

btnTabReport.addEventListener('click', () => {
  state.activeTab = 'report';
  btnTabReport.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg bg-[#39A900] text-white transition-all';
  btnTabControl.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  btnTabExcuses.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  btnTabLateRequests.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  tabContentControl.classList.add('hidden');
  tabContentReport.classList.remove('hidden');
  tabContentExcuses.classList.add('hidden');
  tabContentLateRequests.classList.add('hidden');
  fetchReportData();
});

btnTabExcuses.addEventListener('click', () => {
  state.activeTab = 'excuses';
  btnTabExcuses.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg bg-[#39A900] text-white transition-all';
  btnTabControl.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  btnTabReport.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  btnTabLateRequests.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  tabContentControl.classList.add('hidden');
  tabContentReport.classList.add('hidden');
  tabContentExcuses.classList.remove('hidden');
  tabContentLateRequests.classList.add('hidden');
  fetchInstructorExcuses();
});

btnTabLateRequests.addEventListener('click', () => {
  state.activeTab = 'lateRequests';
  btnTabLateRequests.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg bg-[#39A900] text-white transition-all';
  btnTabControl.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  btnTabReport.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  btnTabExcuses.className = 'tab-btn px-4 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all';
  tabContentControl.classList.add('hidden');
  tabContentReport.classList.add('hidden');
  tabContentExcuses.classList.add('hidden');
  tabContentLateRequests.classList.remove('hidden');
  fetchLateRequests();
});

// Report View Fetch
async function fetchReportData() {
  if (!state.activeSession) return;

  const btnPrint = document.getElementById('btnPrintReport');
  const btnPdf = document.getElementById('btnDownloadPdfReport');
  const btnEvidence = document.getElementById('btnSubmitEvidence');
  const warning = document.getElementById('reportWarning');

  try {
    const res = await fetch(`${state.apiUrl}/reports/session/${state.activeSession.id}`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const reportData = await res.json();
    if (res.ok) {
      state.lastReportData = reportData;
      renderReportGrid(reportData);

      // Enable report downloads (Excel/PDF) unconditionally once the session is loaded
      btnPrint.classList.remove('opacity-50', 'pointer-events-none');
      btnPdf.classList.remove('opacity-50', 'pointer-events-none');
      warning.classList.add('hidden');

      // Condition: Enable official evidence submission unconditionally once the session is loaded
      if (state.activeSession.evidence_submitted === 1) {
        btnEvidence.classList.add('pointer-events-none');
        btnEvidence.classList.remove('bg-blue-600', 'hover:bg-blue-700', 'opacity-50');
        btnEvidence.classList.add('bg-teal-600');
        btnEvidence.querySelector('span').textContent = 'Evidencia Entregada ✓';
      } else {
        btnEvidence.classList.remove('opacity-50', 'pointer-events-none', 'bg-teal-600');
        btnEvidence.classList.add('bg-blue-600', 'hover:bg-blue-700');
        btnEvidence.querySelector('span').textContent = 'Entregar Evidencia';
      }
    }
  } catch (err) {
    console.error('Error fetching report data:', err);
  }
}

function renderReportGrid(data) {
  reportGridBody.innerHTML = '';
  if (data.length === 0) {
    reportGridBody.innerHTML = '<tr><td colspan="7" class="text-center py-8 text-slate-500">Ningún dato disponible.</td></tr>';
    return;
  }

  data.forEach(r => {
    let pctBadge = 'bg-red-500/10 text-red-400 border border-red-500/20';
    if (r.porcentaje_asistencia >= 80) pctBadge = 'bg-green-500/10 text-green-400 border border-green-500/20';
    else if (r.porcentaje_asistencia > 0) pctBadge = 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20';

    let estadoBadge = 'bg-slate-700/50 text-slate-300';
    const estado = r.estado_llegada || r.tipo_registro || 'Inasistencia';
    if (estado === 'Temprano') {
      estadoBadge = 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20';
    } else if (estado === 'Tarde') {
      estadoBadge = 'bg-amber-500/10 text-amber-400 border border-amber-500/20';
    } else if (estado === 'Excusado') {
      estadoBadge = 'bg-blue-500/10 text-blue-400 border border-blue-500/20';
    } else if (estado === 'Excusa Pendiente') {
      estadoBadge = 'bg-purple-500/10 text-purple-400 border border-purple-500/20';
    } else if (estado === 'Inasistencia' || estado === 'FALLA_TOTAL') {
      estadoBadge = 'bg-rose-500/10 text-rose-400 border border-rose-500/20';
    }

    reportGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3.5 px-4 font-medium text-slate-200">${r.nombre}</td>
        <td class="py-3.5 px-4 text-slate-400 font-mono">${r.documento}</td>
        <td class="py-3.5 px-4 text-center font-mono">${r.horas_programadas}h</td>
        <td class="py-3.5 px-4 text-center font-mono text-green-400">${r.horas_asistidas}h</td>
        <td class="py-3.5 px-4 text-center">
          <span class="inline-flex px-2 py-0.5 rounded-full text-xs font-bold font-mono ${pctBadge}">${r.porcentaje_asistencia}%</span>
        </td>
        <td class="py-3.5 px-4 text-slate-300 font-mono text-xs">${r.hora_ingreso || '-'}</td>
        <td class="py-3.5 px-4 text-center">
          <span class="inline-flex px-2.5 py-0.5 rounded-full text-xs font-semibold ${estadoBadge}">${estado}</span>
        </td>
      </tr>
    `;
  });
}

// Download Excel report
btnPrintReport.addEventListener('click', () => {
  if (!state.lastReportData || state.lastReportData.length === 0) {
    alert('No hay datos disponibles para exportar.');
    return;
  }

  try {
    // Map JSON to Spanish Columns (Hora de Entrada only)
    const excelRows = state.lastReportData.map(r => ({
      'Aprendiz': r.nombre,
      'Documento': r.documento,
      'Horas Programadas': r.horas_programadas,
      'Horas Asistidas': r.horas_asistidas,
      '% Asistencia': r.porcentaje_asistencia + '%',
      'Hora de Entrada': r.hora_ingreso || '-',
      'Puntualidad / Estado': r.estado_llegada || r.tipo_registro || 'Inasistencia'
    }));

    // Create Excel book and sheet
    const worksheet = XLSX.utils.json_to_sheet(excelRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Asistencia');

    // Auto-adjust column widths
    const maxLens = {};
    excelRows.forEach(row => {
      Object.keys(row).forEach(key => {
        const valStr = String(row[key] || '');
        maxLens[key] = Math.max(maxLens[key] || 10, valStr.length, key.length);
      });
    });
    worksheet['!cols'] = Object.keys(maxLens).map(k => ({ wch: maxLens[k] + 2 }));

    // Download xlsx
    const filename = `Reporte_Asistencia_${state.activeSession.unit_id.replace('unit_ficha_', '')}.xlsx`;
    XLSX.writeFile(workbook, filename);
  } catch (err) {
    alert('Error al generar el archivo Excel: ' + err.message);
  }
});

// Download PDF report (SENA styled)
btnDownloadPdfReport.addEventListener('click', () => {
  if (!state.lastReportData || state.lastReportData.length === 0) {
    alert('No hay datos disponibles para exportar.');
    return;
  }

  try {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

    // Logo & Header styling (SENA Green #39A900)
    doc.setFillColor(57, 169, 0); // SENA Green
    doc.rect(0, 0, 210, 35, 'F');

    // Title
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('SENA - CONTROL DE ASISTENCIA DIGITAL', 14, 15);

    // Subtitle
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text('Centro de Formación · Reporte Consolidado de Asistencia', 14, 22);
    
    // Details Box
    doc.setFillColor(241, 245, 249);
    doc.rect(14, 42, 182, 24, 'F');

    doc.setTextColor(51, 65, 85);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text('FICHA / SECCIÓN:', 18, 48);
    doc.text('INSTRUCTOR:', 18, 54);
    doc.text('FECHA DE JORNADA:', 18, 60);

    doc.setFont('helvetica', 'normal');
    doc.text(state.activeSession.unit_id.replace('unit_ficha_', ''), 60, 48);
    doc.text(state.person.nombre, 60, 54);
    
    const dateStr = state.activeSession.activated_at 
      ? new Date(state.activeSession.activated_at).toLocaleDateString('es-CO', { dateStyle: 'long' }) 
      : 'No disponible';
    doc.text(dateStr, 60, 60);

    // Map table rows (Without Hora Salida)
    const tableRows = state.lastReportData.map((r, index) => [
      index + 1,
      r.nombre,
      r.documento,
      `${r.horas_programadas}h`,
      `${r.horas_asistidas}h`,
      `${r.porcentaje_asistencia}%`,
      r.hora_ingreso || '-',
      r.estado_llegada || r.tipo_registro || 'Inasistencia'
    ]);

    // Draw AutoTable
    doc.autoTable({
      startY: 72,
      head: [['#', 'Aprendiz', 'Documento', 'Prog.', 'Asist.', '% Jornada', 'Hora Entrada', 'Estado']],
      body: tableRows,
      theme: 'grid',
      headStyles: {
        fillColor: [57, 169, 0],
        textColor: [255, 255, 255],
        fontSize: 8.5,
        fontStyle: 'bold'
      },
      bodyStyles: {
        fontSize: 8,
        textColor: [30, 41, 59]
      },
      columnStyles: {
        0: { width: 8 },
        3: { halign: 'center' },
        4: { halign: 'center' },
        5: { halign: 'center' },
        6: { halign: 'center' },
        7: { halign: 'center' }
      },
      margin: { left: 14, right: 14 }
    });

    const finalY = doc.lastAutoTable.finalY || 100;
    
    // Signatures layout
    if (finalY + 45 < 297) {
      doc.setDrawColor(203, 213, 225);
      doc.line(20, finalY + 30, 85, finalY + 30);
      doc.line(125, finalY + 30, 190, finalY + 30);

      doc.setTextColor(100, 116, 139);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text('Firma del Instructor', 40, finalY + 34);
      doc.text('Firma del Coordinador', 145, finalY + 34);
    }

    // Save PDF
    const filename = `Reporte_Asistencia_${state.activeSession.unit_id.replace('unit_ficha_', '')}.pdf`;
    doc.save(filename);
  } catch (err) {
    alert('Error al generar el reporte PDF: ' + err.message);
  }
});

// Submit session evidence (Instructor via Native File Explorer)
btnSubmitEvidence.addEventListener('click', () => {
  if (!state.activeSession) return;
  if (state.activeSession.evidence_submitted === 1) {
    alert('La evidencia de esta jornada ya ha sido entregada.');
    return;
  }
  const fileInput = document.getElementById('evidenceFileInput');
  if (fileInput) {
    fileInput.click();
  }
});

const evidenceFileInput = document.getElementById('evidenceFileInput');
if (evidenceFileInput) {
  evidenceFileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file || !state.activeSession) return;

    // Validate size (max 10MB)
    const MAX_SIZE = 10 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      alert(`El archivo supera el tamaño máximo permitido de 10 MB (${(file.size / (1024 * 1024)).toFixed(2)} MB).`);
      evidenceFileInput.value = '';
      return;
    }

    // Validate extension (.xlsx, .xls, .pdf)
    const allowedExts = ['.xlsx', '.xls', '.pdf'];
    const fileNameLower = file.name.toLowerCase();
    const isAllowed = allowedExts.some(ext => fileNameLower.endsWith(ext));
    if (!isAllowed) {
      alert('Formato no permitido. Solo se aceptan archivos de tipo Excel (.xlsx, .xls) o PDF (.pdf).');
      evidenceFileInput.value = '';
      return;
    }

    const confirmMsg = `¿Deseas adjuntar y entregar el archivo "${file.name}" (${(file.size / 1024).toFixed(1)} KB) como evidencia oficial al Coordinador? Esta acción no se puede deshacer.`;
    if (!confirm(confirmMsg)) {
      evidenceFileInput.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const fileData = reader.result; // DataURL (Base64)
        const res = await fetch(`${state.apiUrl}/api/sessions/${state.activeSession.id}/evidence`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${state.token}`
          },
          body: JSON.stringify({
            fileName: file.name,
            fileData,
            fileSize: file.size,
            mimeType: file.type || 'application/octet-stream'
          })
        });
        if (handleAuthError(res)) return;

        const result = await res.json();
        if (res.ok) {
          alert('¡Evidencia adjuntada y radicada ante Coordinación con éxito!');
          state.activeSession.evidence_submitted = 1;
          fetchReportData();
        } else {
          alert(`Error al entregar evidencia: ${result.error?.message || 'Error desconocido'}`);
        }
      } catch (err) {
        alert('Error de red al subir la evidencia.');
      } finally {
        evidenceFileInput.value = '';
      }
    };
    reader.onerror = () => {
      alert('Error al leer el archivo seleccionado.');
      evidenceFileInput.value = '';
    };
    reader.readAsDataURL(file);
  });
}

// Create new session flow
btnNewRoom.addEventListener('click', () => {
  state.activeSession = null;
  stopSessionPolling();
  updateControllerView();
  
  // Reset grids
  attendanceGridBody.innerHTML = `
    <tr>
      <td colspan="8" class="text-center py-8 text-slate-500">Seleccione una Ficha e inicie la sesión de clase.</td>
    </tr>
  `;
  reportGridBody.innerHTML = `
    <tr>
      <td colspan="8" class="text-center py-8 text-slate-500">Inicie la sesión para consolidar el reporte.</td>
    </tr>
  `;
});

// --- STUDENT PORTAL LOGIC ---
async function fetchStudentHistory() {
  try {
    const res = await fetch(`${state.apiUrl}/api/student/history`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok && result.data) {
      state.studentHistory = result.data.history || [];
      state.studentExcuses = result.data.excuses || [];
      renderStudentHistoryGrid(result.data.history);
      renderStudentExcuses(result.data.excuses);
    } else {
      console.error('Error fetching student history:', result.error?.message);
    }
  } catch (err) {
    console.error('Error in student history fetch:', err);
  }
}

function renderStudentHistoryGrid(history) {
  studentHistoryGridBody.innerHTML = '';
  
  if (!history || history.length === 0) {
    studentFichaName.textContent = 'Sin Ficha Matriculada';
    studentTotalHours.textContent = '0h';
    studentHistoryGridBody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center py-8 text-slate-500">No hay clases registradas en tu ficha académica.</td>
      </tr>
    `;
    return;
  }

  // Update header info
  const first = history[0];
  studentFichaName.textContent = `Ficha ${first.unitCode} - ${first.unitName}`;

  let totalProg = 0;
  let totalAsis = 0;

  history.forEach(h => {
    totalProg += h.horas_programadas;
    totalAsis += h.horas_asistidas;

    // Badges based on status
    let badgeClass = 'bg-red-500/10 text-red-400 border border-red-500/20';
    if (h.status === 'PRESENTE') {
      badgeClass = h.tipo_registro === 'EXCUSA_APROBADA'
        ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
        : 'bg-green-500/10 text-green-400 border border-green-500/20';
    } else if (h.status === 'ASISTENCIA_PARCIAL') {
      badgeClass = 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20';
    }

    // Excuse button or state
    let excuseCol = '-';
    if (h.horas_falla > 0 || h.excuse) {
      if (h.excuse) {
        if (h.excuse.status === 'pending') {
          excuseCol = `<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">Excusa Pendiente</span>`;
        } else if (h.excuse.status === 'approved') {
          excuseCol = `<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold bg-green-500/10 text-green-400 border border-green-500/20">Excusa Aprobada</span>`;
        } else {
          excuseCol = `<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold bg-red-500/10 text-red-400 border border-red-500/20">Excusa Rechazada</span>`;
        }
      } else {
        excuseCol = `
          <button onclick="openExcuseModal('${h.sessionId}')" class="text-xs bg-blue-950/20 hover:bg-blue-950/40 border border-blue-500/20 text-blue-400 px-2 py-1 rounded-md transition-all">
            Subir Excusa
          </button>
        `;
      }
    }

    studentHistoryGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3 px-4 font-mono text-xs">${h.date}</td>
        <td class="py-3 px-4 text-xs font-semibold text-slate-400">${h.unitCode}</td>
        <td class="py-3 px-4 font-mono text-xs">${h.hora_ingreso}</td>
        <td class="py-3 px-4 font-mono text-xs">${h.hora_salida}</td>
        <td class="py-3 px-4 text-center font-mono text-green-400">${h.horas_asistidas}h</td>
        <td class="py-3 px-4">
          <span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${badgeClass}">${h.tipo_registro}</span>
        </td>
        <td class="py-3 px-4 text-center">${excuseCol}</td>
      </tr>
    `;
  });

  studentTotalHours.textContent = `${totalAsis}h`;
}

// Populate Excuse Sessions Select helper
function populateExcuseSessions(selectedSessionId) {
  if (!excuseSessionSelect) return;
  excuseSessionSelect.innerHTML = '<option value="">-- Selecciona una clase o sesión --</option>';

  const sessions = state.studentHistory || [];
  if (sessions.length === 0) {
    excuseSessionSelect.innerHTML = '<option value="">No hay sesiones registradas en tu ficha</option>';
    return;
  }

  sessions.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.sessionId;
    const sessionDate = s.date || 'Sin fecha';
    const statusText = s.tipo_registro || s.status || 'FALLA';
    const hoursText = s.horas_falla ? `${s.horas_falla}h inasistencia` : 'Jornada regular';
    opt.textContent = `${sessionDate} - Ficha ${s.unitCode} (${statusText} | ${hoursText})`;
    if (selectedSessionId && s.sessionId === selectedSessionId) {
      opt.selected = true;
    }
    excuseSessionSelect.appendChild(opt);
  });

  if (selectedSessionId) {
    excuseSessionSelect.value = selectedSessionId;
    if (excuseSessionId) excuseSessionId.value = selectedSessionId;
  } else if (sessions.length === 1) {
    excuseSessionSelect.value = sessions[0].sessionId;
    if (excuseSessionId) excuseSessionId.value = sessions[0].sessionId;
  }
}

if (excuseSessionSelect) {
  excuseSessionSelect.addEventListener('change', () => {
    if (excuseSessionId) excuseSessionId.value = excuseSessionSelect.value;
  });
}

// Excuse upload modal helpers
window.openExcuseModal = (sessionId) => {
  populateExcuseSessions(sessionId);
  if (excuseSessionId) excuseSessionId.value = sessionId;
  if (excuseSessionSelect) excuseSessionSelect.value = sessionId;
  if (excuseText) excuseText.value = '';
  if (excuseFile) excuseFile.value = '';
  excuseModal.classList.remove('hidden');
};

btnCancelExcuse.addEventListener('click', () => {
  excuseModal.classList.add('hidden');
});

btnRefreshStudent.addEventListener('click', () => {
  fetchStudentHistory();
});

excuseForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const sessionId = (excuseSessionSelect?.value || excuseSessionId?.value || '').trim();
  const text = excuseText.value.trim();
  const file = excuseFile.files[0];

  if (!sessionId) {
    alert('Por favor selecciona la clase o sesión a la cual deseas radicar la excusa.');
    return;
  }

  if (!text) {
    alert('Por favor ingresa la descripción o motivo de la justificación.');
    return;
  }

  let fileName = null;
  let fileData = null;

  if (file) {
    fileName = file.name;
    const reader = new FileReader();
    reader.onload = async () => {
      fileData = reader.result;
      await sendExcuse(sessionId, text, fileName, fileData);
    };
    reader.readAsDataURL(file);
  } else {
    await sendExcuse(sessionId, text, null, null);
  }
});

async function sendExcuse(sessionId, text, fileName, fileData) {
  const submitBtn = excuseForm.querySelector('button[type="submit"]');
  const originalHtml = submitBtn ? submitBtn.innerHTML : '<span>Enviar Excusa</span>';
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span>Enviando excusa...</span>';
  }

  try {
    const res = await fetch(`${state.apiUrl}/api/student/excuses`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({ sessionId, text, fileName, fileData })
    });
    const result = await res.json();
    if (res.ok) {
      alert('¡Excusa radicada exitosamente! Tu instructor podrá verla y resolverla desde su bandeja de excusas.');
      excuseModal.classList.add('hidden');
      await fetchStudentHistory();
    } else {
      alert(`Error: ${result.error?.message || 'No se pudo radicar la excusa.'}`);
    }
  } catch (err) {
    alert('Error de red al presentar la excusa.');
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = originalHtml;
    }
  }
}

function renderStudentExcuses(excuses) {
  if (!studentExcusesGridBody) return;
  studentExcusesGridBody.innerHTML = '';

  const badgeStudentExcuses = document.getElementById('badgeStudentExcuses');
  const studentExcusesNotice = document.getElementById('studentExcusesNotice');

  if (!excuses || excuses.length === 0) {
    if (badgeStudentExcuses) badgeStudentExcuses.classList.add('hidden');
    if (studentExcusesNotice) studentExcusesNotice.classList.add('hidden');
    studentExcusesGridBody.innerHTML = `
      <tr>
        <td colspan="5" class="text-center py-8 text-slate-500">No has radicado ninguna justificación aún.</td>
      </tr>
    `;
    return;
  }

  const rejectedCount = excuses.filter(e => e.status === 'rejected').length;
  const approvedCount = excuses.filter(e => e.status === 'approved').length;
  const pendingCount = excuses.filter(e => e.status === 'pending').length;

  if (badgeStudentExcuses) {
    if (rejectedCount > 0) {
      badgeStudentExcuses.textContent = `${rejectedCount} Rechazada${rejectedCount > 1 ? 's' : ''}`;
      badgeStudentExcuses.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/30';
      badgeStudentExcuses.classList.remove('hidden');
    } else if (pendingCount > 0) {
      badgeStudentExcuses.textContent = `${pendingCount} Pendiente${pendingCount > 1 ? 's' : ''}`;
      badgeStudentExcuses.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold bg-yellow-500/20 text-yellow-400 border border-yellow-500/30';
      badgeStudentExcuses.classList.remove('hidden');
    } else if (approvedCount > 0) {
      badgeStudentExcuses.textContent = `${approvedCount} Aprobada${approvedCount > 1 ? 's' : ''}`;
      badgeStudentExcuses.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-500/20 text-green-400 border border-green-500/30';
      badgeStudentExcuses.classList.remove('hidden');
    } else {
      badgeStudentExcuses.classList.add('hidden');
    }
  }

  if (studentExcusesNotice) {
    if (rejectedCount > 0) {
      studentExcusesNotice.className = 'p-3.5 rounded-2xl text-xs flex items-center gap-3 bg-red-500/10 text-red-300 border border-red-500/30';
      studentExcusesNotice.innerHTML = `
        <svg class="w-5 h-5 text-red-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
        <div>
          <strong class="text-white">Aviso de Novedad:</strong> Tu instructor ha <strong class="text-red-400 font-bold">RECHAZADO ${rejectedCount} justificación(es)</strong> radicada(s). Revisa el detalle de las clases en la tabla para más información.
        </div>
      `;
      studentExcusesNotice.classList.remove('hidden');
    } else if (approvedCount > 0 && pendingCount === 0) {
      studentExcusesNotice.className = 'p-3.5 rounded-2xl text-xs flex items-center gap-3 bg-green-500/10 text-green-300 border border-green-500/30';
      studentExcusesNotice.innerHTML = `
        <svg class="w-5 h-5 text-green-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <div>
          <strong class="text-white">Al día:</strong> Todas tus justificaciones han sido <strong class="text-green-400">APROBADAS</strong> y tus horas formativas fueron convalidadas.
        </div>
      `;
      studentExcusesNotice.classList.remove('hidden');
    } else {
      studentExcusesNotice.classList.add('hidden');
    }
  }

  excuses.forEach(e => {
    let statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">PENDIENTE</span>';
    if (e.status === 'approved') {
      statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-green-500/10 text-green-400 border border-green-500/20">APROBADA</span>';
    } else if (e.status === 'rejected') {
      statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-500/10 text-red-400 border border-red-500/20">RECHAZADA</span>';
    }

    let supportLink = '<span class="text-slate-500 text-xs">Sin soporte</span>';
    if (e.file_data) {
      supportLink = `
        <a href="${e.file_data}" download="${e.file_name || 'soporte'}" class="text-xs text-[#39A900] hover:underline font-semibold inline-flex items-center gap-1">
          <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
          <span>Descargar</span>
        </a>
      `;
    }

    let radicadoAt = '-';
    if (e.created_at) {
      try {
        radicadoAt = new Date(e.created_at).toLocaleString('es-CO', { dateStyle: 'short', timeStyle: 'short' });
      } catch (err) {
        radicadoAt = e.created_at.split('T')[0];
      }
    }

    const fechaSesion = e.session_date ? e.session_date.split('T')[0] : (e.session_id ? e.session_id.substring(0, 10) : '-');

    const safeFechaSesion = escapeHtml(fechaSesion);
    const safeText = escapeHtml(e.text || '-');
    const safeRadicadoAt = escapeHtml(radicadoAt);
    studentExcusesGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3 px-4 font-mono text-xs text-slate-300 font-semibold">${safeFechaSesion}</td>
        <td class="py-3 px-4 text-xs text-slate-200 max-w-xs truncate" title="${safeText}">${safeText}</td>
        <td class="py-3 px-4">${supportLink}</td>
        <td class="py-3 px-4">${statusBadge}</td>
        <td class="py-3 px-4 font-mono text-xs text-slate-400">${safeRadicadoAt}</td>
      </tr>
    `;
  });
}

async function handleDeleteStudentAccount() {
  const confirmed = confirm(
    "¿ESTÁS SEGURO DE QUE DESEAS SUPRIMIR TU CUENTA?\\n\\nDe acuerdo con la Ley Estatutaria 1581 de 2012 (Habeas Data), tus datos personales (nombre, documento, correo) serán disociados y anonimizados permanentemente en la base de datos.\\n\\nEsta acción es irreversible y cerrará tu acceso al sistema."
  );
  if (!confirmed) return;

  try {
    const res = await fetch(`${state.apiUrl}/api/student/delete-account`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${state.token}`
      }
    });
    const result = await res.json();
    if (res.ok) {
      alert(result.data?.message || 'Cuenta y datos personales anonimizados con éxito.');
      state.token = '';
      state.person = null;
      localStorage.removeItem('token');
      localStorage.removeItem('person');
      showPortal();
    } else {
      alert(`Error: ${result.error?.message || 'No se pudo eliminar la cuenta.'}`);
    }
  } catch (err) {
    alert('Error de conexión al solicitar la supresión de cuenta.');
  }
}

// --- INSTRUCTOR EXCUSES LOGIC ---
async function fetchInstructorExcuses() {
  try {
    const unitQuery = state.activeSession?.unit_id ? `?unitId=${encodeURIComponent(state.activeSession.unit_id)}` : '';
    const res = await fetch(`${state.apiUrl}/api/instructor/excuses${unitQuery}`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok) {
      renderInstructorExcusesGrid(result.data);
    }
  } catch (err) {
    console.error('Error fetching instructor excuses:', err);
  }
}

function renderInstructorExcusesGrid(excuses) {
  instructorExcusesGridBody.innerHTML = '';
  
  if (!excuses || excuses.length === 0) {
    instructorExcusesGridBody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center py-8 text-slate-500">No hay excusas registradas.</td>
      </tr>
    `;
    return;
  }

  excuses.forEach(e => {
    let supportCol = '<span class="text-slate-600">Sin soporte</span>';
    if (e.file_data && isSafeDataOrHttpUrl(e.file_data)) {
      supportCol = `
        <a href="${escapeHtml(e.file_data)}" download="${escapeHtml(e.file_name || 'soporte')}" class="inline-flex items-center gap-1 text-xs text-[#39A900] hover:underline font-semibold">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
          <span>Descargar</span>
        </a>
      `;
    }

    let statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">PENDIENTE</span>';
    if (e.status === 'approved') {
      statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-green-500/10 text-green-400 border border-green-500/20">APROBADA</span>';
    } else if (e.status === 'rejected') {
      statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-500/10 text-red-400 border border-red-500/20">RECHAZADA</span>';
    }

    let actionsCol = '-';
    if (e.status === 'pending') {
      const safeId = escapeHtml(e.id);
      actionsCol = `
        <div class="flex items-center justify-center gap-1.5">
          <button onclick="resolveExcuse('${safeId}', 'approved')" class="text-xs bg-[#39A900]/15 hover:bg-[#39A900]/25 border border-[#39A900]/20 text-[#39A900] px-2 py-1 rounded-md transition-all font-semibold">
            Aprobar
          </button>
          <button onclick="resolveExcuse('${safeId}', 'rejected')" class="text-xs bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 px-2 py-1 rounded-md transition-all font-semibold">
            Rechazar
          </button>
        </div>
      `;
    }

    const sessionDate = escapeHtml((e.room_created_at || e.created_at || '').split('T')[0] || '-');
    const safeStudentName = escapeHtml(e.student_name);
    const safeStudentDoc = escapeHtml(e.student_doc);
    const safeUnitCode = escapeHtml(e.unit_code);
    const safeExcuseText = escapeHtml(e.text);

    instructorExcusesGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3 px-4">
          <div class="font-medium text-slate-200">${safeStudentName}</div>
          <div class="text-[10px] text-slate-500 font-mono">${safeStudentDoc}</div>
        </td>
        <td class="py-3 px-4 text-xs font-semibold text-slate-400">${safeUnitCode}</td>
        <td class="py-3 px-4 font-mono text-xs">${sessionDate}</td>
        <td class="py-3 px-4 text-xs max-w-xs truncate" title="${safeExcuseText}">${safeExcuseText}</td>
        <td class="py-3 px-4">${supportCol}</td>
        <td class="py-3 px-4">${statusBadge}</td>
        <td class="py-3 px-4 text-center">${actionsCol}</td>
      </tr>
    `;
  });
}

if (btnRefreshInstructorExcuses) {
  btnRefreshInstructorExcuses.addEventListener('click', fetchInstructorExcuses);
}

window.resolveExcuse = async (id, status) => {
  const confirmMsg = status === 'approved' 
    ? '¿Aprobar esta excusa? Esto marcará al estudiante como PRESENTE (6 horas asistidas) de forma retroactiva.'
    : '¿Rechazar esta excusa? La inasistencia permanecerá en el sistema.';
    
  if (!confirm(confirmMsg)) return;

  try {
    const res = await fetch(`${state.apiUrl}/api/instructor/excuses/${id}/resolve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({ status })
    });
    const result = await res.json();
    if (res.ok) {
      alert(`Excusa procesada correctamente.`);
      fetchInstructorExcuses();
    } else {
      alert(`Error: ${result.error.message}`);
    }
  } catch (err) {
    alert('Error al resolver excusa.');
  }
};

// --- LATE REQUESTS LOGIC ---
async function fetchLateRequests() {
  lateRequestsLoading.classList.remove('hidden');
  lateRequestsGridBody.innerHTML = '';
  try {
    const res = await fetch(`${state.apiUrl}/api/instructor/late-requests`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok) {
      renderLateRequests(result.data);
    } else {
      console.error('Error fetching late requests:', result.error.message);
      lateRequestsGridBody.innerHTML = `<tr><td colspan="7" class="text-center py-8 text-red-400">Error al cargar solicitudes.</td></tr>`;
    }
  } catch (err) {
    console.error('Error fetching late requests:', err);
    lateRequestsGridBody.innerHTML = `<tr><td colspan="7" class="text-center py-8 text-red-400">Error de conexión.</td></tr>`;
  } finally {
    lateRequestsLoading.classList.add('hidden');
  }
}

function renderLateRequests(requests) {
  lateRequestsGridBody.innerHTML = '';

  if (!requests || requests.length === 0) {
    lateRequestsGridBody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center py-8 text-slate-500">No hay solicitudes tardías pendientes.</td>
      </tr>
    `;
    return;
  }

  requests.forEach(r => {
    let statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">PENDIENTE</span>';
    if (r.status === 'approved') {
      statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-green-500/10 text-green-400 border border-green-500/20">APROBADA</span>';
    } else if (r.status === 'rejected') {
      statusBadge = '<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-500/10 text-red-400 border border-red-500/20">RECHAZADA</span>';
    }

    let actionsCol = '-';
    if (r.status === 'pending') {
      actionsCol = `
        <div class="flex items-center justify-center gap-1.5">
          <select id="lateHoras_${r.id}" class="bg-slate-900 border border-slate-800 rounded-md px-2 py-1 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-[#39A900]">
            <option value="1">1h</option>
            <option value="2">2h</option>
            <option value="3">3h</option>
            <option value="4">4h</option>
            <option value="5">5h</option>
          </select>
          <button onclick="resolveLateRequest('${r.id}', 'approved')" class="text-xs bg-[#39A900]/15 hover:bg-[#39A900]/25 border border-[#39A900]/20 text-[#39A900] px-2 py-1 rounded-md transition-all font-semibold">
            Aprobar
          </button>
          <button onclick="resolveLateRequest('${r.id}', 'rejected')" class="text-xs bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 px-2 py-1 rounded-md transition-all font-semibold">
            Rechazar
          </button>
        </div>
      `;
    }

    const sentAt = r.created_at ? new Date(r.created_at).toLocaleString('es-CO') : '-';

    lateRequestsGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3 px-4 font-medium text-slate-200">${r.student_name || '-'}</td>
        <td class="py-3 px-4 text-slate-400 font-mono">${r.student_doc || '-'}</td>
        <td class="py-3 px-4 text-xs font-semibold text-slate-400">${r.unit_code || '-'}</td>
        <td class="py-3 px-4 font-mono text-xs">${sentAt}</td>
        <td class="py-3 px-4 text-xs max-w-xs truncate" title="${r.justification || ''}">${r.justification || '-'}</td>
        <td class="py-3 px-4">${statusBadge}</td>
        <td class="py-3 px-4 text-center">${actionsCol}</td>
      </tr>
    `;
  });
}

window.resolveLateRequest = async (id, status) => {
  const horasSelect = document.getElementById(`lateHoras_${id}`);
  const horasDescontar = horasSelect ? parseInt(horasSelect.value) : 1;

  const confirmMsg = status === 'approved'
    ? `¿Aprobar solicitud tardía descontando ${horasDescontar} hora(s)?`
    : '¿Rechazar esta solicitud tardía? La inasistencia permanecerá en el sistema.';

  if (!confirm(confirmMsg)) return;

  try {
    const res = await fetch(`${state.apiUrl}/api/instructor/late-requests/${id}/resolve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({ status, horasDescontar })
    });
    const result = await res.json();
    if (res.ok) {
      alert('Solicitud tardía procesada correctamente.');
      fetchLateRequests();
    } else {
      alert(`Error: ${result.error.message}`);
    }
  } catch (err) {
    alert('Error al resolver la solicitud tardía.');
  }
};

// --- BIOMETRICS EXCEPTIONS (DEPRECATED & REMOVED PER USER REQUIREMENT) ---

window.viewPhotoInModal = (src, title) => {
  let modal = document.getElementById('photo-preview-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'photo-preview-modal';
    modal.className = 'fixed inset-0 bg-black/95 z-[9999] flex flex-col items-center justify-center p-4 backdrop-blur-sm';
    modal.innerHTML = `
      <div class="relative max-w-lg w-full flex flex-col gap-4">
        <h4 id="photo-modal-title" class="text-sm font-bold text-white text-center"></h4>
        <img id="photo-modal-img" src="" class="w-full max-h-[70vh] object-contain rounded-2xl border border-slate-800">
        <button onclick="document.getElementById('photo-preview-modal').classList.add('hidden')" class="bg-slate-800 hover:bg-slate-700 text-white font-semibold py-2 px-6 rounded-xl text-xs transition-all mx-auto block">Cerrar Vista</button>
      </div>
    `;
    document.body.appendChild(modal);
  }
  document.getElementById('photo-modal-title').textContent = title;
  document.getElementById('photo-modal-img').src = src;
  modal.classList.remove('hidden');
};

// Search Filter Listener
searchStudentInput.addEventListener('input', (e) => {
  state.searchQuery = e.target.value.toLowerCase().trim();
  renderGridFiltered();
});

// Bulk Attendance Trigger
btnBulkMarkPresent.addEventListener('click', async () => {
  if (!state.activeSession) {
    alert('No hay ninguna sesión activa para marcar asistencia.');
    return;
  }
  const absents = state.absentsList || [];
  if (absents.length === 0) {
    alert('No hay aprendices ausentes por marcar en la grilla.');
    return;
  }

  const confirmMsg = `¿Desea registrar asistencia manual rápida (PRESENTE - 6h) para los ${absents.length} aprendices ausentes?`;
  if (!confirm(confirmMsg)) return;

  btnBulkMarkPresent.disabled = true;
  const originalText = btnBulkMarkPresent.textContent;
  btnBulkMarkPresent.textContent = 'Procesando...';

  try {
    const promises = absents.map(a => 
      fetch(`${state.apiUrl}/attendance/manual-override`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${state.token}`
        },
        body: JSON.stringify({
          sessionId: state.activeSession.id,
          documento: a.documento,
          horas_validadas_asistencia: 6,
          horas_inasistencia_acumulada: 0,
          tipo_registro: 'MANUAL_OVERRIDE'
        })
      })
    );

    await Promise.all(promises);
    alert('Se marcó asistencia completa para todos los aprendices ausentes.');
    fetchRealTimeAttendance();
  } catch (err) {
    alert('Error al realizar el marcado masivo de asistencia.');
    console.error(err);
  } finally {
    btnBulkMarkPresent.disabled = false;
    btnBulkMarkPresent.textContent = originalText;
  }
});

// ── COORDINATOR FUNCTIONS ─────────────────────────────────────────────────────

async function fetchCoordInstructors() {
  coordInstructorsGridBody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-slate-500">Cargando instructores...</td></tr>';
  try {
    const res = await fetch(`${state.apiUrl}/api/coord/instructors`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok) {
      state.coordInstructorsList = result.data || [];
      renderCoordInstructors(result.data);
    } else {
      coordInstructorsGridBody.innerHTML = `<tr><td colspan="5" class="text-center py-8 text-red-400">Error: ${result.error.message}</td></tr>`;
    }
  } catch (err) {
    coordInstructorsGridBody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-red-400">Error de conexión.</td></tr>';
  }
}

function renderCoordInstructors(instructors) {
  coordInstructorsGridBody.innerHTML = '';
  if (!instructors || instructors.length === 0) {
    coordInstructorsGridBody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-slate-500">No hay instructores registrados.</td></tr>';
    return;
  }

  instructors.forEach(inst => {
    const statusText = inst.active 
      ? '<span class="inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider bg-green-500/10 text-green-400 border border-green-500/20">ACTIVO</span>'
      : '<span class="inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider bg-red-500/10 text-red-400 border border-red-500/20">INACTIVO</span>';

    const toggleText = inst.active ? 'Desactivar' : 'Activar';

    let fichasBadges = '<span class="text-xs text-slate-500 italic">Sin fichas</span>';
    if (inst.assigned_units && inst.assigned_units.length > 0) {
      fichasBadges = `
        <div class="flex flex-wrap gap-1 max-w-xs">
          ${inst.assigned_units.map(u => `<span class="inline-flex px-2 py-0.5 rounded-md text-[11px] font-mono font-bold bg-[#39A900]/15 text-[#39A900] border border-[#39A900]/25" title="${u.name || ''}">${u.code}</span>`).join('')}
        </div>
      `;
    }

    coordInstructorsGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3 px-4 font-semibold text-slate-200">${inst.nombre}</td>
        <td class="py-3 px-4 font-mono text-slate-400">${inst.documento}</td>
        <td class="py-3 px-4">${fichasBadges}</td>
        <td class="py-3 px-4">${statusText}</td>
        <td class="py-3 px-4 text-right">
          <div class="flex justify-end gap-1.5 flex-wrap">
            <button onclick="window.openAssignFichasModal('${inst.id}', '${inst.nombre.replace(/'/g, "\\'")}')" class="text-xs bg-[#39A900]/15 border border-[#39A900]/30 hover:bg-[#39A900]/25 text-[#39A900] px-2.5 py-1 rounded-md transition-all font-semibold">
              Asignar Fichas
            </button>
            <button onclick="editInstructor('${inst.id}', '${inst.nombre.replace(/'/g, "\\'")}', '${inst.documento}', ${inst.active})" class="text-xs bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md transition-all">
              Editar
            </button>
            <button onclick="toggleInstructorActive('${inst.id}', '${inst.nombre.replace(/'/g, "\\'")}', ${inst.active})" class="text-xs bg-slate-900 border border-slate-800 hover:bg-slate-800 text-red-400 px-2.5 py-1 rounded-md transition-all">
              ${toggleText}
            </button>
          </div>
        </td>
      </tr>
    `;
  });
}

// --- MODAL ASIGNAR FICHAS A INSTRUCTOR ---
window.openAssignFichasModal = async (instructorId, instructorName) => {
  const modal = document.getElementById('assignFichasModal');
  const title = document.getElementById('assignFichasModalTitle');
  const listEl = document.getElementById('assignFichasList');
  const inputId = document.getElementById('assignInstructorId');
  const countEl = document.getElementById('assignFichasCount');

  if (!modal || !listEl) return;

  inputId.value = instructorId;
  title.textContent = `Asignar Fichas: ${instructorName}`;
  listEl.innerHTML = '<div class="text-center py-6 text-slate-500 text-xs">Cargando fichas del centro...</div>';
  modal.classList.remove('hidden');

  try {
    // 1. Fetch all fichas
    const resFichas = await fetch(`${state.apiUrl}/api/coord/fichas`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    const fichasData = await resFichas.json();
    const allFichas = fichasData.data || [];

    // 2. Find instructor in cached list or fetch current assignments
    const inst = (state.coordInstructorsList || []).find(i => i.id === instructorId);
    const assignedIds = new Set((inst?.assigned_units || []).map(u => u.id));

    if (allFichas.length === 0) {
      listEl.innerHTML = '<div class="text-center py-6 text-slate-500 text-xs">No hay fichas registradas en el centro.</div>';
      if (countEl) countEl.textContent = '0 seleccionadas';
      return;
    }

    const updateCount = () => {
      const checkedCount = listEl.querySelectorAll('.ficha-assign-cb:checked').length;
      if (countEl) countEl.textContent = `${checkedCount} seleccionada${checkedCount === 1 ? '' : 's'}`;
    };

    listEl.innerHTML = allFichas.map(f => {
      const isChecked = assignedIds.has(f.id);
      return `
        <label class="flex items-center gap-3 p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-all">
          <input type="checkbox" value="${f.id}" class="ficha-assign-cb rounded bg-slate-800 border-slate-700 text-[#39A900] focus:ring-[#39A900] w-4 h-4 cursor-pointer" ${isChecked ? 'checked' : ''}>
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2">
              <span class="text-xs font-bold font-mono text-white">${f.code}</span>
              <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${f.active ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}">${f.jornada || 'DIURNA'}</span>
            </div>
            <div class="text-[11px] text-slate-400 truncate mt-0.5">${f.name}</div>
          </div>
        </label>
      `;
    }).join('');

    updateCount();
    listEl.querySelectorAll('.ficha-assign-cb').forEach(cb => {
      cb.addEventListener('change', updateCount);
    });

  } catch (err) {
    listEl.innerHTML = '<div class="text-center py-6 text-red-400 text-xs">Error al cargar las fichas disponibles.</div>';
  }
};

const btnCloseAssignFichasModal = document.getElementById('btnCloseAssignFichasModal');
const btnCancelAssignFichas = document.getElementById('btnCancelAssignFichas');
const btnSaveAssignFichas = document.getElementById('btnSaveAssignFichas');
const assignFichasModal = document.getElementById('assignFichasModal');

const closeAssignModal = () => {
  if (assignFichasModal) assignFichasModal.classList.add('hidden');
};

if (btnCloseAssignFichasModal) btnCloseAssignFichasModal.addEventListener('click', closeAssignModal);
if (btnCancelAssignFichas) btnCancelAssignFichas.addEventListener('click', closeAssignModal);

if (btnSaveAssignFichas) {
  btnSaveAssignFichas.addEventListener('click', async () => {
    const inputId = document.getElementById('assignInstructorId');
    const instructorId = inputId ? inputId.value : null;
    if (!instructorId) return;

    const listEl = document.getElementById('assignFichasList');
    const checked = Array.from(listEl.querySelectorAll('.ficha-assign-cb:checked')).map(cb => cb.value);

    btnSaveAssignFichas.disabled = true;
    const btnSpan = btnSaveAssignFichas.querySelector('span');
    const origText = btnSpan ? btnSpan.textContent : '';
    if (btnSpan) btnSpan.textContent = 'Guardando...';

    try {
      const res = await fetch(`${state.apiUrl}/api/coord/instructors/${instructorId}/units`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${state.token}`
        },
        body: JSON.stringify({ unitIds: checked })
      });
      if (handleAuthError(res)) return;

      const result = await res.json();
      if (res.ok) {
        alert(result.data?.message || 'Fichas asignadas correctamente al instructor.');
        closeAssignModal();
        fetchCoordInstructors();
      } else {
        alert(`Error: ${result.error?.message || 'No se pudieron asignar las fichas'}`);
      }
    } catch (err) {
      alert('Error de red al guardar las asignaciones.');
    } finally {
      btnSaveAssignFichas.disabled = false;
      if (btnSpan) btnSpan.textContent = origText || 'Guardar Asignaciones';
    }
  });
}

async function handleInstructorSubmit(e) {
  e.preventDefault();
  const id = instructorEditId.value;
  const nombre = instNombre.value.trim();
  const documento = instDocumento.value.trim();
  const password = instPassword.value.trim();
  const active = instActive.checked;

  const url = id 
    ? `${state.apiUrl}/api/coord/instructors/${id}`
    : `${state.apiUrl}/api/coord/instructors`;

  const method = id ? 'PUT' : 'POST';
  const bodyData = { nombre, documento };
  if (password) bodyData.password = password;
  if (id) bodyData.active = active;

  try {
    const res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify(bodyData)
    });
    const result = await res.json();
    if (res.ok) {
      alert(id ? 'Instructor actualizado correctamente.' : 'Instructor creado correctamente.');
      instructorModal.classList.add('hidden');
      fetchCoordInstructors();
    } else {
      alert(`Error: ${result.error.message}`);
    }
  } catch (err) {
    alert('Error al guardar el instructor.');
  }
}

window.editInstructor = (id, nombre, documento, active) => {
  instructorModalTitle.textContent = "Editar Instructor";
  instructorEditId.value = id;
  instNombre.value = nombre;
  instDocumento.value = documento;
  instDocumento.disabled = true; // No permitir cambiar documento en edición
  instPassword.value = "";
  instPassword.required = false; // No obligatorio en edición
  instActive.checked = active === 1 || active === true;
  instActiveWrapper.classList.remove('hidden');
  instructorModal.classList.remove('hidden');
};

window.toggleInstructorActive = async (id, nombre, currentActive) => {
  const nextActive = currentActive ? 0 : 1;
  const verb = currentActive ? 'desactivar' : 'activar';
  if (!confirm(`¿Estás seguro de que deseas ${verb} al instructor ${nombre}?`)) return;

  try {
    const res = await fetch(`${state.apiUrl}/api/coord/instructors/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({ active: nextActive })
    });
    const result = await res.json();
    if (res.ok) {
      alert('Estado actualizado correctamente.');
      fetchCoordInstructors();
    } else {
      alert(`Error: ${result.error.message}`);
    }
  } catch (err) {
    alert('Error al actualizar el estado del instructor.');
  }
};

async function fetchCoordFichas() {
  coordFichasGridBody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-slate-500">Cargando fichas...</td></tr>';
  try {
    const res = await fetch(`${state.apiUrl}/api/coord/fichas`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok) {
      renderCoordFichas(result.data);
    } else {
      coordFichasGridBody.innerHTML = `<tr><td colspan="5" class="text-center py-8 text-red-400">Error: ${result.error.message}</td></tr>`;
    }
  } catch (err) {
    coordFichasGridBody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-red-400">Error de conexión.</td></tr>';
  }
}

function renderCoordFichas(fichas) {
  coordFichasGridBody.innerHTML = '';
  if (!fichas || fichas.length === 0) {
    coordFichasGridBody.innerHTML = '<tr><td colspan="7" class="text-center py-8 text-slate-500">No hay fichas registradas.</td></tr>';
    return;
  }

  fichas.forEach(f => {
    let statusText = f.active 
      ? '<span class="inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider bg-green-500/10 text-green-400 border border-green-500/20">ACTIVA</span>'
      : '<span class="inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider bg-red-500/10 text-red-400 border border-red-500/20">INACTIVA</span>';

    if (f.status === 'PENDING_DELETION') {
      statusText = '<span class="inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider bg-orange-500/10 text-orange-400 border border-orange-500/20">BAJA PENDIENTE</span>';
    }

    let jornadaBadge = '<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">Diurna</span>';
    if (f.jornada === 'TARDE') {
      jornadaBadge = '<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">Tarde</span>';
    } else if (f.jornada === 'NOCTURNA') {
      jornadaBadge = '<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/20">Nocturna</span>';
    } else if (f.jornada === 'MIXTA') {
      jornadaBadge = '<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">Mixta</span>';
    }

    let modalidadBadge = '<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Presencial</span>';
    if (f.modalidad === 'VIRTUAL') {
      modalidadBadge = '<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">Virtual</span>';
    } else if (f.modalidad === 'MIXTA') {
      modalidadBadge = '<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-semibold bg-teal-500/10 text-teal-400 border border-teal-500/20">Híbrida</span>';
    }

    const toggleText = f.active ? 'Desactivar' : 'Activar';

    const safeFId = escapeHtml(f.id);
    const safeFCode = escapeHtml(f.code);
    const safeFName = escapeHtml(f.name);
    const safeFJornada = escapeHtml(f.jornada || 'DIURNA');
    const safeFModalidad = escapeHtml(f.modalidad || 'PRESENCIAL');

    const deleteBtn = (f.status !== 'PENDING_DELETION' && f.status !== 'DELETED') ? `
      <button onclick="openRequestFichaDeletionModal('${safeFId}', '${safeFCode}', '${safeFName}')" class="text-xs bg-red-950/20 border border-red-500/20 hover:bg-red-900/30 text-red-400 px-2.5 py-1 rounded-md transition-all">
        Solicitar Baja
      </button>
    ` : '';

    coordFichasGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3 px-4 font-mono font-semibold text-[#39A900]">${safeFCode}</td>
        <td class="py-3 px-4 text-slate-200">${safeFName}</td>
        <td class="py-3 px-4 text-center">${jornadaBadge}</td>
        <td class="py-3 px-4 text-center">${modalidadBadge}</td>
        <td class="py-3 px-4 text-center font-semibold text-slate-400">${Number(f.learners_count) || 0}</td>
        <td class="py-3 px-4">${statusText}</td>
        <td class="py-3 px-4 text-right">
          <div class="flex justify-end gap-2">
            <button onclick="editFicha('${safeFId}', '${safeFCode}', '${safeFName}', ${Boolean(f.active)}, '${safeFJornada}', '${safeFModalidad}')" class="text-xs bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md transition-all">
              Editar
            </button>
            <button onclick="toggleFichaActive('${safeFId}', '${safeFName}', ${Boolean(f.active)})" class="text-xs bg-slate-900 border border-slate-800 hover:bg-slate-800 text-red-400 px-2.5 py-1 rounded-md transition-all">
              ${toggleText}
            </button>
            ${deleteBtn}
          </div>
        </td>
      </tr>
    `;
  });
}

async function handleFichaSubmit(e) {
  e.preventDefault();
  const id = fichaEditId.value;
  const code = fichaCode.value.trim();
  const name = fichaName.value.trim();
  const jornada = fichaJornada ? fichaJornada.value : 'DIURNA';
  const modalidad = fichaModalidad ? fichaModalidad.value : 'PRESENCIAL';
  const active = fichaActive.checked;

  const url = id 
    ? `${state.apiUrl}/api/coord/fichas/${id}`
    : `${state.apiUrl}/api/coord/fichas`;

  const method = id ? 'PUT' : 'POST';
  const bodyData = { code, name, jornada, modalidad };
  if (id) bodyData.active = active;

  try {
    const res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify(bodyData)
    });
    const result = await res.json();
    if (res.ok) {
      alert(id ? 'Ficha actualizada correctamente.' : 'Ficha creada correctamente.');
      fichaModal.classList.add('hidden');
      fetchCoordFichas();
    } else {
      alert(`Error: ${result.error?.message || 'No se pudo guardar la ficha'}`);
    }
  } catch (err) {
    alert('Error al guardar la ficha.');
  }
}

window.editFicha = (id, code, name, active, jornada, modalidad) => {
  fichaModalTitle.textContent = "Editar Ficha";
  fichaEditId.value = id;
  fichaCode.value = code;
  fichaCode.disabled = false; // Permitir cambiar el código en edición
  fichaName.value = name;
  if (fichaJornada) fichaJornada.value = jornada || 'DIURNA';
  if (fichaModalidad) fichaModalidad.value = modalidad || 'PRESENCIAL';
  fichaActive.checked = active === 1 || active === true;
  fichaActiveWrapper.classList.remove('hidden');
  fichaModal.classList.remove('hidden');
};

window.toggleFichaActive = async (id, nombre, currentActive) => {
  const nextActive = currentActive ? 0 : 1;
  const verb = currentActive ? 'desactivar' : 'activar';
  if (!confirm(`¿Estás seguro de que deseas ${verb} la ficha ${nombre}?`)) return;

  try {
    const res = await fetch(`${state.apiUrl}/api/coord/fichas/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({ active: nextActive })
    });
    const result = await res.json();
    if (res.ok) {
      alert('Estado actualizado correctamente.');
      fetchCoordFichas();
    } else {
      alert(`Error: ${result.error.message}`);
    }
  } catch (err) {
    alert('Error al actualizar el estado de la ficha.');
  }
};

// --- COORDINATOR EVIDENCES FUNCTIONS ---

async function fetchCoordEvidences() {
  coordEvidencesGridBody.innerHTML = '<tr><td colspan="6" class="text-center py-8 text-slate-500">Cargando histórico de jornadas...</td></tr>';
  try {
    const res = await fetch(`${state.apiUrl}/api/coord/evidences`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok) {
      renderCoordEvidences(result.data);
    } else {
      coordEvidencesGridBody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-red-400">Error: ${result.error.message}</td></tr>`;
    }
  } catch (err) {
    coordEvidencesGridBody.innerHTML = '<tr><td colspan="6" class="text-center py-8 text-red-400">Error de conexión.</td></tr>';
  }
}

function renderCoordEvidences(evidences) {
  coordEvidencesGridBody.innerHTML = '';
  if (!evidences || evidences.length === 0) {
    coordEvidencesGridBody.innerHTML = '<tr><td colspan="6" class="text-center py-8 text-slate-500">No se encontraron jornadas registradas en el sistema.</td></tr>';
    return;
  }

  evidences.forEach(ev => {
    const dateStr = ev.activated_at 
      ? new Date(ev.activated_at).toLocaleString('es-CO', { dateStyle: 'short', timeStyle: 'short' }) 
      : 'No iniciada';

    // Status Badges
    const statusText = ev.status === 'closed' ? 'Cerrada' : (ev.status === 'active' ? 'Activa' : 'Borrador');
    const statusClass = ev.status === 'closed' ? 'bg-slate-500/10 text-slate-400 border border-slate-500/20' : 'bg-green-500/10 text-green-400 border border-green-500/20';

    // Evidence Badges
    const evText = ev.evidence_submitted === 1 ? 'Entregada ✓' : 'Pendiente';
    const evClass = ev.evidence_submitted === 1 ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20 font-bold' : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20';

    // Evidence file download button if submitted
    let downloadAttachedBtn = '';
    if (ev.evidence_submitted === 1) {
      downloadAttachedBtn = `
        <a 
          href="${state.apiUrl}/api/coord/evidences/${ev.id}/download"
          target="_blank"
          class="px-2.5 py-1 bg-teal-600/20 hover:bg-teal-600/30 text-teal-400 border border-teal-500/30 active:scale-95 text-xs font-bold rounded-lg transition-all inline-flex items-center gap-1"
          title="Descargar archivo de evidencia oficial entregado por el instructor"
        >
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"></path></svg>
          <span>Evidencia Adjunta</span>
        </a>
      `;
    }

    const downloadBtn = `
      <div class="flex items-center justify-end gap-1.5 flex-wrap">
        ${downloadAttachedBtn}
        <button 
          onclick="window.downloadCoordExcelReport('${ev.id}', '${ev.ficha_code}')"
          class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 active:scale-95 text-xs font-bold rounded-lg text-slate-200 hover:text-white transition-all inline-flex items-center gap-1 border border-slate-700/60"
        >
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
          <span>Reporte Excel</span>
        </button>
      </div>
    `;

    coordEvidencesGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3.5 px-4 font-bold text-white font-mono">${ev.ficha_code} - ${ev.ficha_name}</td>
        <td class="py-3.5 px-4 text-slate-300 font-medium">${ev.instructor_name || 'Sin asignar'}</td>
        <td class="py-3.5 px-4 text-slate-400 font-mono text-xs">${dateStr}</td>
        <td class="py-3.5 px-4">
          <span class="inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${statusClass}">${ev.jornada || 'DIURNA'} - ${statusText}</span>
        </td>
        <td class="py-3.5 px-4 text-center">
          <span class="inline-flex px-2 py-0.5 rounded-full text-xs ${evClass}">${evText}</span>
        </td>
        <td class="py-3.5 px-4 text-right">
          ${downloadBtn}
        </td>
      </tr>
    `;
  });
}

// Download Excel report on Coordinator click
window.downloadCoordExcelReport = async (sessionId, fichaCode) => {
  try {
    const res = await fetch(`${state.apiUrl}/reports/session/${sessionId}`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const reportData = await res.json();
    if (!res.ok) {
      alert(`Error al obtener los datos del reporte: ${reportData.error?.message || 'Error desconocido'}`);
      return;
    }

    if (reportData.length === 0) {
      alert('No hay registros de asistencia para esta jornada.');
      return;
    }

    // Map to Spanish columns (Without Hora Salida)
    const excelRows = reportData.map(r => ({
      'Aprendiz': r.nombre,
      'Documento': r.documento,
      'Horas Programadas': r.horas_programadas,
      'Horas Asistidas': r.horas_asistidas,
      '% Asistencia': r.porcentaje_asistencia + '%',
      'Hora de Entrada': r.hora_ingreso || '-',
      'Puntualidad / Estado': r.estado_llegada || r.tipo_registro || 'Inasistencia'
    }));

    // Generate Excel
    const worksheet = XLSX.utils.json_to_sheet(excelRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Asistencia');

    // Widths auto-adjust
    const maxLens = {};
    excelRows.forEach(row => {
      Object.keys(row).forEach(key => {
        const valStr = String(row[key] || '');
        maxLens[key] = Math.max(maxLens[key] || 10, valStr.length, key.length);
      });
    });
    worksheet['!cols'] = Object.keys(maxLens).map(k => ({ wch: maxLens[k] + 2 }));

    XLSX.writeFile(workbook, `Reporte_Jornada_${fichaCode}_${sessionId.substring(0, 8)}.xlsx`);
  } catch (err) {
    alert('Error al descargar el archivo Excel: ' + err.message);
  }
};

// ── COORDINATOR DUAL APPROVALS & AUDIT LOGS (PHASE 3 & 4) ────────────────────

// Fetch Dual Deletion Requests (BR-08 Four-Eyes Principle)
async function fetchCoordDualApprovals() {
  if (!coordDualGridBody) return;
  coordDualGridBody.innerHTML = '<tr><td colspan="6" class="text-center py-8 text-slate-500">Cargando solicitudes de baja...</td></tr>';
  try {
    const res = await fetch(`${state.apiUrl}/api/coord/deletion-requests`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok) {
      renderCoordDualApprovals(result.data);
    } else {
      coordDualGridBody.innerHTML = `<tr><td colspan="6" class="text-center py-8 text-red-400">Error: ${result.error?.message || 'Error al cargar'}</td></tr>`;
    }
  } catch (err) {
    coordDualGridBody.innerHTML = '<tr><td colspan="6" class="text-center py-8 text-red-400">Error de conexión.</td></tr>';
  }
}

function renderCoordDualApprovals(requests) {
  if (!coordDualGridBody) return;
  coordDualGridBody.innerHTML = '';
  if (!requests || requests.length === 0) {
    coordDualGridBody.innerHTML = '<tr><td colspan="6" class="text-center py-8 text-slate-500">No hay solicitudes de baja pendientes de segundo par.</td></tr>';
    return;
  }

  const currentUserId = state.person?.id;

  requests.forEach(r => {
    const dateStr = r.created_at ? new Date(r.created_at).toLocaleString('es-CO', { dateStyle: 'short', timeStyle: 'short' }) : '-';
    const isSelf = r.requested_by === currentUserId;

    let actionCol = '';
    if (isSelf) {
      actionCol = `<span class="inline-flex px-2 py-1 rounded text-[11px] font-semibold bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">Esperando 2do Coordinador</span>`;
    } else {
      actionCol = `
        <div class="flex justify-end gap-2">
          <button onclick="approveDualDeletion('${r.id}')" class="text-xs bg-red-600 hover:bg-red-500 text-white font-bold px-3 py-1.5 rounded-lg transition-all shadow-md shadow-red-600/20">
            Aprobar Baja (4 Ojos)
          </button>
          <button onclick="rejectDualDeletion('${r.id}')" class="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold px-2.5 py-1.5 rounded-lg transition-all">
            Rechazar
          </button>
        </div>
      `;
    }

    coordDualGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-3 px-4 font-mono font-bold text-white">${r.unit_code} - ${r.unit_name}</td>
        <td class="py-3 px-4 text-slate-300 text-xs">${r.requester_name} <span class="text-slate-500 font-mono">(${r.requester_doc})</span></td>
        <td class="py-3 px-4 text-xs text-slate-400 max-w-xs truncate" title="${r.reason}">${r.reason}</td>
        <td class="py-3 px-4 font-mono text-xs text-slate-400">${dateStr}</td>
        <td class="py-3 px-4">
          <span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-500/10 text-orange-400 border border-orange-500/20">PENDIENTE 4-OJOS</span>
        </td>
        <td class="py-3 px-4 text-right">${actionCol}</td>
      </tr>
    `;
  });
}

window.approveDualDeletion = async (requestId) => {
  if (!confirm('¿Confirmas la baja definitiva de esta ficha académica cumpliendo con el principio de 4 Ojos (BR-08)?')) return;
  try {
    const res = await fetch(`${state.apiUrl}/api/coord/deletion-requests/${requestId}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      }
    });
    const result = await res.json();
    if (res.ok) {
      alert(result.data?.message || 'Ficha eliminada exitosamente.');
      fetchCoordDualApprovals();
      fetchCoordFichas();
    } else {
      alert(`Error: ${result.error?.message || 'No se pudo aprobar la baja.'}`);
    }
  } catch (err) {
    alert('Error al procesar la aprobación dual.');
  }
};

window.rejectDualDeletion = async (requestId) => {
  const reason = prompt('Motivo del rechazo de la solicitud:');
  if (reason === null) return;
  try {
    const res = await fetch(`${state.apiUrl}/api/coord/deletion-requests/${requestId}/reject`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.token}`
      },
      body: JSON.stringify({ rejectionReason: reason })
    });
    const result = await res.json();
    if (res.ok) {
      alert(result.data?.message || 'Solicitud rechazada.');
      fetchCoordDualApprovals();
      fetchCoordFichas();
    } else {
      alert(`Error: ${result.error?.message || 'No se pudo rechazar.'}`);
    }
  } catch (err) {
    alert('Error al rechazar la solicitud.');
  }
};

// Fetch System Audit Logs (Immutable Master Log)
async function fetchCoordAuditLogs() {
  if (!coordAuditGridBody) return;
  coordAuditGridBody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-slate-500 font-sans">Cargando libro de auditoría...</td></tr>';
  try {
    const res = await fetch(`${state.apiUrl}/api/coord/audit-logs`, {
      headers: { 'Authorization': `Bearer ${state.token}` }
    });
    if (handleAuthError(res)) return;

    const result = await res.json();
    if (res.ok) {
      renderCoordAuditLogs(result.data);
    } else {
      coordAuditGridBody.innerHTML = `<tr><td colspan="5" class="text-center py-8 text-red-400 font-sans">Error: ${result.error?.message || 'Error al cargar'}</td></tr>`;
    }
  } catch (err) {
    coordAuditGridBody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-red-400 font-sans">Error de conexión.</td></tr>';
  }
}

function renderCoordAuditLogs(logs) {
  if (!coordAuditGridBody) return;
  coordAuditGridBody.innerHTML = '';
  if (!logs || logs.length === 0) {
    coordAuditGridBody.innerHTML = '<tr><td colspan="5" class="text-center py-8 text-slate-500 font-sans">No hay eventos de auditoría registrados.</td></tr>';
    return;
  }

  logs.forEach(l => {
    const dateStr = l.created_at ? new Date(l.created_at).toLocaleString('es-CO', { dateStyle: 'short', timeStyle: 'medium' }) : '-';
    const actor = l.actor_name ? `${l.actor_name} (${l.actor_doc})` : (l.actor_id || 'SYSTEM');

    let actionBadge = `<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">${l.action}</span>`;
    if (l.action.includes('DELETE') || l.action.includes('ANONYMIZED')) {
      actionBadge = `<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/10 text-red-400 border border-red-500/20">${l.action}</span>`;
    } else if (l.action.includes('APPROVE') || l.action.includes('REGISTRATION')) {
      actionBadge = `<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-bold bg-green-500/10 text-green-400 border border-green-500/20">${l.action}</span>`;
    }

    const detailObj = l.metadata_json ? JSON.parse(l.metadata_json) : (l.after_json ? JSON.parse(l.after_json) : {});
    const detailStr = JSON.stringify(detailObj);

    const safeActor = escapeHtml(actor);
    const safeAction = escapeHtml(l.action);
    const safeEntity = escapeHtml(`${l.entity_type}:${l.entity_id ? l.entity_id.substring(0, 14) : ''}`);
    const safeDetailStr = escapeHtml(detailStr);
    const safeDateStr = escapeHtml(dateStr);

    let safeActionBadge = `<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">${safeAction}</span>`;
    if (String(l.action || '').includes('DELETE') || String(l.action || '').includes('ANONYMIZED')) {
      safeActionBadge = `<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/10 text-red-400 border border-red-500/20">${safeAction}</span>`;
    } else if (String(l.action || '').includes('APPROVE') || String(l.action || '').includes('REGISTRATION')) {
      safeActionBadge = `<span class="inline-flex px-2 py-0.5 rounded text-[10px] font-bold bg-green-500/10 text-green-400 border border-green-500/20">${safeAction}</span>`;
    }

    coordAuditGridBody.innerHTML += `
      <tr class="hover:bg-slate-900/20 border-b border-slate-800/40">
        <td class="py-2.5 px-4 text-slate-400 whitespace-nowrap">${safeDateStr}</td>
        <td class="py-2.5 px-4 whitespace-nowrap">${safeActionBadge}</td>
        <td class="py-2.5 px-4 text-slate-300 font-sans text-xs">${safeActor}</td>
        <td class="py-2.5 px-4 text-slate-400">${safeEntity}</td>
        <td class="py-2.5 px-4 text-slate-500 text-[11px] max-w-xs truncate" title="${safeDetailStr}">${safeDetailStr}</td>
      </tr>
    `;
  });
}

// Open Request Ficha Deletion Modal (BR-08)
window.openRequestFichaDeletionModal = (id, code, name) => {
  if (!requestFichaDeletionModal) return;
  deleteFichaId.value = id;
  deleteFichaLabel.textContent = `Ficha ${code} - ${name}`;
  deleteFichaReason.value = '';
  requestFichaDeletionModal.classList.remove('hidden');
};
