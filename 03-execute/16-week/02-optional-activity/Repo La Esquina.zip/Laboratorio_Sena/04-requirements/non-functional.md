# Requisitos no funcionales y de negocio

> Estado: 🟢 Documentado | Última actualización: 2026-06-20
> Autor: Equipo de Análisis y Desarrollo de Software — SENA | Equipo: ADSO — Competencia 220501046

Los requisitos no funcionales (RNF) y de negocio (RN) se priorizaron mediante el modelo **MoSCoW** bajo el marco NTC-ISO/IEC 25010, con justificación por triangulación multi-instrumento conforme a Wiegers & Beatty (2013) y SENA (2026).

## Must Have

### RNF01 — Interfaz Intuitiva (máximo 2 horas de inducción)

**Descripción:** la interfaz debe permitir que un operario sin experiencia técnica previa complete una venta completa tras una sesión de inducción de máximo dos horas. Íconos y etiquetas en español colombiano. **I×U = 9/9 — Must Have**

> **Justificación por triangulación**
> - Instrumentos: entrevista semiestructurada (propietario) · ficha de caracterización de usuarios · encuesta a clientes.
> - Actores/fuentes: Carlos Ruiz (Administrador) · Martha Suárez (Empleado) · Julián Torres (empleado).
> - Evidencia convergente: Carlos Ruiz nunca ha operado un software de gestión comercial y manifestó temor a depender de una herramienta que no pudiera manejar de forma autónoma: "Que sea sencillo, que yo pueda aprender en un día." La ficha de caracterización confirmó que ninguno de los cuatro actores posee experiencia previa con sistemas POS. La encuesta reveló que la expectativa de rapidez de clientes como Ana Moreno y Sofía Mendoza solo se cumplirá si los operarios dominan la herramienta desde el primer día.
> - Conclusión: la resistencia moderada a la tecnología del propietario, la nula experiencia del equipo y la expectativa de rapidez del cliente convergen en una restricción de usabilidad no negociable: máximo 2 horas de inducción. El incumplimiento implica riesgo de abandono del sistema.

### RNF02 — Funcionamiento en Modo Offline

**Descripción:** el sistema debe operar con plena funcionalidad de ventas e inventario sin conexión a internet. La sincronización con la nube debe realizarse en menos de cinco minutos al recuperarse la conexión. Crítico dado el internet básico domiciliario del negocio. **I×U = 9/9 — Must Have**

> **Justificación por triangulación**
> - Instrumentos: entrevista semiestructurada (propietario) · ficha de observación directa · revisión del entorno tecnológico.
> - Actores/fuentes: Carlos Ruiz (propietario) · contexto: sector residencial de barrio con servicio de internet básico domiciliario.
> - Evidencia convergente: el supermercado cuenta únicamente con un plan de internet residencial básico, no con conexión empresarial de alta disponibilidad. La observación directa registró al menos una interrupción breve de conectividad durante la sesión de campo en horario pico. Depender de conexión permanente representa un riesgo de disponibilidad inaceptable: cualquier caída de red paralizaría las operaciones de cobro en el horario de mayor afluencia.
> - Conclusión: la inestabilidad documentada del internet residencial hace del modo Offline-First un requisito de arquitectura no negociable. Un sistema cloud-only tendría disponibilidad operativa inferior al 100%, bloqueando ventas en momentos de mayor demanda. I×U = 9 — prioridad máxima.

### RNF05 — Compatibilidad con Hardware de Bajo Costo

**Descripción:** el sistema debe ejecutarse en tablet Android 8.0 o superior con mínimo 2 GB de RAM, o en computador con Windows 10 y mínimo 2 GB de RAM, sin requerir hardware especializado. Determinante para la viabilidad económica del proyecto. **I×U = 6/9 — Must Have**

> **Justificación por triangulación**
> - Instrumentos: entrevista semiestructurada (propietario) · revisión del entorno tecnológico.
> - Actores/fuentes: Carlos Ruiz (propietario) · equipo existente en el negocio.
> - Evidencia convergente: Carlos Ruiz declaró no contar con presupuesto para hardware especializado (terminales POS dedicados, impresoras fiscales certificadas). El negocio dispone de un dispositivo Android básico y un computador Windows 10 de gama media-baja. Cualquier solución que exija hardware adicional elevaría el costo total por encima del umbral de viabilidad para una microempresa familiar.
> - Conclusión: el perfil tecnológico del negocio y la restricción presupuestaria determinan que la compatibilidad con hardware existente de bajo costo es condición necesaria para la adopción del sistema (mín. 2 GB RAM, Android 8.0 / Windows 10).

## Should Have

| ID | Nombre del requisito | I (1-3) | U (1-3) | I×U | MoSCoW |
| --- | --- | --- | --- | --- | --- |
| RNF03 | Tiempo de Respuesta ≤3 segundos | 2 | 2 | 4 — Medio | 🟠 Should Have |
| RNF04 | Control de Acceso por Roles | 3 | 2 | 6 — Alto | 🟠 Should Have |
| RNF06 | Actualización Catálogo sin Técnico | 2 | 2 | 4 — Medio | 🟠 Should Have |
| RNF08 | Respaldo Automático Diario | 2 | 2 | 4 — Medio | 🟠 Should Have |

- **RNF06** está directamente vinculado a RF02 (Catálogo de Productos): permite al Administrador actualizar precios sin asistencia técnica, abordando la causa raíz del hallazgo D04 (~9% de productos con precio desactualizado).
- **RNF04** complementa el Módulo M3 (Usuarios y Roles), separando el acceso total del Administrador del acceso limitado del Empleado.

## Could Have

| ID | Nombre del requisito | I (1-3) | U (1-3) | I×U | MoSCoW |
| --- | --- | --- | --- | --- | --- |
| RNF07 | Escalabilidad Arquitectural 300 Productos | 1 | 1 | 1 — Mínimo | 🟡 Could Have |

## Requisitos de negocio (Must Have)

### RN01 — Modelo de Costo Único (sin suscripción mensual)

**Descripción:** el sistema debe adquirirse bajo un esquema de costo único de desarrollo o licencia anual. No se aceptan modelos de suscripción mensual recurrente de alto costo, dada la naturaleza de microempresa familiar. **I×U = 9/9 — Must Have**

> **Justificación por triangulación**
> - Instrumentos: entrevista semiestructurada (propietario) · análisis de contexto económico del negocio.
> - Actores/fuentes: Carlos Ruiz (único decisor financiero).
> - Evidencia convergente: Carlos Ruiz manifestó preocupación explícita por costos recurrentes, señalando que el negocio no puede comprometerse con pagos mensuales fijos adicionales a los gastos operativos actuales (arrendamiento, servicios públicos, nómina). El análisis del modelo de negocio confirma una microempresa familiar con flujo de caja variable según temporada, lo que hace inviable un modelo SaaS de suscripción mensual.
> - Conclusión: la restricción financiera es no negociable; un modelo de suscripción mensual representa riesgo de abandono del sistema en meses de menor facturación. El costo único garantiza previsibilidad financiera y continuidad operativa.

### RN02 — Autonomía Operativa

**Descripción:** el negocio no debe depender de asistencia técnica externa para operaciones diarias. El propietario debe resolver situaciones básicas (reinicio, actualización de precios, corte de caja) de forma autónoma. **I×U = 9/9 — Must Have**

> **Justificación por triangulación**
> - Instrumentos: entrevista semiestructurada (propietario) · ficha de caracterización de usuarios.
> - Actores/fuentes: Carlos Ruiz (propietario) · equipo operativo (4 personas sin formación técnica).
> - Evidencia convergente: Carlos Ruiz indicó no contar con acceso inmediato a soporte técnico presencial en el sector donde opera, y que llamar a un técnico implicaría costos adicionales y tiempos de espera inaceptables. La ficha de caracterización confirmó que ninguno de los cuatro integrantes del equipo posee formación técnica en sistemas. La autonomía operativa es una extensión directa de RNF01 (usabilidad) aplicada a la gestión post-implementación.
> - Conclusión: la ausencia de soporte técnico inmediato y la nula formación técnica del equipo hacen de la autonomía operativa un requisito de negocio crítico. El sistema debe ser operable y mantenible por sus propios usuarios sin intervención externa para tareas cotidianas.

## Argumentos de entorno tecnológico

| Factor del entorno | Implicación para el diseño |
| --- | --- |
| Internet residencial básico, sin conexión empresarial | Arquitectura Offline-First (RNF02) |
| Hardware existente: Android básico + PC Windows 10 gama media-baja | Sin requerimiento de hardware especializado (RNF05) |
| Cero formación técnica en el equipo (4 personas) | Interfaz intuitiva ≤2h de inducción (RNF01) y autonomía operativa (RN02) |
| Flujo de caja variable de microempresa familiar | Modelo de costo único, sin suscripción mensual (RN01) |

## Referencias

- ICONTEC. (2013). *NTC-ISO/IEC 25010 — Calidad del producto de software*.
- SENA. (2026). *SRS — Supermercado "La Esquina" (v1.0)*.
- Wiegers, K., & Beatty, J. (2013). *Software Requirements* (3.ª ed.). Microsoft Press.
