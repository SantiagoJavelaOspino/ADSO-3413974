# Requisitos funcionales

> Estado: 🟢 Documentado | Última actualización: 2026-06-20
> Autor: Equipo de Análisis y Desarrollo de Software — SENA | Equipo: ADSO — Competencia 220501046

Los requisitos funcionales fueron derivados del SRS v1.0 mediante cuatro instrumentos de recolección (entrevista semiestructurada, ficha de observación directa, encuesta a clientes y revisión documental D01–D06) y priorizados con el modelo **MoSCoW**, usando criterios de Importancia (I: 1–3) y Urgencia (U: 1–3), donde Prioridad = I × U (Must Have ≥7 · Should Have 4–6 · Could Have ≤3).

## Must Have

### RF01 — Registro de Venta / POS Básico

**Descripción:** el sistema debe permitir registrar una venta seleccionando productos del catálogo digital, calculando automáticamente el subtotal y el total, y registrando el método de pago. Elimina el Paso 3 de la ficha de observación (120 s = 44% del tiempo total). **I×U = 9/9 — Must Have**

> **Justificación por triangulación**
> - Instrumentos: entrevista semiestructurada · encuesta a clientes · ficha de observación directa.
> - Actores/fuentes: Carlos Ruiz (propietario) · Martha Suárez (cajera) · Ana Moreno (cliente) · Sofía Mendoza (cliente).
> - Evidencia convergente: la entrevista identificó el paso de suma manual como el más lento y propenso a errores. La observación directa lo cuantificó en 120 segundos (44% del tiempo por transacción). La encuesta reveló que Ana Moreno y Sofía Mendoza mencionaron explícitamente la lentitud en el cobro como su principal queja del servicio.
> - Conclusión: tres instrumentos independientes convergen en el mismo problema: el proceso manual de cobro es el cuello de botella principal. Nivel de confianza: alto. Prioridad: máxima (I×U = 9).

### RF02 — Catálogo de Productos

**Descripción:** gestión de hasta 90 productos con nombre, precio, categoría, stock actual y stock mínimo. Solo el Administrador puede crear, editar o eliminar productos. Resuelve la desactualización del D04 (8 precios incorrectos). **I×U = 9/9 — Must Have**

> **Justificación por triangulación**
> - Instrumentos: encuesta a clientes · revisión documental (D04 — Lista de precios) · ficha de observación directa.
> - Actores/fuentes: Rosa Vargas (cliente) · Felipe Salcedo (cliente) · Hernán Ospina (cliente) · Diego Morales (empleado).
> - Evidencia convergente: la revisión del D04 detectó que 8 de 90 productos (~9%) presentaban precio inconsistente entre el cuaderno y la estantería. Rosa Vargas reportó un cobro incorrecto por el precio del aceite de cocina, experiencia que disminuyó su confianza en el establecimiento. Felipe Salcedo y Hernán Ospina manifestaron quejas similares. Diego Morales confirmó que consultaba frecuentemente el cuaderno por desconocer el precio actualizado de varios artículos.
> - Conclusión: encuesta, revisión documental y perspectiva del empleado convergen en que la falta de un catálogo digital centralizado genera cobros incorrectos, pérdida de confianza del cliente y confusión operativa interna. La actualización autónoma del catálogo (RNF06) es condición necesaria para que RF02 sea efectivo.

## Should Have

| ID | Nombre del requisito | I (1-3) | U (1-3) | I×U | MoSCoW |
| --- | --- | --- | --- | --- | --- |
| RF03 | Control de Inventario + Alertas de Stock | 3 | 2 | 6 — Alto | 🟠 Should Have |
| RF04 | Corte de Caja Diario | 2 | 3 | 6 — Alto | 🟠 Should Have |
| RF05 | Gestión de Crédito / Fiado | 2 | 2 | 4 — Medio | 🟠 Should Have |
| RF06 | Generación de Tiquete de Venta | 2 | 2 | 4 — Medio | 🟠 Should Have |

### RF03 — Control de Inventario y Alertas de Stock (nota de triangulación)

Aunque RF03 se clasifica como Should Have (I×U = 6), su justificación por triangulación es sólida y se incluye como fundamento analítico para la segunda iteración del MVP.

> - Instrumentos: entrevista semiestructurada (propietario) · revisión documental (D05 — Registro de pedidos) · observación directa.
> - Actores/fuentes: Carlos Ruiz (propietario) · Diego Morales (empleado).
> - Evidencia convergente: Carlos Ruiz declaró: "No sé cuándo se va a acabar un producto hasta que ya no hay", revelando que la gestión de inventario opera exclusivamente por memoria. El D05 evidenció la ausencia de umbrales mínimos definidos por producto. Diego Morales confirmó durante la observación directa que el agotamiento de productos se descubre únicamente cuando el cliente lo solicita en caja.
> - Conclusión: la preocupación del propietario, la evidencia documental del D05 y la validación del empleado convergen en la misma brecha: sin control digital de stock, los agotamientos son inevitables e imprevisibles. RF03 se recomienda para la primera actualización post-MVP.

### RF04 — Corte de Caja Diario

Resumen diario de ventas por método de pago y diferencia versus caja física. Originado por D06 (Corte de caja diario), que evidenció ausencia total de desglose por producto, hora pico o empleado, y nula trazabilidad para auditoría.

### RF05 — Gestión de Crédito / Fiado

Registro de créditos por cliente, abonos, saldo pendiente y alertas de vencimiento. Originado directamente por el hallazgo de D02 (cuaderno de fiado): 12 clientes activos, cartera total de $336.000 COP, sin columna de abonos ni saldo actualizado. Ver detalle financiero en [`15-project-control/risks.md`](../15-project-control/risks.md).

### RF06 — Generación de Tiquete de Venta

Generación de tiquete en formato impreso o digital (PDF/WhatsApp) al completar cada transacción.

## Could Have

| ID | Nombre del requisito | I (1-3) | U (1-3) | I×U | MoSCoW |
| --- | --- | --- | --- | --- | --- |
| RF07 | Historial de Ventas con Filtros | 2 | 1 | 2 — Bajo | 🟡 Could Have |
| RF08 | Gestión de Proveedores | 1 | 1 | 1 — Mínimo | 🟡 Could Have |
| RF09 | Notificación de Pedidos Sugeridos | 1 | 1 | 1 — Mínimo | 🟡 Could Have |
| RF10 | Reporte de Productos Más Vendidos | 1 | 1 | 1 — Mínimo | 🟡 Could Have |

- **RF08** se origina en el hallazgo de D03 (Facturas de proveedores): tres proveedores identificados (Alimentos del Sur, Bebidas La Unión, Surtidor Pan de Horno), sin comparación sistemática entre precios de factura y precios de venta.
- **RF10** se origina en el hallazgo de D06 (Corte de caja diario), que no permitía identificar el producto más vendido ni el rendimiento individual por empleado.

## Resumen MoSCoW

**Total: 7 Must Have · 8 Should Have · 5 Could Have.**

Leyenda: I = Importancia (1–3) · U = Urgencia (1–3) · Prioridad = I × U · Must Have ≥7 · Should Have 4–6 · Could Have ≤3.

## Referencias

- IEEE. (1998). *IEEE Std 830-1998*. IEEE Computer Society.
- SENA. (2026). *SRS — Supermercado "La Esquina" (v1.0)*.
- Wiegers, K., & Beatty, J. (2013). *Software Requirements* (3.ª ed.). Microsoft Press.
