# Overview

> Estado: 🟢 Documentado | Última actualización: 2026-06-20
> Autor: Equipo de Análisis y Desarrollo de Software — SENA | Equipo: ADSO — Competencia 220501046

## Contexto institucional

Este documento de contexto forma parte del repositorio técnico del proyecto **"Sistema POS e Inventario — Supermercado La Esquina"**, desarrollado en el marco de la Tecnología en Análisis y Desarrollo de Software (ADSO) del SENA, bajo la Competencia 220501046 — *Construir los requisitos del sistema de información*. El documento base que sustenta todo el contenido de esta carpeta es el SRS — Especificación de Requerimientos de Software v1.0 (SENA, 2026), elaborado bajo el marco normativo IEEE 830, NTC-ISO/IEC 25010, modelo de priorización MoSCoW y los lineamientos de Sommerville (2016).

| Campo | Valor |
| --- | --- |
| Cliente | Carlos Ruiz — Propietario, Supermercado "La Esquina" |
| Documento base | SRS — Especificación de Requerimientos de Software v1.0 |
| Marco normativo | IEEE 830 · NTC-ISO/IEC 25010 · MoSCoW · Sommerville (2016) |

## Contexto del establecimiento

El Supermercado "La Esquina" es un establecimiento comercial de carácter familiar ubicado en un sector residencial de barrio, con operación en jornada completa (7:00 a.m. – 7:00 p.m.). Su propietario, Carlos Ruiz, actúa como principal cajero y único decisor estratégico del negocio. El catálogo comprende aproximadamente **90 productos** de consumo masivo, con un volumen diario de entre 35 y 50 transacciones — **promedio de 42,5 ventas por día**.

El equipo operativo está integrado por **cuatro personas**:

| Actor | Rol en el negocio | Jornada | Doc. asociado | Observación clave del SRS |
| --- | --- | --- | --- | --- |
| Carlos Ruiz | Propietario / Jefe (único decisor y cajero principal) | 7 a.m. – 7 p.m. | D01, D02, D05, D06 | Resistencia tecnológica moderada. Único con poder de decisión sobre el sistema. Opera por memoria sin respaldo digital. |
| Martha Suárez | Cajera — tiempo completo. Apoya caja en horas pico. | 7 a.m. – 4 p.m. | D01 | Caligrafía variable en el cuaderno de ventas (D01): dificulta la lectura y auditoría de registros históricos. |
| Julián Torres | Empleado — tiempo completo. | 8 a.m. – 4 p.m. | D01 | Comete más errores al sumar durante la hora pico (12:00–2:00 p.m.), según ficha de observación directa (D01). |
| Diego Morales | Empleado — medio tiempo. | 2 p.m. – 7 p.m. | D04 | Detectó errores de precio en D04 (aceite, arroz). Consulta frecuentemente el cuaderno de precios por desactualización. |

*Tabla — Equipo del Supermercado "La Esquina" y documentos físicos asociados a cada actor.*

## Problema

La operación del supermercado se ejecuta de forma **100% manual**, mediante cuaderno y calculadora, lo que genera ineficiencias estructurales documentadas a través de cuatro instrumentos de recolección: entrevista semiestructurada, ficha de observación directa, encuesta a clientes y revisión documental de seis registros físicos (D01–D06). Esta revisión documental fue el instrumento complementario esencial del estudio: cada documento físico reveló brechas operativas que Carlos Ruiz no mencionó espontáneamente en la entrevista, evidenciando lo que Sommerville (2016) denomina **requisitos implícitos** — necesidades reales que el cliente no logra articular hasta confrontarlos con la evidencia documental.

### Hallazgos por documento físico (D01–D06)

| Doc. | Nombre del registro | Hallazgo clave identificado en el SRS |
| --- | --- | --- |
| D01 | Cuaderno de ventas (ene–sep 2024) | Sin clasificación por producto, empleado ni hora pico. Caligrafía variable de Martha Suárez imposibilita la auditoría. Promedio de 42,5 ventas/día derivado de este registro. No permite identificar el producto más vendido ni el rendimiento individual. |
| D02 | Cuaderno de fiado | 12 clientes activos · Cartera total: $336.000 COP · Promedio por cliente: $28.000 COP. Sin columna de abonos ni saldo actualizado. Riesgo de pérdida patrimonial por omisión de pagos. Originó directamente RF05 (Gestión de Crédito / Fiado). |
| D03 | Facturas de proveedores | Tres proveedores identificados: Alimentos del Sur, Bebidas La Unión, Surtidor Pan de Horno. No existe comparación sistemática entre precios de factura y precios de venta. Base para RF08 (Gestión de Proveedores — Could Have). |
| D04 | Lista de precios | 8 de 90 productos (~9%) con precio diferente entre el cuaderno y la estantería. Cobros incorrectos reportados por Rosa Vargas, Felipe Salcedo y Hernán Ospina. Diego Morales detectó errores en aceite y arroz. Originó RF02 (Catálogo de Productos — Must Have) y RNF06 (actualización sin técnico). |
| D05 | Registro de pedidos a proveedores | Pedidos realizados exclusivamente por memoria del propietario. Sin umbrales mínimos definidos por producto. Agotamientos no planificados descubiertos cuando el cliente los solicita. Carlos Ruiz declaró: "No sé cuándo se va a acabar un producto hasta que ya no hay." Originó RF03 (Alertas de Stock — Should Have). |
| D06 | Corte de caja diario | Sin desglose por producto, hora pico ni rendimiento individual por empleado. No permite identificar diferencias entre efectivo registrado y efectivo físico. Nula trazabilidad para auditoría. Originó RF04 (Corte de Caja Diario — Should Have) y RF10 (Reporte de Productos Más Vendidos — Could Have). |

*Tabla — Hallazgos por documento físico D01–D06 y requisitos derivados.*

### Impacto cuantificado de los procesos manuales

La ficha de observación directa en horario pico (12:00–14:00 h) cuantificó el proceso de venta en seis pasos, determinando un **tiempo promedio total de 382 segundos** por transacción. El paso crítico identificado es la suma manual de precios con calculadora (Paso 3), que consume en promedio **120 segundos**, representando el **44% del tiempo total** de cada transacción. Esta actividad constituye el cuello de botella operativo principal del negocio.

| Paso del proceso | Mín (s) | Máx (s) | Prom (s) | % del total | Error |
| --- | --- | --- | --- | --- | --- |
| 1. Cliente lleva productos al mostrador | 30 | 30 | 30 | 7.9% | Bajo |
| 2. Identificar precio de cada producto | 60 | 105 | 82.5 | 21.6% | Alto ⚠ |
| 3. Sumar precios con calculadora ← CUELLO DE BOTELLA | 90 | 150 | 120 | 44% | Alto ⚠ |
| 4. Anotar venta en cuaderno | 60 | 90 | 75 | 19.6% | Medio |
| 5. Calcular y entregar cambio | 40 | 60 | 50 | 13.1% | Medio |
| 6. Archivar tiquete / recibo | 20 | 30 | 25 | 6.5% | Bajo |
| **TOTAL POR TRANSACCIÓN** | **300** | **465** | **382.5** | **100%** | — |

*Tabla — Tiempos del proceso de venta — Ficha de observación directa.*

Con un promedio de 42,5 ventas diarias y 382,5 segundos por transacción, se estima una inversión de **16.256 segundos diarios** en el proceso de cobro, de los cuales **5.100 segundos (85 minutos)** corresponden exclusivamente a la suma manual. La automatización de este proceso permitiría reducir el tiempo de transacción de 382 a 145 segundos (**reducción del 62%**), equivalente a recuperar **3,7 horas de productividad diaria**.

### Validación por encuesta a clientes — impacto en ventas por ausencia de pagos digitales

La encuesta aplicada a 15 clientes habituales del supermercado reveló un hallazgo crítico complementario a la ficha de observación directa: **4 de los 15 participantes (26,7%)** declararon haber abandonado una compra en el establecimiento debido a la ausencia de medios de pago digitales —específicamente Nequi, Daviplata o datafono—. Este dato fue corroborado mediante triangulación con la ficha de observación, en la que se registró al menos un episodio de cliente que se retiró sin comprar durante la sesión de observación en horario pico (12:00–14:00 h), confirmando que el fenómeno no es anecdótico sino sistemático.

La triangulación entre instrumentos —encuesta cuantitativa y observación directa— eleva la validez interna del hallazgo, ya que descarta el sesgo de deseabilidad social presente en las respuestas individuales: los clientes no solo reportaron el problema, sino que el comportamiento fue observado in situ de forma independiente. Este hallazgo sustenta la inclusión del registro del método de pago en el Módulo M2 (POS/Ventas) y orienta la hoja de ruta hacia la integración de pagos digitales como escalabilidad futura de la segunda iteración del MVP.

> **Dato de triangulación — Encuesta × Observación Directa**
> - Instrumento 1 — Encuesta a clientes (n=15): 4 clientes (26,7%) afirmaron haber abandonado una compra por falta de pago digital.
> - Instrumento 2 — Ficha de Observación Directa (horario pico 12:00–14:00 h): se documentó al menos un episodio de retiro de cliente sin comprar durante la sesión de campo, coincidiendo con la razón reportada en la encuesta.
> - **Conclusión de triangulación:** hallazgo validado por convergencia multi-instrumento. Nivel de confianza: alto.

### Hallazgos críticos adicionales

| Hallazgo | Descripción e impacto cuantificado |
| --- | --- |
| Precios desactualizados | El documento D04 evidencia que 8 de 90 productos (~9%) tienen precio inconsistente entre el cuaderno y la estantería, generando cobros incorrectos reportados por tres clientes. |
| Cartera sin trazabilidad | El cuaderno de fiado (D02) registra 12 clientes activos con una cartera total de $336.000 COP (promedio de $28.000 por cliente), sin columna de abonos ni saldo actualizado, exponiendo al negocio a pérdidas no cuantificadas. |
| Sin control de inventario | Carlos Ruiz declara: "No sé cuándo se va a acabar un producto hasta que ya no hay" (D05). Los pedidos a proveedores se realizan exclusivamente por memoria del propietario. |
| Ventas perdidas por pagos digitales | 4 de 15 clientes encuestados (26,7%) reportaron abandonar compras por ausencia de pago digital (Nequi, Daviplata, datafono). Validado por convergencia: la Ficha de Observación Directa registró al menos un episodio de retiro de cliente sin comprar durante la sesión de campo en horario pico (12:00–14:00 h), corroborando el dato de la encuesta. |

*Tabla — Hallazgos críticos del diagnóstico operacional.*

## Objetivos

- Eliminar el cuello de botella de la suma manual de precios (120 s · 44% del tiempo de transacción) mediante un cálculo automático de venta.
- Reducir el tiempo total de transacción de 382 a 145 segundos (**-62%**), recuperando 3,7 horas productivas diarias.
- Eliminar la desactualización de precios (~9% del catálogo) mediante un catálogo digital centralizado.
- Dar trazabilidad a la cartera de fiado ($336.000 COP en 12 clientes) mediante registro digital de créditos y abonos.
- Habilitar el registro del método de pago para cuantificar la oportunidad de recuperación del 26,7% de ventas perdidas por ausencia de pagos digitales.
- Garantizar autonomía operativa total del propietario y su equipo, sin dependencia de soporte técnico externo ni de conexión permanente a internet.

## Referencias

- IEEE. (1998). *IEEE Std 830-1998 — IEEE Recommended Practice for Software Requirements Specifications*. IEEE Computer Society.
- ICONTEC. (2013). *NTC-ISO/IEC 25010 — Calidad del producto de software*. Instituto Colombiano de Normas Técnicas y Certificación.
- SENA. (2026). *SRS — Especificación de Requerimientos de Software: Supermercado "La Esquina" (v1.0)*. Programa Tecnología en Análisis y Desarrollo de Software.
- Sommerville, I. (2016). *Ingeniería de Software* (10.ª ed.). Pearson Educación.
