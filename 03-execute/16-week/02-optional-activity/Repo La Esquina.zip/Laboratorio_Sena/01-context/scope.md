# Alcance

> Estado: 🟢 Documentado | Última actualización: 2026-06-20
> Autor: Equipo de Análisis y Desarrollo de Software — SENA | Equipo: ADSO — Competencia 220501046

El sistema a desarrollar constituye un **Producto Mínimo Viable (MVP)** de tipo Sistema de Punto de Venta (POS) e Inventario. Su objetivo es permitir a Carlos Ruiz y su equipo registrar ventas, controlar el inventario de hasta 90 productos y gestionar créditos de clientes, con una curva de aprendizaje máxima de **dos horas de inducción**. El alcance funcional del MVP se estructura en seis módulos principales.

## En alcance — Seis módulos del MVP

| ID | Módulo | Alcance funcional |
| --- | --- | --- |
| M1 | Inventario y Catálogo | Gestión de hasta 90 productos (nombre, precio, categoría, stock). Alertas de stock mínimo configurables por el Administrador. |
| M2 | Ventas / POS | Registro de transacciones con selección de productos, cálculo automático del total y registro del método de pago (efectivo/digital). |
| M3 | Usuarios y Roles | Acceso diferenciado: Administrador (Carlos Ruiz) con acceso total; Empleado con acceso limitado a ventas e inventario en modo lectura. |
| M4 | Reportes y Corte de Caja | Resumen diario de ventas por método de pago, diferencia versus caja física e historial consultable con filtros. |
| M5 | Facturación / Tiquetes | Generación de tiquete de venta en formato impreso o digital (PDF/WhatsApp) al completar cada transacción. |
| M6 | Gestión de Crédito / Fiado | Registro de créditos por cliente, abonos, saldo pendiente y alertas de vencimiento (deudas con más de 30 días sin abono). |

*Tabla — Módulos del MVP, Supermercado "La Esquina".*

## Fuera de alcance

Se excluyen explícitamente del alcance del MVP:

- Integración directa con pasarelas de pago (Nequi, Daviplata, datafono).
- Facturación electrónica DIAN.
- Gestión contable integral del negocio.
- Administración de múltiples sucursales.

Estas funcionalidades se clasifican como **Should Have** o elementos de escalabilidad futura para iteraciones posteriores al MVP, una vez validada la adopción del producto inicial.

## Supuestos

- El propietario y su equipo (4 personas) no poseen formación técnica previa en sistemas de información.
- El negocio cuenta únicamente con un plan de internet residencial básico, sin conexión empresarial de alta disponibilidad.
- El catálogo se mantiene en un rango cercano a 90 productos durante la vigencia del MVP.
- El hardware disponible se limita a un dispositivo Android básico y un computador con Windows 10 de gama media-baja.

## Restricciones

- **Curva de aprendizaje:** máximo 2 horas de inducción para que un operario sin experiencia técnica complete una venta (RNF01).
- **Disponibilidad:** el sistema debe operar en modo offline obligatorio, con sincronización en menos de 5 minutos al recuperar conexión (RNF02).
- **Hardware:** compatibilidad con tablet Android 8.0+ (mín. 2 GB RAM) o PC con Windows 10 (mín. 2 GB RAM), sin hardware especializado (RNF05).
- **Modelo económico:** costo único de desarrollo o licencia anual; no se aceptan modelos de suscripción mensual recurrente (RN01).
- **Autonomía:** el negocio no debe depender de soporte técnico externo para operaciones diarias (RN02).
