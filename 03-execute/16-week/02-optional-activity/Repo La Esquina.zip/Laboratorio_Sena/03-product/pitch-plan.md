# Plan multimedial para pitch — 3 minutos

> Estado: 🟢 Documentado | Última actualización: 2026-06-20
> Autor: Equipo de Análisis y Desarrollo de Software — SENA | Equipo: ADSO — Competencia 220501046
> Audiencia: Carlos Ruiz (cliente) y evaluadores académicos SENA

Este documento traduce los hallazgos de diagnóstico ([`01-context/overview.md`](../01-context/overview.md)) y la priorización de requisitos ([`04-requirements/functional.md`](../04-requirements/functional.md), [`04-requirements/non-functional.md`](../04-requirements/non-functional.md)) en un guion de presentación comercial de 3 minutos, estructurado en tres segmentos.

## Estructura general

| Segmento | Nombre | Objetivo comunicativo |
| --- | --- | --- |
| Minuto 1 | El Problema — The Pain | Generar empatía y urgencia: hacer visible el costo real de la operación manual. |
| Minuto 2 | La Solución MVP | Demostrar la solución técnica con métricas concretas de mejora operativa. |
| Minuto 3 | El Cierre — Costo-Beneficio | Convencer con el modelo económico y la recuperación de ingresos perdidos. |

---

## Minuto 1 — El Problema (The Pain)

### Diapositiva 1.1 — Portada del problema

- **Título:** *"120 segundos. Eso cuesta cada venta en el Supermercado La Esquina."*
- **Elemento visual:** reloj analógico grande con aguja moviéndose lentamente, fondo oscuro, número 120 en rojo al centro. Texto inferior: "Solo en sumar con calculadora."
- **Dato ancla:** 44% del tiempo de cada transacción = Paso 3 (suma manual). Fuente: ficha de observación directa, horario pico.
- **Guion narrado:** *"Carlos, cada vez que un cliente pone sus productos en el mostrador, usted o su equipo gastan en promedio dos minutos solo sumando con la calculadora. No atendiéndolo. No cobrándole. Solo sumando. Y eso sucede 42 veces al día."*

### Diapositiva 1.2 — El cuello de botella visualizado

- **Título:** *"El embudo roto: 382 segundos por cliente."*
- **Elemento visual:** diagrama de embudo horizontal con 6 fases. La fase 3 ("Sumar precios") en rojo brillante, notoriamente más ancha, con etiqueta "120 s — 44%". Las demás fases en gris claro.
- **Estadísticas de apoyo:** 8 de 90 productos con precio incorrecto (9% de desactualización). 3 clientes reportaron cobros erróneos. 5 de 15 clientes reportaron tiempos de espera inaceptables.
- **Guion narrado:** *"El problema no es solo la velocidad. Ocho de sus 90 productos tienen precio diferente entre el cuaderno y la estantería. Eso significa que en este momento, algunos clientes ya se fueron pagando de más... o de menos. Y usted no lo sabe."*

---

## Minuto 2 — La Solución MVP

### Diapositiva 2.1 — La transformación en números

- **Título:** *"De 382 a 145 segundos: el tiempo que recupera su negocio."*
- **Elemento visual:** dos termómetros paralelos — izquierdo (rojo, lleno) = 382 s / "Hoy"; derecho (azul, parcial) = 145 s / "Con el MVP". Flecha entre ellos: "-62%". Debajo: "= 3,7 horas productivas recuperadas cada día."
- **Dato ancla:** reducción del 62% en tiempo de transacción (de 382 s a 145 s). Equivale a 3,7 horas de productividad diaria recuperada. Fuente: SENA (2026).
- **Guion narrado:** *"El sistema calcula el total en menos de tres segundos. Sin calculadora. Sin errores. El cajero selecciona los productos, el sistema suma, y usted atiende al siguiente cliente. Eso son 237 segundos menos por venta, multiplicado por 42 ventas diarias: 3,7 horas que hoy se pierden y mañana pueden dedicarse a atender, a reponer, o simplemente a cerrar a tiempo."*

### Diapositiva 2.2 — Los 6 módulos en acción

- **Título:** *"Un sistema para su negocio. Seis soluciones para sus seis problemas."*
- **Elemento visual:** panel hexagonal con 6 celdas de color, cada una con ícono y etiqueta — M1-Inventario (📦), M2-POS/Ventas (🛒), M3-Usuarios (👤), M4-Reportes (📊), M5-Tiquetes (🧾), M6-Créditos/Fiado (💳). Al centro: "MVP La Esquina".
- **Control de stock automático:** mensaje emergente: "¡Alerta! Aceite de cocina: 2 unidades restantes." El sistema descuenta el inventario en cada venta y avisa antes del agotamiento, eliminando la gestión por memoria del propietario.
- **Guion narrado:** *"Y no es solo la caja. Cuando el aceite llegue a las últimas dos unidades, el sistema lo notifica automáticamente. No más descubrir que se acabó cuando el cliente lo pide. No más cuadernos. No más pérdidas invisibles."*

---

## Minuto 3 — El Cierre (Costo-Beneficio)

### Diapositiva 3.1 — El modelo económico

- **Título:** *"Paga una vez. Trabaja para siempre."*
- **Elemento visual:** comparativa de dos columnas — izquierda ❌ "Suscripción mensual" (tachado, rojo); derecha ✅ "Costo único de desarrollo" (verde, con sello de garantía). Debajo: listado de beneficios sin costo recurrente.
- **Argumentos clave:** sin cuotas mensuales. Sin dependencia de proveedores externos. El propietario opera el sistema de forma autónoma. Compatible con hardware existente (Android 8.0 / Windows 10 con 2 GB RAM): sin inversión en equipos nuevos.
- **Guion narrado:** *"Este sistema no le cobra mensualmente. No tiene letra pequeña. No necesita llamar a un técnico para actualizar un precio o cerrar la caja. Carlos, usted y su equipo aprenden a usarlo en menos de dos horas, y desde ese día, el negocio es suyo de verdad."*

### Diapositiva 3.2 — Recuperación de ingresos perdidos

- **Título:** *"26,7% de sus clientes se fueron sin comprar. ¿Cuánto dinero es eso?"*
- **Elemento visual:** gráfico circular — 73,3% azul = "Compraron" / 26,7% rojo = "Se fueron sin comprar por falta de pago digital". Fuente: encuesta a 15 clientes. Cifra roja grande: "4 de cada 15 clientes."
- **Impacto de la cartera:** $336.000 COP en cartera activa sin trazabilidad (D02). El Módulo M6 convierte este riesgo en un activo controlado con alertas automáticas de vencimiento.
- **Guion narrado:** *"Y hay más. Cuatro de cada quince personas que entran a su tienda se van sin comprar porque no tienen efectivo. El sistema registra si el pago fue digital, lo que le da información real para tomar la decisión de implementar Nequi o Daviplata cuando usted quiera. Y esos $336.000 que le deben en el cuaderno de fiado... el sistema los vigila por usted, con alertas automáticas cuando alguien lleva más de 30 días sin abonar."*

### Diapositiva 3.3 — Cierre y llamado a la acción

- **Título:** *"La Esquina merece una herramienta a su altura."*
- **Elemento visual:** pantalla de tablet mostrando el POS con una venta completada en 3 segundos. Texto superpuesto en verde: "✅ Venta registrada". Abajo: "6 módulos. 1 solución. 0 suscripciones."
- **Resumen de impactos:** 62% menos tiempo por transacción · 3,7 horas diarias recuperadas · $336.000 COP en cartera controlada · 26,7% de clientes con oportunidad de recuperación · 90 productos con precio siempre correcto.
- **Guion narrado (cierre):** *"Carlos, le proponemos un sistema hecho para usted: sencillo, económico, que funciona sin internet y que su equipo aprende en una jornada. Un sistema que no le cobra mensualidad ni le exige técnico. Solo le pide una cosa: que confíe en que La Esquina puede operar mejor. Nosotros ya hicimos el trabajo de entender su negocio. Ahora le traemos la solución."*

---

## Referencias

- Beck, K., et al. (2001). *Manifiesto por el Desarrollo Ágil de Software*. Agile Alliance.
- SENA. (2026). *SRS — Supermercado "La Esquina" (v1.0)*.
