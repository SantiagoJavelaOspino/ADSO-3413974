# Visión

> Estado: 🟢 Documentado | Última actualización: 2026-06-20
> Autor: Equipo de Análisis y Desarrollo de Software — SENA | Equipo: ADSO — Competencia 220501046

## Propuesta de valor

El Supermercado "La Esquina" opera de forma **100% manual**, mediante cuaderno y calculadora. Esta condición no es solo una incomodidad operativa: representa un costo medible en tiempo, dinero y oportunidades de venta perdidas. La visión de este producto es transformar esa operación manual en un sistema digital de Punto de Venta (POS) e Inventario, simple de adoptar y económicamente sostenible para una microempresa familiar, sin imponer cargas tecnológicas ni financieras que el negocio no pueda asumir.

## De la ineficiencia manual a la recuperación de productividad

La ficha de observación directa en horario pico (12:00–14:00 h) determinó que cada transacción de venta toma en promedio **382 segundos**, de los cuales el paso de **sumar precios con calculadora consume 120 segundos (44% del tiempo total)** — el cuello de botella operativo principal del negocio. Con un promedio de 42,5 ventas diarias, esto representa una inversión diaria de 16.256 segundos en el proceso de cobro, de los cuales 5.100 segundos (85 minutos) corresponden exclusivamente a la suma manual.

La automatización de este paso —mediante el cálculo automático del total en el Módulo M2 (Ventas/POS)— permite reducir el tiempo de transacción de **382 a 145 segundos**, una **reducción del 62%**. Esta mejora se traduce directamente en la recuperación de **3,7 horas de productividad diaria**, tiempo que hoy se pierde sumando con calculadora y que, con el MVP implementado, puede dedicarse a atender clientes, reponer inventario o cerrar el negocio a tiempo.

| Indicador | Antes (manual) | Con el MVP | Mejora |
| --- | --- | --- | --- |
| Tiempo por transacción | 382 segundos | 145 segundos | -62% |
| Tiempo diario en cobro (42,5 ventas/día) | 16.256 segundos | ≈ 6.163 segundos | 3,7 horas recuperadas/día |
| Precisión de catálogo | ~9% de productos desactualizados (8 de 90) | Catálogo digital centralizado | Eliminación de cobros incorrectos |
| Trazabilidad de cartera (fiado) | $336.000 COP sin columna de abonos | Registro digital con alertas de vencimiento | Riesgo patrimonial controlado |

## Justificación de la transformación digital

La transformación no responde a una preferencia tecnológica, sino a brechas operativas evidenciadas mediante triangulación multi-instrumento (entrevista, encuesta, observación directa y revisión documental D01–D06), siguiendo el marco de Sommerville (2016) sobre requisitos implícitos: necesidades reales que el cliente no articula espontáneamente hasta confrontarlas con evidencia documental.

- **Eficiencia de transacción:** el cálculo automático elimina el paso de suma manual, principal cuello de botella (44% del tiempo).
- **Confianza del cliente:** un catálogo digital centralizado elimina la desactualización de precios (~9% del catálogo, D04), que generó cobros incorrectos reportados por al menos tres clientes.
- **Salud financiera:** el Módulo M6 (Gestión de Crédito/Fiado) da trazabilidad a una cartera de $336.000 COP en 12 clientes activos, hoy sin columna de abonos ni saldo actualizado (D02).
- **Oportunidad de ingresos:** el registro del método de pago permite cuantificar la oportunidad de recuperación del 26,7% de clientes (4 de 15 encuestados) que abandonaron una compra por ausencia de pagos digitales.
- **Adopción real:** una interfaz intuitiva (≤2 horas de inducción), modo offline obligatorio y compatibilidad con hardware de bajo costo garantizan que la solución sea efectivamente usable por un equipo de cuatro personas sin formación técnica previa.

## Principio rector

> "Que sea sencillo, que yo pueda aprender en un día." — Carlos Ruiz, propietario.

Esta declaración del cliente, recogida en la entrevista semiestructurada, resume el criterio de diseño que rige todas las decisiones de producto: la solución solo genera valor si el equipo de "La Esquina" puede operarla de forma autónoma, sin depender de soporte técnico externo, desde el primer día de uso.

## Referencias

- SENA. (2026). *SRS — Especificación de Requerimientos de Software: Supermercado "La Esquina" (v1.0)*.
- Sommerville, I. (2016). *Ingeniería de Software* (10.ª ed.). Pearson Educación.
