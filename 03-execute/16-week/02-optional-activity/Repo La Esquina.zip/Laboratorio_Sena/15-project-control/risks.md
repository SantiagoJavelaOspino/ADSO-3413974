# Riesgos

> Estado: 🟢 Documentado | Última actualización: 2026-06-20
> Autor: Equipo de Análisis y Desarrollo de Software — SENA | Equipo: ADSO — Competencia 220501046

## Riesgo financiero — Cartera sin trazabilidad

El cuaderno de fiado (D02) constituye el **principal riesgo financiero documentado** del negocio. La revisión documental, uno de los cuatro instrumentos de recolección aplicados (junto con la entrevista semiestructurada, la ficha de observación directa y la encuesta a clientes), evidenció los siguientes datos cuantitativos sobre la cartera de crédito activa del Supermercado "La Esquina":

| Indicador | Valor documentado (D02) |
| --- | --- |
| Clientes con crédito activo | 12 clientes registrados en el cuaderno de fiado |
| Deuda promedio por cliente | $28.000 COP |
| Cartera total activa | **$336.000 COP** |
| Columna de abonos | INEXISTENTE — no hay registro de pagos parciales |
| Saldo actualizado por cliente | INEXISTENTE — solo se registra el monto inicial del crédito |
| Capacidad de auditoría | NULA — sin trazabilidad ni historial de transacciones |

*Tabla — Indicadores de riesgo financiero, cartera de crédito.*

### Descripción del riesgo

La ausencia de una columna de abonos y de un saldo actualizado en el cuaderno de fiado expone al negocio a **pérdidas no cuantificadas** por omisión o olvido de pagos realizados por los clientes. Sin un mecanismo de registro digital, no existe forma de verificar si un cliente abonó parcialmente su deuda, lo que genera:

- Riesgo de doble cobro o de cobro incompleto a un mismo cliente.
- Imposibilidad de identificar cuáles de los 12 clientes activos llevan más tiempo sin abonar.
- Nula capacidad de auditoría sobre el estado real de la cartera en cualquier punto del tiempo.
- Exposición patrimonial sostenida, ya que el monto de $336.000 COP no está respaldado por ningún control de seguimiento.

### Probabilidad e impacto

| Atributo | Valoración |
| --- | --- |
| Probabilidad | Alta — el riesgo ya se materializa de forma continua bajo el esquema actual de registro en papel. |
| Impacto financiero | Medio-alto — $336.000 COP representan una porción significativa del flujo de caja de una microempresa familiar. |
| Tipo de riesgo | Financiero / operativo — no bloquea las ventas inmediatas, pero compromete la salud patrimonial del negocio en el mediano plazo. |
| Prioridad de mitigación (MoSCoW) | Should Have — RF05, I×U = 4 (Importancia 2 × Urgencia 2). |

### Mitigación propuesta

El **Módulo M6 (Gestión de Crédito / Fiado)** del MVP aborda directamente esta brecha mediante:

1. Registro digital de créditos por cliente, con histórico de transacciones.
2. Registro de abonos (pagos parciales) asociados a cada crédito.
3. Cálculo automático del saldo pendiente actualizado por cliente.
4. Alertas automáticas de vencimiento para deudas con más de 30 días sin abono.

Su priorización como Should Have (RF05) — y no Must Have — se justifica porque, aunque no bloquea las operaciones de venta inmediatas del día a día, representa un riesgo patrimonial sostenido que debe resolverse en una etapa temprana posterior al lanzamiento del MVP, antes de que la cartera continúe creciendo sin control.

### Riesgo relacionado — Ventas perdidas por ausencia de pagos digitales

Como riesgo financiero complementario, la encuesta a 15 clientes habituales reveló que **4 de ellos (26,7%)** abandonaron una compra por ausencia de medios de pago digitales (Nequi, Daviplata, datafono), hallazgo validado por convergencia con la ficha de observación directa (al menos un episodio de retiro de cliente sin comprar registrado en campo). Si bien la integración de pasarelas de pago queda fuera del alcance del MVP (ver [`01-context/scope.md`](../01-context/scope.md)), el registro del método de pago en el Módulo M2 permite cuantificar esta oportunidad de ingresos no capturados para una futura iteración.

## Referencias

- SENA. (2026). *SRS — Supermercado "La Esquina" (v1.0)*.
- Wiegers, K., & Beatty, J. (2013). *Software Requirements* (3.ª ed.). Microsoft Press.
