# Microservicios

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Centraliza el catálogo de microservicios, patrones de comunicación y documentación por servicio.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [service-catalog.md](./service-catalog.md) | Inventario de servicios, owners, repos y estado documental | 🟡 |
| [communication-patterns.md](./communication-patterns.md) | Patrones síncronos, asíncronos y resiliencia | 🟡 |
| [_template/](./_template/) | Plantilla para documentar un servicio nuevo; no representa un microservicio real | 🟡 |
| [services/](./services/) | Documentación específica por microservicio | 🟡 |
