# Modelo de datos del servicio

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Propósito

Definir la estructura mínima de datos que maneja un servicio del MVP La Esquina.

## Secciones sugeridas

- Entidades del servicio
- Atributos principales
- Relaciones con otros contextos
- Reglas de integridad

## Referencias

- [Data dictionary](../../06-data/data-dictionary.md)
- [Entities and rules](../../02-domain/entities-and-rules.md)
