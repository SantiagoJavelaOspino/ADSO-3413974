# Runbook del servicio

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Propósito

Documentar el procedimiento operativo básico para mantener en funcionamiento un servicio del MVP.

## Secciones sugeridas

- Inicio y parada del servicio
- Verificación de salud
- Recuperación ante fallas
- Puntos de contacto

## Referencias

- [Observability](../../13-operations/observability.md)
- [Incident management](../../13-operations/incident-management.md)
