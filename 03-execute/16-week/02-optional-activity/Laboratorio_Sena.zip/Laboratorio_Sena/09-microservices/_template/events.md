# Eventos del servicio

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Propósito

Registrar los eventos de dominio que el servicio publica o consume.

## Secciones sugeridas

- Nombre del evento
- Emisor y consumidores
- Payload
- Condiciones de negocio

## Referencias

- [Domain events](../../02-domain/domain-events.md)
- [Communication patterns](../communication-patterns.md)
