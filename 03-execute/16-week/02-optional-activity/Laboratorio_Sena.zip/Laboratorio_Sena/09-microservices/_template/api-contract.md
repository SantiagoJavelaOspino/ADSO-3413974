# Contrato de API de servicio

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Propósito

Documentar el contrato de entrada/salida de un servicio de negocio asociado a los módulos M1–M6 del MVP.

## Secciones sugeridas

- Operación o endpoint
- Request / Response
- Reglas de negocio aplicadas
- Errores esperados

## Referencias

- [Guidelines](../guidelines.md)
- [Domain events](../../02-domain/domain-events.md)
