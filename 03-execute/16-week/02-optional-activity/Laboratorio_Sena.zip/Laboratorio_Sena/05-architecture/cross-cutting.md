# Aspectos transversales

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Seguridad

- Control de acceso por rol.
- Solo el administrador gestiona productos y configuraciones sensibles.
- No almacenar credenciales ni información sensible en repositorios.

## Observabilidad

- Registro de eventos de venta, stock y fiados.
- Auditoría básica de cambios críticos.

## Resiliencia

- Operación local sin red.
- Reintentos de sincronización con recuperación automática.

## Referencias

- [Overview](./overview.md)
- [Deployment](./deployment.md)
- [Observability](../13-operations/observability.md)
