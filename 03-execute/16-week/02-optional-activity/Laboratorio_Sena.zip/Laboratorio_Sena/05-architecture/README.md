# Arquitectura

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Describe la arquitectura del sistema, despliegue, decisiones técnicas y aspectos transversales.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Vista general de arquitectura y componentes | 🟡 |
| [deployment.md](./deployment.md) | Topología de despliegue y ambientes | 🟡 |
| [cross-cutting.md](./cross-cutting.md) | Seguridad, logging, auditoría, errores y demás aspectos transversales | 🟡 |
| [decisions/](./decisions/) | Registro de decisiones de arquitectura (ADR) | 🟡 |
