# Visión general de arquitectura

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Enfoque arquitectónico

La arquitectura propuesta para el MVP sigue un enfoque offline-first, simple y compatible con hardware de bajo costo. El sistema debe soportar ventas, inventario, fiados y reportes sin exigir infraestructura compleja.

## Componentes principales

- Frontend de caja y administración.
- Motor de reglas de negocio local.
- Almacenamiento local para operación sin conexión.
- Sincronización diferida cuando la conexión vuelve.
- Módulos de reporte, tiquetes y validación de crédito.

## Principios

1. Operar sin internet de forma completa.
2. Reducir dependencia de soporte técnico.
3. Mantener bajo costo de implementación.
4. Separar módulos funcionales por dominio.

## Referencias

- [Deployment](./deployment.md)
- [Cross-cutting](./cross-cutting.md)
- [Mapa de dominio](../02-domain/domain-map.md)
