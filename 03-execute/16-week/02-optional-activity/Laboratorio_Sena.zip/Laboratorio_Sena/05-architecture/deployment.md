# Despliegue

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Topología propuesta

| Capa | Tecnología sugerida | Propósito |
|------|---------------------|-----------|
| Cliente | Tablet Android / PC Windows | Interacción de caja y administración |
| Aplicación local | App local offline-first | Procesar ventas y catálogo |
| Persistencia | Base local / caché | Almacenar ventas, inventario y fiados |
| Sincronización | Servicio de sync diferido | Enviar cambios cuando haya red |

## Requisitos de despliegue

- Compatibilidad con Android 8.0+/Windows 10.
- Mínimo 2 GB RAM.
- Operación continua en condiciones de conectividad variable.

## Referencias

- [Overview](./overview.md)
- [Cross-cutting](./cross-cutting.md)
- [Local setup](../10-devops/local-setup.md)
