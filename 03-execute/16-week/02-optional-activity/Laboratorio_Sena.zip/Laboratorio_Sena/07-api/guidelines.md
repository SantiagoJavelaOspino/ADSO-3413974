# Guías de API

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Principios

- APIs simples y orientadas a operaciones de negocio.
- Respuestas claras y fáciles de consumir desde client local.
- Uso de contratos para ventas, inventario, fiados y reportes.

## Convenciones

- Nombres en español o inglés consistentes con el dominio.
- Manejo uniforme de errores.
- Versionado inicial simple para el MVP.

## Referencias

- [Authentication](./authentication.md)
- [OpenAPI](./contracts/openapi/)
