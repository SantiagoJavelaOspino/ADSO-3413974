# Autenticación

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Modelo de acceso

- Administrador: acceso total a productos, usuarios, reportes y configuración.
- Empleado: acceso a ventas y lectura limitada de inventario.

## Requisitos de autenticación

- Inicio de sesión con credenciales locales.
- Control por rol en cada operación crítica.
- Sesiones simples y de baja complejidad para el entorno del negocio.

## Referencias

- [Guidelines](./guidelines.md)
- [Requisitos no funcionales](../04-requirements/non-functional.md)
