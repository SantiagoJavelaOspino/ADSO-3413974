# Operaciones

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Describe cómo operar, monitorear, responder incidentes y recuperar el sistema.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [observability.md](./observability.md) | Métricas, logs, trazas, alertas y tableros | 🟡 |
| [incident-management.md](./incident-management.md) | Clasificación, respuesta y comunicación de incidentes | 🟡 |
| [backup-and-recovery.md](./backup-and-recovery.md) | Backups, restauración, RPO/RTO y pruebas de recuperación | 🟡 |
