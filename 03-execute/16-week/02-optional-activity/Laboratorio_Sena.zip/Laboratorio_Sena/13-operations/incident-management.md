# Gestión de incidentes

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Flujo básico

1. Detectar la incidencia.
2. Clasificar impacto (operativo, financiero o técnico).
3. Aplicar acción correctiva y documentar.
4. Verificar recuperación.

## Referencias

- [Observability](./observability.md)
- [Backup and recovery](./backup-and-recovery.md)
