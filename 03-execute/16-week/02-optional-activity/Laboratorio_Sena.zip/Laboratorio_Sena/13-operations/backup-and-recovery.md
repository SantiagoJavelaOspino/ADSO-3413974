# Respaldo y recuperación

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Recomendaciones

- Respaldar información diaria de ventas, inventario y fiados.
- Mantener copia local y copia externa de respaldo.
- Verificar periódicamente la recuperación de datos.

## Referencias

- [Observability](./observability.md)
- [Incident management](./incident-management.md)
