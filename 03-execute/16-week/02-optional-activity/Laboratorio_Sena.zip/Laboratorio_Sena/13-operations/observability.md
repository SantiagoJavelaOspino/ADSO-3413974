# Observabilidad

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Métricas clave

- Ventas registradas por día.
- Diferencia entre efectivo físico y ventas registradas.
- Alertas de stock bajo.
- Créditos vencidos sin abono.

## Referencias

- [Incident management](./incident-management.md)
- [Backup and recovery](./backup-and-recovery.md)
