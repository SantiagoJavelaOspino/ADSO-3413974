# Índice de diagramas

| Diagrama | Tipo | Archivo fuente | Exportación | Estado |
|----------|------|---------------|-------------|--------|
| Mapa de dominio | Mermaid | [../02-domain/domain-map.md](../02-domain/domain-map.md) | [exports/](./diagrams/exports/) | 🟡 |
| Eventos de dominio | Mermaid | [../02-domain/domain-events.md](../02-domain/domain-events.md) | [exports/](./diagrams/exports/) | 🟡 |
| Arquitectura general | Mermaid | [../05-architecture/overview.md](../05-architecture/overview.md) | [exports/](./diagrams/exports/) | 🟡 |

## Convención

Los diagramas fuente deben mantenerse sincronizados con sus exportaciones en la carpeta de diagramas.
