# Control de Proyecto

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Agrupa backlog técnico, riesgos, dependencias y preguntas abiertas del proyecto.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [technical-backlog.md](./technical-backlog.md) | Pendientes técnicos y deuda documentada | 🟡 |
| [risks.md](./risks.md) | Riesgos, impacto, probabilidad y mitigación | 🟡 |
| [dependencies.md](./dependencies.md) | Dependencias internas y externas | 🟡 |
| [open-questions.md](./open-questions.md) | Preguntas pendientes de decisión o aclaración | 🟡 |
