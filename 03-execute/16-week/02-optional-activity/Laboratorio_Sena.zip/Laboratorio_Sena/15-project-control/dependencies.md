# Dependencias

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Dependencias identificadas

- Hardware compatible con Android 8.0 / Windows 10.
- Conectividad variable para sincronización diferida.
- Documentación del SRS como fuente de verdad.
- Reglas de negocio definidas en dominio y requisitos.

## Referencias

- [Risks](./risks.md)
- [Open questions](./open-questions.md)
