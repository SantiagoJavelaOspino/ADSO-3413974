# Backlog técnico

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Pendientes técnicos

- Definir arquitectura concreta de sincronización offline.
- Definir contratos de API para ventas e inventario.
- Preparar plantillas de despliegue y pruebas.
- Definir almacenamiento persistente local y remoto.

## Referencias

- [Dependencies](./dependencies.md)
- [Risks](./risks.md)
- [Componentes de arquitectura](../05-architecture/overview.md)
