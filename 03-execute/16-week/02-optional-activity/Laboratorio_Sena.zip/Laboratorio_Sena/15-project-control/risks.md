# Riesgos

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Riesgos principales

| Riesgo | Impacto | Mitigación |
|--------|---------|------------|
| Resistencia tecnológica del propietario | Alta | Diseño sencillo y capacitación breve |
| Interrupciones de conectividad | Alta | Arquitectura offline-first |
| Pérdida de control financiero por fiados | Alta | Registro digital de abonos y alertas |
| Desactualización de precios | Media | Catálogo centralizado y actualización sencilla |

## Referencias

- [Open questions](./open-questions.md)
- [Dependencies](./dependencies.md)
- [Scope](../01-context/scope.md)
