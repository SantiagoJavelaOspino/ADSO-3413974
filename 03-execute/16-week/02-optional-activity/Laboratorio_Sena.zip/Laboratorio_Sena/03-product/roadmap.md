# Roadmap del producto

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Fase 1 — MVP base

- Implementar módulos M1, M2, M3, M4, M5 y M6 en alcance inicial.
- Priorizar registro de ventas, catálogo, usuarios, corte de caja y fiados.
- Asegurar funcionamiento offline-first y facilidad de uso.

## Fase 2 — Consolidación operativa

- Ajustar alertas de stock y flujos de corte de caja.
- Mejorar trazabilidad de ventas y cartera.
- Validar la experiencia del equipo operativo con inducción de máximo 2 horas.

## Fase 3 — Escalabilidad

- Explorar integración con pagos digitales.
- Evaluar gestión de proveedores y reportes más avanzados.
- Considerar expansión del alcance más allá del MVP.

## Hitos propuestos

| Fase | Hito | Resultado esperado |
|------|------|--------------------|
| F1 | MVP funcional | Operación de ventas e inventario del negocio |
| F2 | Tranzabilidad y control | Reportes y fiados operativos |
| F3 | Escalabilidad | Integraciones y extensiones futuras |

## Referencias

- [Visión del producto](./vision.md)
- [Backlog de producto](./product-backlog.md)
- [Alcance del MVP](../01-context/scope.md)
