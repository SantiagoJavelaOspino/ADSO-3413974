# Backlog de producto

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Priorización MoSCoW

| ID | Historia / elemento | Prioridad | Justificación |
|----|---------------------|-----------|---------------|
| RF01 | Registrar venta con cálculo automático | Must Have | Elimina el cuello de botella de suma manual |
| RF02 | Gestionar catálogo de productos | Must Have | Evita errores de precio y desactualización |
| RNF01 | Interfaz intuitiva | Must Have | Requisito de adopción en ≤2 horas |
| RNF02 | Modo offline | Must Have | Esencial para continuidad operativa |
| RNF05 | Compatibilidad con hardware básico | Must Have | Permite implementación económica |
| RN01 | Modelo de costo único | Must Have | Requisito de negocio y financiero |
| RN02 | Autonomía operativa | Must Have | Evita dependencia de soporte externo |
| RF03 | Alertas de stock | Should Have | Mejora control de inventario |
| RF04 | Corte de caja diario | Should Have | Mejora trazabilidad financiera |
| RF05 | Gestión de crédito y fiado | Should Have | Controla riesgo patrimonial |
| RF06 | Generación de tiquete | Should Have | Mejora comprobantes de venta |
| RNF03 | Tiempo de respuesta ≤3 s | Should Have | Soporte a experiencia fluida |
| RNF04 | Control de acceso por roles | Should Have | Seguridad básica del sistema |
| RNF06 | Actualización de catálogo sin técnico | Should Have | Soporta autonomía operativa |
| RNF08 | Respaldo automático diario | Should Have | Protección de datos |
| RF07 | Historial de ventas con filtros | Could Have | Valor adicional |
| RF08 | Gestión de proveedores | Could Have | Ampliación futura |
| RF09 | Notificaciones de pedidos sugeridos | Could Have | Escalabilidad de inventario |
| RF10 | Reporte de productos más vendidos | Could Have | Análisis posterior |
| RNF07 | Escalabilidad a 300 productos | Could Have | Posterior crecimiento |

## Riesgos asociados

- Dependencia del negocio en procesos manuales actuales.
- Resistencia tecnológica moderada del propietario.
- Limitaciones de conectividad en horario comercial.

## Referencias

- [Visión del producto](./vision.md)
- [Roadmap](./roadmap.md)
- [Requisitos funcionales](../04-requirements/functional.md)
