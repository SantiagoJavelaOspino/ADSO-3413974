# Producto

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Documenta la intención del producto, evolución esperada y backlog funcional de alto nivel.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [vision.md](./vision.md) | Visión, objetivos de producto y propuesta de valor | 🟡 |
| [roadmap.md](./roadmap.md) | Hitos, fases y evolución planificada | 🟡 |
| [product-backlog.md](./product-backlog.md) | Backlog priorizado de producto | 🟡 |
