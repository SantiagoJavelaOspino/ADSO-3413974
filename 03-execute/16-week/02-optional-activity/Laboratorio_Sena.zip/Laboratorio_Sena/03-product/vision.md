# Visión del producto

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contexto

La visión del producto se deriva del SRS v1.0 para el Supermercado "La Esquina" y define el propósito del MVP de POS e inventario.

## Visión

Desarrollar un sistema simple, económico y operativo que permita al negocio registrar ventas, controlar inventario y administrar fiados sin depender de procesos manuales ni de soporte técnico externo.

## Propuesta de valor

- Reducir el tiempo de cobro de 382,5 s a 145 s por transacción.
- Eliminar errores de suma y de precio en caja.
- Centralizar el catálogo de productos y stock disponible.
- Dar trazabilidad a la cartera de fiado y al cierre de caja.
- Mantener una solución usable por usuarios con poca experiencia tecnológica.

## Objetivos de producto

| ID | Objetivo | Métrica de éxito |
|----|----------|------------------|
| OBJ-01 | Eliminar la suma manual en caja | Reducción del 62% en tiempo de transacción |
| OBJ-02 | Centralizar catálogo de productos | 0 discrepancias entre precio del sistema y la tienda |
| OBJ-03 | Dar trazabilidad a créditos y abonos | Registro digital de cartera activa |
| OBJ-04 | Permitír autonomía operativa | Inducción de máximo 2 horas |
| OBJ-05 | Operar con continuidad | Funcionamiento offline-first |

## Principios del producto

1. Simplicidad operativa para usuarios no técnicos.
2. Bajo costo total de adopción.
3. Funcionamiento continuo aunque la red falle.
4. Trazabilidad de ventas, inventario y cartera.
5. Evolución incremental desde un MVP claro.

## Alcance estratégico del MVP

El MVP cubre seis módulos: inventario, POS, usuarios, reportes, tiquetes y crédito. La integración con pagos digitales y facturación electrónica se postergan a futuras iteraciones.

## Referencias

- [Alcance](../01-context/scope.md)
- [Backlog de producto](./product-backlog.md)
- [Roadmap](./roadmap.md)
