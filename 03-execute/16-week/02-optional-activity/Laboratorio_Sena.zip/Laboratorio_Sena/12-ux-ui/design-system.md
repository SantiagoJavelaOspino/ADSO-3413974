# Sistema de diseño

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Directrices visuales

- Interfaz sencilla y legible.
- Uso de etiquetas claras en español colombiano.
- Priorizar acciones de venta y catálogo.
- Diseño usable para usuarios sin experiencia previa.

## Componentes sugeridos

- Pantalla de venta.
- Lista de productos.
- Alertas de stock.
- Vista de corte de caja.
- Formulario de fiados.

## Referencias

- [Navigation map](./navigation-map.md)
- [Wireframes](./wireframes.md)
