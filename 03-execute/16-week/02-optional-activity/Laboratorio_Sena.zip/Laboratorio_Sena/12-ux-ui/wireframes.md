# Wireframes

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Propuesta de pantallas

- Pantalla de venta con carrito y total automático.
- Pantalla de productos con stock y precio.
- Pantalla de fiados con saldo pendiente.
- Pantalla de corte de caja con resumen diario.

## Referencias

- [Navigation map](./navigation-map.md)
- [Design system](./design-system.md)
