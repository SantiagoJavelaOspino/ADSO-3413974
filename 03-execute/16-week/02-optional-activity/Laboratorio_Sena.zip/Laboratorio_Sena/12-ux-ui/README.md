# UX/UI

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Documenta sistema de diseño, navegación y wireframes del producto.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [design-system.md](./design-system.md) | Tokens, componentes, patrones visuales y reglas UX/UI | 🟡 |
| [navigation-map.md](./navigation-map.md) | Mapa de navegación y jerarquía de pantallas | 🟡 |
| [wireframes.md](./wireframes.md) | Wireframes y referencias de interacción | 🟡 |
