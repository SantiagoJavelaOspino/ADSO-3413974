# Mapa de navegación

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Estructura propuesta

- Inicio / Venta
- Catálogo de productos
- Reportes y corte de caja
- Crédito y fiados
- Configuración de administrador

## Referencias

- [Design system](./design-system.md)
- [Wireframes](./wireframes.md)
