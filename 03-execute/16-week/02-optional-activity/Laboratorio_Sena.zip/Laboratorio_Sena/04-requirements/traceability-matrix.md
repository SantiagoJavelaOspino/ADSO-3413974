# Matriz de trazabilidad

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Objetivo

Mantener trazabilidad entre los requisitos del SRS, las historias de usuario, las decisiones de arquitectura y la documentación de soporte.

## Matriz

| ID requisito | Tipo | Historia | Módulo | Documento de apoyo |
|--------------|------|----------|--------|---------------------|
| RF01 | Funcional | US02 | M2 | [functional.md](./functional.md) |
| RF02 | Funcional | US01 | M1 | [functional.md](./functional.md) |
| RF03 | Funcional | US03 | M1 | [functional.md](./functional.md) |
| RF04 | Funcional | US04 | M4 | [functional.md](./functional.md) |
| RF05 | Funcional | US05 | M6 | [functional.md](./functional.md) |
| RF06 | Funcional | US06 | M5 | [functional.md](./functional.md) |
| RNF01 | No funcional | US02 | M2/M3 | [non-functional.md](./non-functional.md) |
| RNF02 | No funcional | US02 | Infraestructura | [non-functional.md](./non-functional.md) |
| RNF05 | No funcional | US01/US02 | M1/M2 | [non-functional.md](./non-functional.md) |
| RN01 | Negocio | US01/US02 | Modelo de negocio | [non-functional.md](./non-functional.md) |
| RN02 | Negocio | US01/US02 | Operación | [non-functional.md](./non-functional.md) |

## Evidencia documental base

- [Overview](../01-context/overview.md)
- [Scope](../01-context/scope.md)
- [Entidades y reglas](../02-domain/entities-and-rules.md)
- [Mapa de dominio](../02-domain/domain-map.md)
- [Roadmap](../03-product/roadmap.md)

## Criterio de actualización

Toda modificación funcional o arquitectónica debe reflejarse aquí para mantener coherencia documental.
