# Historias de usuario

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Historias principales

| ID | Historia | Criterios de aceptación |
|----|----------|--------------------------|
| US01 | Como administrador, quiero registrar productos para mantener el catálogo actualizado. | Se pueden crear, editar y eliminar productos; solo el Administrador puede hacerlo. |
| US02 | Como cajero, quiero registrar una venta rápidamente para atender a los clientes sin demoras. | Se seleccionan productos, se calcula el total automáticamente y se guarda la venta. |
| US03 | Como propietario, quiero ver los productos con stock bajo para evitar agotamientos. | El sistema muestra alertas cuando el stock está en o por debajo del mínimo. |
| US04 | Como administrador, quiero generar un corte de caja para cerrar el día con trazabilidad. | Se resumen ventas por método de pago y se compara con efectivo físico. |
| US05 | Como administrador, quiero registrar fiados y abonos para controlar la cartera. | Se registran créditos, abonos y el saldo pendiente actualizado. |
| US06 | Como cajero, quiero imprimir o enviar un tiquete para entregar comprobante al cliente. | El sistema genera un tiquete al completar una venta. |

## Relación con requisitos

- US01 → RF02, RNF04, RNF06
- US02 → RF01, RNF03
- US03 → RF03, RNF06
- US04 → RF04
- US05 → RF05
- US06 → RF06

## Referencias

- [Requisitos funcionales](./functional.md)
- [Requisitos no funcionales](./non-functional.md)
- [Matriz de trazabilidad](./traceability-matrix.md)
