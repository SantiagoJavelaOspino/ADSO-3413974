# Requisitos funcionales

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Resumen

Los requisitos funcionales del SRS se agrupan en los módulos M1–M6 del MVP para el Supermercado "La Esquina".

## Requisitos funcionales

| ID | Requisito | Módulo | Prioridad | Descripción |
|----|-----------|--------|-----------|-------------|
| RF01 | Registro de venta / POS básico | M2 | Must Have | Registrar venta, seleccionar productos, calcular total y registrar método de pago. |
| RF02 | Catálogo de productos | M1 | Must Have | Gestionar hasta 90 productos con nombre, precio, categoría, stock y stock mínimo. |
| RF03 | Control de inventario y alertas | M1 | Should Have | Alertar al administrador cuando el stock se acerque al mínimo. |
| RF04 | Corte de caja diario | M4 | Should Have | Resumir ventas, diferencia versus caja física y filtros de consulta. |
| RF05 | Gestión de crédito / fiado | M6 | Should Have | Registrar créditos, abonos, saldos y alertas de vencimiento. |
| RF06 | Generación de tiquete | M5 | Should Have | Emitir comprobante en formato impreso o digital al completar venta. |
| RF07 | Historial de ventas con filtros | M4 | Could Have | Consultar historial de ventas por filtros básicos. |
| RF08 | Gestión de proveedores | M1/M4 | Could Have | Comparar precio factura vs. precio de venta. |
| RF09 | Notificación de pedidos sugeridos | M1 | Could Have | Sugerir reposición según stock mínimo. |
| RF10 | Reporte de productos más vendidos | M4 | Could Have | Analizar productos con mayor volumen de venta. |

## Reglas operativas asociadas

- Solo el Administrador puede crear, editar o eliminar productos.
- Al confirmar una venta se descuenta stock automáticamente.
- El sistema registra el método de pago (efectivo/digital).
- Los tiquetes se generan al completar la venta.

## Referencias

- [Scope](../01-context/scope.md)
- [Entidades y reglas](../02-domain/entities-and-rules.md)
- [Matriz de trazabilidad](./traceability-matrix.md)
