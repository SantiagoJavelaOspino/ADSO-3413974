# Requisitos no funcionales

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Resumen

Los requisitos no funcionales del SRS priorizan usabilidad, disponibilidad, compatibilidad, costo y operabilidad para un entorno de microempresa familiar.

## Requisitos no funcionales

| ID | Requisito | Prioridad | Descripción |
|----|-----------|-----------|-------------|
| RNF01 | Interfaz intuitiva | Must Have | El operador debe poder aprender el sistema en máximo 2 horas. |
| RNF02 | Modo offline | Must Have | Operación completa sin conexión y sincronización < 5 min al recuperar red. |
| RNF03 | Tiempo de respuesta | Should Have | Procesamiento de ventas y consultas en ≤3 s. |
| RNF04 | Control de acceso por roles | Should Have | Administrador y Empleado con permisos diferenciados. |
| RNF05 | Compatibilidad con hardware de bajo costo | Must Have | Ejecutarse en Android 8.0+/Windows 10 con 2 GB RAM. |
| RNF06 | Actualización del catálogo sin técnico | Should Have | El administrador debe poder actualizar precios de forma autónoma. |
| RNF07 | Escalabilidad arquitectural | Could Have | Soportar crecimiento a 300 productos. |
| RNF08 | Respaldo automático diario | Should Have | Proteger información operativa y financiera. |

## Restricciones de calidad

- Diseño simple y enfocado en operación diaria.
- Bajo costo de adquisición y mantenimiento.
- Autonomía del negocio en tareas operativas básicas.
- Compatibilidad con hardware existente.

## Referencias

- [Alcance](../01-context/scope.md)
- [Entidades y reglas](../02-domain/entities-and-rules.md)
- [Matriz de trazabilidad](./traceability-matrix.md)
