# Calidad

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Define prácticas de pruebas, revisión de código y criterios de calidad.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [testing-strategy.md](./testing-strategy.md) | Estrategia de pruebas por nivel y tipo | 🟡 |
| [code-review.md](./code-review.md) | Criterios y flujo para revisiones de código | 🟡 |
