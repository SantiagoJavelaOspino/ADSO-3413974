# Revisión de código

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Criterios

- Verificar que se cumplan los requisitos del sprint.
- Revisar reglas de negocio y manejo de stock.
- Confirmar que no se introduzcan errores en cálculos de venta o fiado.

## Proceso

1. Revisar alcance y criterios de aceptación.
2. Validar cambios de dominio y negocio.
3. Aprobar solo cuando la lógica y la trazabilidad sean claras.

## Referencias

- [Testing strategy](./testing-strategy.md)
- [Definition of done](../00-governance/definition-of-done.md)
