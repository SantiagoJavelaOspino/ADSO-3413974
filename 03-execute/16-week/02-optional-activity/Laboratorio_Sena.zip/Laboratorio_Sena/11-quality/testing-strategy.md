# Estrategia de pruebas

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Objetivo

Validar que el MVP cumpla requisitos básicos de venta, inventario, fiados y usabilidad.

## Tipos de pruebas

- Pruebas funcionales de ventas y catálogo.
- Pruebas de regresión para precios y stock.
- Pruebas de usabilidad con inducción máxima de 2 horas.
- Pruebas de resiliencia offline.

## Referencias

- [Code review](./code-review.md)
- [Requisitos funcionales](../04-requirements/functional.md)
