# Configuración local

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Objetivo

Preparar un entorno local para desarrollar y validar el MVP de forma simple y económica.

## Pasos sugeridos

1. Instalar el entorno de ejecución compatible con Android/Windows.
2. Configurar almacenamiento local para datos operativos.
3. Validar funcionamiento offline.
4. Ejecutar pruebas básicas de venta, inventario y corte de caja.

## Referencias

- [README](./README.md)
- [Environments](./environments.md)
- [CI/CD](./ci-cd.md)
