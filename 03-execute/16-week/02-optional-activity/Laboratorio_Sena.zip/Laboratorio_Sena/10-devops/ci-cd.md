# CI/CD

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Objetivo

Asegurar calidad básica y trazabilidad del software en cada cambio relevante.

## Prácticas recomendadas

- Validación de documentación y requisitos antes de integrar cambios.
- Revisión de cambios por módulo.
- Ejecución de pruebas funcionales básicas en ventas e inventario.

## Referencias

- [Local setup](./local-setup.md)
- [Testing strategy](../11-quality/testing-strategy.md)
