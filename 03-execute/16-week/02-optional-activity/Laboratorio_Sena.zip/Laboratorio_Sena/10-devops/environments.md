# Entornos

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Entornos propuestos

| Entorno | Propósito |
|---------|-----------|
| Local | Desarrollo y validación inicial |
| Pruebas | Validación funcional del MVP |
| Producción | Operación del negocio |

## Reglas

- No usar producción para pruebas sin respaldo.
- Mantener consistencia con la documentación del SRS.

## Referencias

- [Local setup](./local-setup.md)
- [CI/CD](./ci-cd.md)
