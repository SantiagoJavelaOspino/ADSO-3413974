# DevOps

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Documenta instalación local, CI/CD y ambientes del proyecto.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [local-setup.md](./local-setup.md) | Preparación del entorno local de desarrollo | 🟡 |
| [ci-cd.md](./ci-cd.md) | Pipelines, despliegues y controles de calidad automatizados | 🟡 |
| [environments.md](./environments.md) | Ambientes, propósito y reglas de uso | 🟡 |
