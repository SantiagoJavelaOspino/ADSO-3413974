# Entidades y reglas de negocio

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contexto

Entidades del dominio, invariantes y reglas de negocio (**RN**) del Supermercado "La Esquina". Complementa el [diccionario de datos](../06-data/data-dictionary.md).

## Contenido

### Entidades principales

#### Producto (M1)

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id | UUID | Identificador único |
| nombre | String | Nombre comercial |
| precio | Decimal (COP) | Precio de venta vigente |
| categoria | String | Categoría de consumo masivo |
| stockActual | Integer | Unidades disponibles |
| stockMinimo | Integer | Umbral para alerta (RF03) |

**Invariantes:** precio > 0; stockActual ≥ 0; stockMinimo ≥ 0. Máximo 90 productos activos en MVP.

#### Venta (M2)

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id | UUID | Identificador de transacción |
| fechaHora | DateTime | Timestamp de la venta |
| total | Decimal (COP) | Total calculado automáticamente |
| metodoPago | Enum | `EFECTIVO` \| `DIGITAL` |
| usuarioId | UUID | Cajero que registró la venta |
| detalles | List\<DetalleVenta\> | Productos y cantidades |

#### DetalleVenta

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| productoId | UUID | Referencia al producto |
| cantidad | Integer | Unidades vendidas |
| precioUnitario | Decimal | Precio al momento de la venta |
| subtotal | Decimal | cantidad × precioUnitario |

#### Usuario (M3)

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id | UUID | Identificador |
| nombre | String | Nombre del operario |
| rol | Enum | `ADMINISTRADOR` \| `EMPLEADO` |
| activo | Boolean | Estado de la cuenta |

#### Cliente (M6)

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id | UUID | Identificador |
| nombre | String | Nombre del cliente fiado |
| telefono | String | Contacto opcional |

#### Crédito / Fiado (M6)

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id | UUID | Identificador del crédito |
| clienteId | UUID | Cliente asociado |
| montoInicial | Decimal (COP) | Deuda original |
| saldoPendiente | Decimal (COP) | Saldo actualizado |
| fechaCreacion | Date | Fecha del fiado |
| abonos | List\<Abono\> | Pagos parciales registrados |

**Datos documentados (D02):** 12 clientes activos · cartera total $336.000 COP · promedio $28.000 COP/cliente.

#### Abono (M6)

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id | UUID | Identificador |
| creditoId | UUID | Crédito asociado |
| monto | Decimal (COP) | Valor del abono |
| fecha | Date | Fecha del pago |

#### CorteCaja (M4)

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id | UUID | Identificador |
| fecha | Date | Día del corte |
| totalVentas | Decimal | Suma ventas registradas |
| totalEfectivo | Decimal | Ventas en efectivo |
| totalDigital | Decimal | Ventas digitales registradas |
| efectivoFisico | Decimal | Efectivo contado en caja |
| diferencia | Decimal | efectivoFisico − totalEfectivo |

#### Tiquete (M5)

| Atributo | Tipo | Descripción |
|----------|------|-------------|
| id | UUID | Identificador |
| ventaId | UUID | Venta asociada |
| formato | Enum | `IMPRESO` \| `PDF` \| `WHATSAPP` |
| contenido | String | Datos del comprobante |

### Reglas de negocio

#### RN01 — Modelo de Costo Único (Must Have)

| Campo | Valor |
|-------|-------|
| **ID** | RN01 |
| **Descripción** | El sistema debe adquirirse bajo esquema de costo único de desarrollo o licencia anual. No se aceptan suscripciones mensuales recurrentes de alto costo. |
| **I × U** | 9 — Must Have |
| **Justificación** | Carlos Ruiz declaró que el negocio no puede comprometer pagos mensuales fijos adicionales. Microempresa con flujo de caja variable. |
| **Trazabilidad** | [non-functional.md](../04-requirements/non-functional.md), [risks.md](../15-project-control/risks.md) |

#### RN02 — Autonomía Operativa (Must Have)

| Campo | Valor |
|-------|-------|
| **ID** | RN02 |
| **Descripción** | El negocio no debe depender de asistencia técnica externa para operaciones diarias. El propietario resuelve reinicio, actualización de precios y corte de caja de forma autónoma. |
| **I × U** | 9 — Must Have |
| **Justificación** | Sin soporte técnico presencial inmediato en el sector. Ninguno de los 4 operarios tiene formación técnica. Extensión de RNF01. |
| **Trazabilidad** | RNF01, RNF06, [admin-manual.md](../14-training/admin-manual.md) |

#### Reglas operativas derivadas

| ID | Regla | Módulo |
|----|-------|--------|
| RN-OP-01 | Solo el Administrador crea, edita o elimina productos | M1 / RF02 |
| RN-OP-02 | Al confirmar venta se descuenta stock automáticamente | M2 → M1 |
| RN-OP-03 | Alerta de vencimiento cuando fiado supera 30 días sin abono | M6 / RF05 |
| RN-OP-04 | Empleado no puede modificar precios ni eliminar productos | M3 / RNF04 |
| RN-OP-05 | Ventas e inventario operan sin conexión; sync < 5 min al reconectar | RNF02 |

## Referencias

- [Mapa de dominio](./domain-map.md)
- [Eventos de dominio](./domain-events.md)
- [Requisitos funcionales](../04-requirements/functional.md)
