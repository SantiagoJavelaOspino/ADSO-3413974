# Eventos de dominio

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contexto

Eventos significativos del dominio **La Esquina** que disparan acciones en otros contextos o módulos. Base para integración futura entre microservicios.

## Contenido

### Catálogo de eventos

| Evento | Contexto origen | Payload | Consumidores | Requisito |
|--------|-----------------|---------|--------------|-----------|
| `ProductoCreado` | M1 Inventario | productoId, nombre, precio, stock | M2 POS (catálogo) | RF02 |
| `ProductoActualizado` | M1 Inventario | productoId, camposModificados | M2 POS | RF02, RNF06 |
| `StockBajoDetectado` | M1 Inventario | productoId, stockActual, stockMinimo | M4 Reportes, UI alertas | RF03 |
| `VentaRegistrada` | M2 POS | ventaId, total, metodoPago, detalles | M1, M4, M5 | RF01 |
| `VentaCompletada` | M2 POS | ventaId, total | M5 Tiquetes | RF06 |
| `TiqueteGenerado` | M5 Facturación | tiqueteId, ventaId, formato | — | RF06 |
| `CorteCajaRealizado` | M4 Reportes | corteId, fecha, diferencia | — | RF04 |
| `CreditoRegistrado` | M6 Fiado | creditoId, clienteId, monto | M4 Reportes | RF05 |
| `AbonoRegistrado` | M6 Fiado | abonoId, creditoId, monto, saldoPendiente | M4 Reportes | RF05 |
| `CreditoVencido` | M6 Fiado | creditoId, clienteId, diasSinAbono | UI alertas | RF05 |
| `DatosSincronizados` | Infraestructura | timestamp, registrosPendientes | — | RNF02 |
| `ConexionRecuperada` | Infraestructura | timestamp | Sync service | RNF02 |

### Flujo — Venta registrada

```mermaid
sequenceDiagram
    participant POS as M2 POS
    participant INV as M1 Inventario
    participant TIQ as M5 Tiquetes
    participant REP as M4 Reportes

    POS->>POS: Calcular total automático
    POS->>INV: VentaRegistrada (descontar stock)
    INV-->>POS: Stock actualizado
    alt stock <= mínimo
        INV->>INV: StockBajoDetectado
    end
    POS->>TIQ: VentaCompletada
    TIQ->>TIQ: TiqueteGenerado
    POS->>REP: Actualizar totales del día
```

### Flujo — Alerta de fiado vencido

```mermaid
sequenceDiagram
    participant M6 as M6 Crédito
    participant UI as Interfaz Admin

    M6->>M6: Evaluar días sin abono
    alt > 30 días
        M6->>UI: CreditoVencido
    end
```

## Referencias

- [Mapa de dominio](./domain-map.md)
- [Entidades y reglas](./entities-and-rules.md)
- [Patrones de comunicación](../09-microservices/communication-patterns.md)
