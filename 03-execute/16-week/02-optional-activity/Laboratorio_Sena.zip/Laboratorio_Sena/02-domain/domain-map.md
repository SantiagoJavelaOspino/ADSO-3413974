# Mapa de dominio

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contexto

Mapa de contextos delimitados del MVP **La Esquina**, derivado de los seis módulos funcionales del SRS (M1–M6). Para persistencia ver [06-data/models.md](../06-data/models.md).

## Contenido

### Diagrama de contextos

```mermaid
flowchart TB
    subgraph M1["M1 — Inventario y Catálogo"]
        P[Producto]
        C[Categoría]
        S[Stock / Alertas]
    end

    subgraph M2["M2 — Ventas / POS"]
        V[Venta]
        DV[DetalleVenta]
        MP[MétodoPago]
    end

    subgraph M3["M3 — Usuarios y Roles"]
        U[Usuario]
        R[Rol]
    end

    subgraph M4["M4 — Reportes y Corte de Caja"]
        CC[CorteCaja]
        RPT[Reporte]
    end

    subgraph M5["M5 — Facturación / Tiquetes"]
        T[Tiquete]
    end

    subgraph M6["M6 — Gestión de Crédito / Fiado"]
        CR[Crédito]
        AB[Abono]
        CL[Cliente]
    end

    M2 --> M1
    M2 --> M5
    M2 --> M4
    M6 --> CL
    M6 --> M4
    M3 --> M1
    M3 --> M2
    M3 --> M4
    M3 --> M6
```

### Bounded contexts

| Contexto | Módulo | Responsabilidad | Agregado raíz |
|----------|--------|-----------------|---------------|
| Catálogo e Inventario | M1 | CRUD productos, stock, alertas mínimas | `Producto` |
| Punto de Venta | M2 | Registro de transacciones, cálculo automático | `Venta` |
| Identidad y Acceso | M3 | Autenticación, roles Administrador/Empleado | `Usuario` |
| Reportes y Caja | M4 | Corte diario, conciliación, filtros | `CorteCaja` |
| Comprobantes | M5 | Emisión tiquete impreso/digital | `Tiquete` |
| Crédito al Cliente | M6 | Fiado, abonos, alertas vencimiento | `Crédito` |

### Integración entre contextos

| Origen | Destino | Relación |
|--------|---------|----------|
| M2 Ventas | M1 Inventario | Descuenta stock al confirmar venta |
| M2 Ventas | M5 Tiquetes | Genera comprobante al cerrar venta |
| M2 Ventas | M4 Reportes | Alimenta totales del corte de caja |
| M6 Crédito | M4 Reportes | Incluye cartera en reportes financieros |
| M3 Usuarios | Todos | Control de acceso por rol |

## Referencias

- [Entidades y reglas](./entities-and-rules.md)
- [Eventos de dominio](./domain-events.md)
- [Alcance M1–M6](../01-context/scope.md)
