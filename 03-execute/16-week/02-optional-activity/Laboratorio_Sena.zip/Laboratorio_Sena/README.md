# Laboratorio_Sena

Repositorio oficial de documentación del proyecto **Sistema POS e Inventario – Supermercado "La Esquina"**.

Este repositorio constituye la **fuente de verdad documental** del proyecto desarrollado en el marco de la Tecnología en Análisis y Desarrollo de Software (SENA). Toda la documentación técnica, funcional y arquitectónica se encuentra organizada por dominios, permitiendo mantener la trazabilidad completa desde los objetivos del negocio hasta la implementación y operación del sistema.

El contenido del repositorio se basa en la **Especificación de Requerimientos de Software (SRS v1.0)** del proyecto *Supermercado "La Esquina"* y sigue buenas prácticas de documentación establecidas por IEEE 830, ISO/IEC 25010 y la metodología de priorización MoSCoW.

---

# Objetivo

Centralizar la documentación del proyecto para facilitar:

- Gestión de requisitos.
- Diseño de arquitectura.
- Modelado del dominio.
- Diseño de base de datos.
- Definición de APIs.
- Diagramas UML.
- Manuales técnicos y de usuario.
- Control documental del proyecto.
- Trazabilidad completa durante el ciclo de vida del software.

---

# Reglas generales

Todo cambio realizado en este repositorio debe cumplir las siguientes políticas:

- Trabajar mediante ramas (feature branches).
- Realizar Pull Request antes de integrar cambios.
- No modificar directamente las ramas `main`, `qa` o `dev`.
- Mantener consistencia entre documentación y SRS.
- Registrar los cambios relevantes en `CHANGELOG.md`.
- Actualizar el README correspondiente cuando se agreguen nuevos documentos.
- No eliminar documentación histórica; utilizar `99-archive/`.
- No almacenar credenciales, contraseñas, llaves privadas o información sensible.
- Mantener sincronizados los diagramas fuente y sus exportaciones.

---

# Estructura del repositorio

| Sección | Descripción | Estado |
|---------|-------------|--------|
| [00-governance](./00-governance/) | Gobierno documental, estándares y convenciones | 🟡 |
| [01-context](./01-context/) | Contexto del negocio, stakeholders, alcance y glosario | 🟡 |
| [02-domain](./02-domain/) | Modelo de dominio, procesos y reglas de negocio | 🟡 |
| [03-product](./03-product/) | Visión del producto, roadmap y estrategia del MVP | 🟡 |
| [04-requirements](./04-requirements/) | Requisitos funcionales, no funcionales y trazabilidad | 🟡 |
| [05-architecture](./05-architecture/) | Arquitectura de software y decisiones arquitectónicas | 🟡 |
| [06-data](./06-data/) | Modelo de datos, diccionario y estrategia de persistencia | 🟡 |
| [07-api](./07-api/) | Contratos API, autenticación y especificaciones OpenAPI | 🟡 |
| [08-uml](./08-uml/) | Diagramas UML del sistema | 🟡 |
| [09-microservices](./09-microservices/) | Documentación de servicios y componentes | 🟡 |
| [10-devops](./10-devops/) | Infraestructura, CI/CD y entornos | 🟡 |
| [11-quality](./11-quality/) | Estrategia de calidad, pruebas y revisiones | 🟡 |
| [12-ux-ui](./12-ux-ui/) | Wireframes, navegación y sistema de diseño | 🟡 |
| [13-operations](./13-operations/) | Operación, monitoreo, respaldo y recuperación | 🟡 |
| [14-training](./14-training/) | Manuales de usuario, administrador y capacitación | 🟡 |
| [15-project-control](./15-project-control/) | Riesgos, dependencias, backlog y control del proyecto | 🟡 |
| [99-archive](./99-archive/) | Documentación histórica o deprecada | 🟡 |

---

# Estado de la documentación

| Icono | Estado |
|-------|--------|
| 🟢 | Documentación completa |
| 🟡 | En revisión |
| 🔴 | Pendiente |
| ⚫ | Documento deprecado |

---

# Estándares utilizados

La documentación del proyecto se elaboró siguiendo las siguientes referencias:

- IEEE Std 830 – Software Requirements Specification.
- ISO/IEC 25010 – Calidad del Producto Software.
- Modelo de priorización MoSCoW.
- Buenas prácticas de Ingeniería de Software propuestas por Sommerville.
- Competencia SENA 220501046 – Construcción de Requisitos.

---

# Documentación de gobierno

- [Guía de contribución](./CONTRIBUTING.md)
- [Reglas de documentación](./00-governance/documentation-rules.md)
- [Convenciones Git](./00-governance/git-conventions.md)
- [Seguridad documental](./00-governance/security-rules.md)
- [Documentación de microservicios](./00-governance/microservices-documentation.md)
- [Definition of Ready](./00-governance/definition-of-ready.md)
- [Definition of Done](./00-governance/definition-of-done.md)
- [CHANGELOG](./CHANGELOG.md)

---

# Documento fuente

Toda la documentación de este repositorio mantiene trazabilidad con el documento:

**SRS v1.0 — Sistema POS e Inventario para el Supermercado "La Esquina".**

Cualquier modificación funcional deberá reflejarse tanto en la documentación correspondiente como en la matriz de trazabilidad de requisitos.

---

# Licencia

Este repositorio corresponde a un proyecto académico desarrollado para el **Servicio Nacional de Aprendizaje (SENA)** con fines educativos y de formación en Ingeniería de Software.