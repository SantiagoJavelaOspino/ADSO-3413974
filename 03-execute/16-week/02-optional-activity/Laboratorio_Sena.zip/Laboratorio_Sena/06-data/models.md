# Modelos de datos

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Modelo conceptual

- Producto
- Venta
- DetalleVenta
- Usuario
- Crédito
- Abono
- CorteCaja
- Tiquete

## Relación entre entidades

- Una venta contiene muchos detalles.
- Un detalle pertenece a un producto y a una venta.
- Un crédito tiene muchos abonos.
- Un tiquete está asociado a una venta.
- Un corte de caja consolida varias ventas del día.

## Referencias

- [Data dictionary](./data-dictionary.md)
- [Migration strategy](./migration-strategy.md)
- [Entidades y reglas](../02-domain/entities-and-rules.md)
