# Estrategia de migración

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Objetivo

Definir cómo incorporar los datos del negocio en una solución digital sin afectar la operación diaria.

## Estrategia

1. No migrar automáticamente los cuadernos históricos D01–D06 al MVP.
2. Cargar catálogo inicial de productos con precios y stock base.
3. Crear los registros iniciales de usuarios y configuración de negocio.
4. Registrar fiados y ventas a partir del inicio del sistema.

## Riesgo

La migración manual de datos históricos puede introducir errores; por ello se prioriza un arranque limpio con carga controlada.

## Referencias

- [Data dictionary](./data-dictionary.md)
- [Scope](../01-context/scope.md)
