# Diccionario de datos

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Entidades principales

| Entidad | Atributos clave |
|---------|-----------------|
| Producto | id, nombre, precio, categoria, stockActual, stockMinimo |
| Venta | id, fechaHora, total, metodoPago, usuarioId |
| DetalleVenta | productoId, cantidad, precioUnitario, subtotal |
| Crédito | id, clienteId, montoInicial, saldoPendiente, fechaCreacion |
| Abono | id, creditoId, monto, fecha |
| CorteCaja | id, fecha, totalVentas, totalEfectivo, totalDigital, efectivoFisico, diferencia |
| Tiquete | id, ventaId, formato, contenido |

## Reglas de negocio aplicadas

- precio > 0
- stockActual ≥ 0
- stockMinimo ≥ 0
- saldoPendiente ≥ 0

## Referencias

- [Models](./models.md)
- [Entities and rules](../02-domain/entities-and-rules.md)
