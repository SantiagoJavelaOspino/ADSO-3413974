# Entrenamiento

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Contiene manuales y material de onboarding para usuarios, administradores y equipo técnico.

## Audiencias

| Audiencia | Documento principal | Quién lo escribe |
|-----------|--------------------|--------------------|
| Usuarios finales | [user-manual.md](./user-manual.md) | Equipo de soporte / producto |
| Administradores del sistema | [admin-manual.md](./admin-manual.md) | Equipo de soporte / operaciones |
| Nuevos integrantes técnicos | [technical-onboarding.md](./technical-onboarding.md) | Equipo de desarrollo / DevOps |

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [user-manual.md](./user-manual.md) | Manual para usuarios finales | 🟡 |
| [admin-manual.md](./admin-manual.md) | Manual para administración y soporte | 🟡 |
| [technical-onboarding.md](./technical-onboarding.md) | Guía de entrada para integrantes técnicos | 🟡 |
