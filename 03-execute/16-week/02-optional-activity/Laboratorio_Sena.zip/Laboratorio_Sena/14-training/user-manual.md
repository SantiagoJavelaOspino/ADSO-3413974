# Manual de usuario

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Objetivo

Guiar a usuarios del negocio en el uso del MVP para ventas, inventario y fiados.

## Secciones principales

- Registrar ventas y cobrar.
- Consultar productos y stock.
- Generar tiquetes.
- Consultar fiados y saldos.

## Referencias

- [Admin manual](./admin-manual.md)
- [Technical onboarding](./technical-onboarding.md)
