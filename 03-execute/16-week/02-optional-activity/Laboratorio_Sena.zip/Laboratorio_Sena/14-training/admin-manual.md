# Manual de administración

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Tareas administrativas

- Crear y actualizar productos.
- Configurar stock mínimo.
- Revisar corte de caja.
- Gestionar fiados y alertas.

## Referencias

- [User manual](./user-manual.md)
- [Technical onboarding](./technical-onboarding.md)
