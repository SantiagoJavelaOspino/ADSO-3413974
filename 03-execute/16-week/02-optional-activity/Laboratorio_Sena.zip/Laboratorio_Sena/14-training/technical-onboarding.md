# Onboarding técnico

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Objetivo

Acelerar la incorporación de nuevos integrantes al proyecto y al dominio del supermercado.

## Contenido inicial

- Contexto del negocio y alcance del MVP.
- Módulos M1–M6.
- Requisitos y reglas de negocio.
- Puntos de operación y soporte.

## Referencias

- [User manual](./user-manual.md)
- [Admin manual](./admin-manual.md)
