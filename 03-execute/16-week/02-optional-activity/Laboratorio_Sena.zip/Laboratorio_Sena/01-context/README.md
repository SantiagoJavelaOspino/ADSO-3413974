# Contexto

> Estado: � En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contenido

Describe el problema, alcance, contexto institucional y vocabulario base del proyecto Supermercado "La Esquina".

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Contexto institucional, problema y objetivos generales | 🟡 |
| [scope.md](./scope.md) | Alcance, exclusiones, supuestos y restricciones | 🟡 |
| [glossary.md](./glossary.md) | Glosario compartido del dominio y del sistema | 🟡 |
