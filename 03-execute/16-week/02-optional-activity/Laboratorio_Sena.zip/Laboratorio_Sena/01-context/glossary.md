# Glosario

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contexto

Lenguaje ubicuo del dominio **Supermercado "La Esquina"** — Sistema POS e Inventario MVP. Términos alineados con el SRS v1.0 y el modelo de dominio en [02-domain/](../02-domain/).

## Contenido

| Término | Definición | Contexto |
|---------|------------|----------|
| POS | Punto de Venta. Sistema que registra transacciones comerciales en mostrador. | M2 — Ventas |
| MVP | Producto Mínimo Viable. Primera versión operativa con funcionalidad esencial. | Producto |
| Fiado / Crédito | Venta a crédito registrada por cliente con saldo pendiente y abonos parciales. | M6 — Gestión de Crédito |
| Corte de caja | Cierre diario que concilia ventas registradas vs. efectivo físico en caja. | M4 — Reportes |
| Stock mínimo | Umbral configurable por producto que dispara alerta de reabastecimiento. | M1 — Inventario |
| Catálogo | Conjunto de hasta 90 productos con nombre, precio, categoría y stock. | M1 — Inventario |
| Administrador | Rol con acceso total al sistema. Usuario principal: Carlos Ruiz. | M3 — Usuarios |
| Empleado | Rol con acceso limitado: ventas e inventario en modo lectura. | M3 — Usuarios |
| Tiquete de venta | Comprobante impreso o digital (PDF/WhatsApp) generado al completar una venta. | M5 — Facturación |
| Modo offline | Operación plena de ventas e inventario sin conexión a internet. | RNF02 |
| MoSCoW | Modelo de priorización: Must Have, Should Have, Could Have, Won't Have. | Requisitos |
| Documento físico (D01–D06) | Registros manuales del negocio analizados en el levantamiento (ventas, fiado, precios, etc.). | Contexto |
| Hora pico | Franja 12:00–14:00 h con mayor afluencia y errores operativos documentados. | Operación |
| Cartera activa | Suma de deudas pendientes de clientes con crédito/fiado. Valor documentado: $336.000 COP. | M6 — Riesgo financiero |
| Abono | Pago parcial o total aplicado a un crédito/fiado de cliente. | M6 |
| Método de pago | Forma de pago registrada en venta: efectivo o digital (sin pasarela en MVP). | M2 |
| Offline-First | Arquitectura que prioriza operación local con sincronización diferida a la nube. | Arquitectura |

## Referencias

- [Entidades y reglas de negocio](../02-domain/entities-and-rules.md)
- [Diccionario de datos](../06-data/data-dictionary.md)
- Wiegers, K., & Beatty, J. (2013). *Software Requirements* (3.ª ed.). Microsoft Press.
