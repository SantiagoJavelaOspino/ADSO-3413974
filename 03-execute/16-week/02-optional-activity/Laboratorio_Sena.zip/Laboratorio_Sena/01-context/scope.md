# Alcance

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contexto

Define el alcance funcional y no funcional del **MVP — Sistema POS e Inventario** para el Supermercado "La Esquina", conforme al SRS v1.0.

## En alcance

### Sistema objetivo

Producto Mínimo Viable (MVP) de tipo **Sistema de Punto de Venta (POS) e Inventario** para microempresa familiar con hasta **90 productos** y **42,5 ventas diarias** promedio.

### Módulos del MVP (M1–M6)

| ID | Módulo | Alcance funcional |
|----|--------|-------------------|
| M1 | Inventario y Catálogo | Gestión de hasta 90 productos (nombre, precio, categoría, stock). Alertas de stock mínimo configurables por el Administrador. |
| M2 | Ventas / POS | Registro de transacciones con selección de productos, cálculo automático del total y registro del método de pago (efectivo/digital). |
| M3 | Usuarios y Roles | Acceso diferenciado: **Administrador** (Carlos Ruiz) acceso total; **Empleado** acceso limitado a ventas e inventario en modo lectura. |
| M4 | Reportes y Corte de Caja | Resumen diario de ventas por método de pago, diferencia versus caja física e historial consultable con filtros. |
| M5 | Facturación / Tiquetes | Generación de tiquete de venta en formato impreso o digital (PDF/WhatsApp) al completar cada transacción. |
| M6 | Gestión de Crédito / Fiado | Registro de créditos por cliente, abonos, saldo pendiente y alertas de vencimiento (deudas con más de 30 días sin abono). |

### Requisitos Must Have incluidos en MVP

| ID | Requisito |
|----|-----------|
| RF01 | Registro de Venta / POS Básico |
| RF02 | Catálogo de Productos |
| RNF01 | Interfaz Intuitiva (≤2 h inducción) |
| RNF02 | Funcionamiento en Modo Offline |
| RNF05 | Compatibilidad con Hardware de Bajo Costo |
| RN01 | Modelo de Costo Único (sin suscripción mensual) |
| RN02 | Autonomía Operativa |

Ver detalle completo en [functional.md](../04-requirements/functional.md), [non-functional.md](../04-requirements/non-functional.md) y [entities-and-rules.md](../02-domain/entities-and-rules.md).

## Fuera de alcance

| Exclusión | Clasificación futura |
|-----------|---------------------|
| Integración directa con pasarelas de pago (Nequi, Daviplata, datáfono) | Escalabilidad — segunda iteración |
| Facturación electrónica DIAN | Fuera de MVP |
| Gestión contable completa | Fuera de MVP |
| Administración de múltiples sucursales | Fuera de MVP |
| Gestión de proveedores (RF08) | Could Have — mediano plazo |
| Reporte de productos más vendidos (RF10) | Could Have — mediano plazo |

> El registro del **método de pago** (efectivo/digital) sí está en alcance del M2 para informar decisiones futuras sobre pagos digitales.

## Supuestos

| ID | Supuesto |
|----|----------|
| SUP-01 | El negocio dispone de tablet Android 8.0+ o PC Windows 10 con mínimo 2 GB RAM. |
| SUP-02 | Carlos Ruiz es el único decisor para adopción, configuración y actualización de precios. |
| SUP-03 | El catálogo inicial no superará 90 productos en la primera versión operativa. |
| SUP-04 | La conectividad a internet es residencial básica con interrupciones ocasionales. |
| SUP-05 | El equipo operativo (4 personas) no tiene experiencia previa con sistemas POS. |
| SUP-06 | Los datos históricos de cuadernos D01–D06 no se migrarán automáticamente al MVP. |

## Restricciones

| ID | Restricción | Origen |
|----|-------------|--------|
| RES-01 | Curva de aprendizaje máxima: **2 horas** de inducción | RNF01 — Carlos Ruiz |
| RES-02 | Arquitectura **Offline-First** con sincronización < 5 min al recuperar conexión | RNF02 |
| RES-03 | Hardware mínimo: Android 8.0 / Windows 10, 2 GB RAM | RNF05 |
| RES-04 | **Costo único** — sin suscripción mensual recurrente | RN01 |
| RES-05 | Operaciones diarias sin asistencia técnica externa | RN02 |
| RES-06 | Solo el Administrador puede crear, editar o eliminar productos | RF02 |
| RES-07 | Documento académico con fines de formación SENA — competencia 220501046 | Institucional |

## Referencias

- [Overview — Diagnóstico operacional](./overview.md)
- [Mapa de dominio](../02-domain/domain-map.md)
- [Backlog de producto](../03-product/product-backlog.md)
- [Riesgos financieros](../15-project-control/risks.md)
