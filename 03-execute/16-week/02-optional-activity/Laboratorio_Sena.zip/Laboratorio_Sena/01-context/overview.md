# Overview

> Estado: 🟡 En progreso | Última actualización: 2026-07-04
> Autor: Equipo ADSO — SENA | Equipo: Análisis y Desarrollo de Software

## Contexto

### Contexto institucional

Proyecto académico del **Servicio Nacional de Aprendizaje (SENA)** — Tecnología en Análisis y Desarrollo de Software, competencia **220501046** (Construir los requisitos del sistema de información). El documento base es el **SRS — Supermercado "La Esquina" v1.0** (SENA, 2026), elaborado bajo marcos **IEEE 830**, **NTC-ISO/IEC 25010**, **MoSCoW** y **Sommerville (2016)**.

### Contexto del establecimiento

El **Supermercado "La Esquina"** es un establecimiento comercial de carácter familiar ubicado en un sector residencial de barrio, con operación en jornada completa (**7:00 a.m. – 7:00 p.m.**). Su propietario, **Carlos Ruiz**, actúa como principal cajero y único decisor estratégico.

| Indicador | Valor |
|-----------|-------|
| Equipo operativo | 4 personas |
| Catálogo | ~90 productos de consumo masivo |
| Volumen diario | 35–50 transacciones (promedio **42,5 ventas/día**) |
| Cliente / patrocinador | Carlos Ruiz — Propietario |

### Stakeholders y actores

| Actor | Rol en el negocio | Jornada | Doc. asociado | Observación clave |
|-------|-------------------|---------|---------------|-------------------|
| Carlos Ruiz | Propietario / Jefe (único decisor y cajero principal) | 7 a.m. – 7 p.m. | D01, D02, D05, D06 | Resistencia tecnológica moderada. Único con poder de decisión sobre el sistema. Opera por memoria sin respaldo digital. |
| Martha Suárez | Cajera — tiempo completo. Apoya caja en horas pico. | 7 a.m. – 4 p.m. | D01 | Caligrafía variable en el cuaderno de ventas (D01): dificulta la lectura y auditoría de registros históricos. |
| Julián Torres | Empleado — tiempo completo. | 8 a.m. – 4 p.m. | D01 | Comete más errores al sumar durante la hora pico (12:00–2:00 p.m.), según ficha de observación directa (D01). |
| Diego Morales | Empleado — medio tiempo. | 2 p.m. – 7 p.m. | D04 | Detectó errores de precio en D04 (aceite, arroz). Consulta frecuentemente el cuaderno de precios por desactualización. |

### Instrumentos de recolección

La operación se analizó mediante cuatro instrumentos complementarios:

1. Entrevista semiestructurada (propietario y equipo)
2. Ficha de observación directa (horario pico 12:00–14:00 h)
3. Encuesta a clientes (n=15)
4. Revisión documental de seis registros físicos (**D01–D06**)

## Problema

### Diagnóstico operacional

La operación del supermercado se ejecuta de forma **100% manual**, mediante cuaderno y calculadora, lo que genera ineficiencias estructurales documentadas.

#### Hallazgos por documento físico (D01–D06)

| Doc. | Nombre del registro | Hallazgo clave | Requisito derivado |
|------|---------------------|----------------|-------------------|
| D01 | Cuaderno de ventas (ene–sep 2024) | Sin clasificación por producto, empleado ni hora pico. Caligrafía variable imposibilita auditoría. Promedio 42,5 ventas/día. | RF01, RF10 |
| D02 | Cuaderno de fiado | 12 clientes activos · Cartera: **$336.000 COP** · Promedio: **$28.000 COP/cliente**. Sin columna de abonos ni saldo actualizado. | RF05 |
| D03 | Facturas de proveedores | Tres proveedores: Alimentos del Sur, Bebidas La Unión, Surtidor Pan de Horno. Sin comparación precio factura vs. venta. | RF08 |
| D04 | Lista de precios | **8 de 90 productos (~9%)** con precio inconsistente entre cuaderno y estantería. Cobros incorrectos reportados. | RF02, RNF06 |
| D05 | Registro de pedidos a proveedores | Pedidos por memoria del propietario. Sin umbrales mínimos. Agotamientos no planificados. | RF03 |
| D06 | Corte de caja diario | Sin desglose por producto, hora pico ni rendimiento por empleado. Nula trazabilidad para auditoría. | RF04, RF10 |

> **Nota:** Cada documento reveló brechas operativas que Carlos Ruiz no mencionó espontáneamente en la entrevista — requisitos implícitos según Sommerville (2016).

#### Impacto cuantificado — Proceso de venta manual

| Paso del proceso | Mín (s) | Máx (s) | Prom (s) | % del total | Error |
|------------------|---------|---------|----------|-------------|-------|
| 1. Cliente lleva productos al mostrador | 30 | 30 | 30 | 7,9% | Bajo |
| 2. Identificar precio de cada producto | 60 | 105 | 82,5 | 21,6% | Alto ⚠ |
| 3. Sumar precios con calculadora ← **CUELLO DE BOTELLA** | 90 | 150 | **120** | **44%** | Alto ⚠ |
| 4. Anotar venta en cuaderno | 60 | 90 | 75 | 19,6% | Medio |
| 5. Calcular y entregar cambio | 40 | 60 | 50 | 13,1% | Medio |
| 6. Archivar tiquete / recibo | 20 | 30 | 25 | 6,5% | Bajo |
| **TOTAL POR TRANSACCIÓN** | 300 | 465 | **382,5** | 100% | — |

Con 42,5 ventas diarias y 382,5 s por transacción → **16.256 s diarios** en cobro; **5.100 s (85 min)** exclusivamente en suma manual. La automatización reduce el tiempo de **382 s a 145 s** (−62%), equivalente a **3,7 horas productivas diarias** recuperadas.

#### Hallazgos críticos adicionales

| Hallazgo | Descripción e impacto |
|----------|----------------------|
| Precios desactualizados | 8/90 productos (~9%) con precio inconsistente; cobros incorrectos reportados por Rosa Vargas, Felipe Salcedo y Hernán Ospina. |
| Cartera sin trazabilidad | 12 clientes · $336.000 COP cartera activa; sin abonos ni saldo actualizado. |
| Sin control de inventario | *"No sé cuándo se va a acabar un producto hasta que ya no hay"* (Carlos Ruiz, D05). |
| Ventas perdidas por pagos digitales | **4/15 clientes (26,7%)** abandonaron compras por ausencia de Nequi, Daviplata o datáfono. Validado por triangulación encuesta × observación directa. |

#### Triangulación — Pagos digitales

| Instrumento | Evidencia |
|-------------|-----------|
| Encuesta (n=15) | 4 clientes (26,7%) abandonaron compra por falta de pago digital |
| Observación directa (12:00–14:00 h) | Al menos un episodio de retiro sin comprar en horario pico |
| **Conclusión** | Hallazgo validado por convergencia multi-instrumento. Nivel de confianza: **alto**. |

## Objetivos

### Objetivo general

Desarrollar un **MVP de Sistema POS e Inventario** que permita a Carlos Ruiz y su equipo registrar ventas, controlar el inventario de hasta 90 productos y gestionar créditos de clientes, con curva de aprendizaje máxima de **dos horas de inducción**.

### Objetivos específicos

| ID | Objetivo | Métrica de éxito |
|----|----------|------------------|
| OBJ-01 | Eliminar suma manual en caja | Reducir tiempo de transacción de 382 s a 145 s (−62%) |
| OBJ-02 | Centralizar catálogo de productos | 0 discrepancias precio cuaderno vs. sistema |
| OBJ-03 | Trazabilidad de cartera de fiado | Registro digital de créditos, abonos y saldos |
| OBJ-04 | Operación autónoma sin soporte externo | Inducción ≤ 2 h; actualización de precios sin técnico (RNF06) |
| OBJ-05 | Disponibilidad operativa | Funcionamiento offline-first (RNF02) |

## Referencias

- [Alcance del MVP](./scope.md)
- [Glosario](./glossary.md)
- [Requisitos funcionales](../04-requirements/functional.md)
- [Matriz de trazabilidad](../04-requirements/traceability-matrix.md)
- SENA. (2026). *SRS — Supermercado "La Esquina" v1.0*.
- Sommerville, I. (2016). *Ingeniería de Software* (10.ª ed.). Pearson Educación.
- IEEE. (1998). *IEEE Std 830-1998*.
